#!/bin/bash -x

# Report vertex logic start timestamp
date '+%Y%m%d-%H%M%S' > /tmp/image_start_timestamp
systemctl daemon-reload
systemctl start log-systemd-services.service

systemctl start \
  workbench-configure.service \
  riptide-init.service \
  disable-ssh-access.service \
  disable-gce-startup-scripts.service \
  workbench-mount-disk.service

# Enable containerd, gcfsd and snapshotter. (for Riptide)
systemctl start gcfsd snapshotter
systemctl restart containerd
systemctl start pull-custom-container-payload.service

systemctl start workbench-euc-metadata.service
systemctl start jupyter-payload.service
systemctl start workbench-euc-agent.service

systemctl start workbench-proxy-agent.service
systemctl start workbench-idle-shutdown-agent.service
systemctl start workbench-health-agent.service
systemctl start workbench-diagnostic-service.service

systemctl start euc-initialization.service
date '+%Y%m%d-%H%M%S' >> /tmp/image_end_timestamp

systemctl start run-post-startup.service
