# Atlas Provisioning: Chain of Events

**Scenario:** A data scientist asks for a GPU workbench from the Atlas UI.
**Companion to:** [atlas-session-persistence-spec.md](atlas-session-persistence-spec.md)

This document follows one request from click to ready, showing which component acts, what it writes, and what the state is afterwards. It then walks through every point where a component can fail and what recovers it.

---

## 1. Actors

| Actor | Runs where | Role in the chain |
|---|---|---|
| **Client** | Browser, VS Code extension, or SDK | Sends the request, then polls or subscribes for the result |
| **Edge** | Load balancer with SSO / Identity-Aware Proxy | Verifies identity. Injects the principal. Atlas never sees a password or token secret. |
| **Experience API** | GKE, stateless pods | Attaches the session, validates, persists intent, returns 202 |
| **Cloud SQL** | PostgreSQL 16/17 | The only component whose writes are transactional. Holds session, operation, event, and resource rows. |
| **Worker** | GKE, separate Deployment | Claims pending operations, calls the orchestrator, records the outcome |
| **Orchestrator API** | Existing service | Synchronous request and response. Runs Terraform, talks to Vertex and Cloud Workstations. |
| **GCP** | Vertex AI, Cloud Workstations | Where the resource actually comes to exist |

The one design constraint everything follows from: **an HTTP call cannot join a Postgres transaction.** There is no two-phase commit between Cloud SQL and a REST endpoint. So the chain never tries to make the database write and the orchestrator call atomic. It makes the sequence safe under failure instead.

---

## 2. The happy path

```mermaid
sequenceDiagram
    autonumber
    participant C as Client
    participant E as Edge (SSO)
    participant A as Experience API
    participant DB as Cloud SQL
    participant W as Worker
    participant O as Orchestrator
    participant G as GCP

    C->>E: POST /mlWorkspaces/{ws}/workstations<br/>Idempotency-Key, X-Atlas-Session-Id
    E->>A: same request + verified principal
    A->>DB: SELECT session WHERE id AND user AND live
    DB-->>A: session row (or none → create)
    A->>DB: BEGIN
    A->>DB: INSERT workstation_configuration
    A->>DB: INSERT workstation (PROVISIONING)
    A->>DB: INSERT operation (PENDING)
    A->>DB: INSERT operation_event (NULL → PENDING)
    A->>DB: COMMIT
    A-->>C: 202 Accepted, Location: /operations/{op}
    Note over C,A: Elapsed: tens of milliseconds

    loop every 1–2 s (or on NOTIFY)
        W->>DB: claim: UPDATE … FOR UPDATE SKIP LOCKED
    end
    DB-->>W: operation row, status RUNNING, lease held
    W->>DB: INSERT operation_event (PENDING → RUNNING)
    W->>O: POST /provision (idempotency key = operation_id)
    O->>G: terraform apply
    Note over W,G: Minutes. Possibly an approval wait.
    G-->>O: workstation created
    O-->>W: 200 { correlationId, resourceName, host }
    W->>DB: BEGIN
    W->>DB: UPDATE operation SET SUCCEEDED, result_payload, completed_at
    W->>DB: UPDATE workstation SET READY, url, launch_url, external_resource_name
    W->>DB: INSERT operation_event (RUNNING → SUCCEEDED)
    W->>DB: COMMIT

    loop until terminal
        C->>A: GET /operations/{op}
        A->>DB: SELECT operation
        A-->>C: { status, resultPayload }
    end
    C->>A: GET /workstations/{id}
    A-->>C: { lifecycleStatus: READY, launchUrl }
```

![Provisioning sequence: client, edge, API, Cloud SQL, worker, orchestrator, GCP](atlas-design-pack/diagrams/provisioning-sequence.png)

*Rendered: [PNG](atlas-design-pack/diagrams/provisioning-sequence.png) · [SVG](atlas-design-pack/diagrams/provisioning-sequence.svg) · [Mermaid source](atlas-design-pack/diagrams/provisioning-sequence.mmd)*

### 2.1 Step by step

| # | Actor | What happens | Durable state afterwards |
|---|---|---|---|
| 1 | Client | Sends the provisioning request with an `Idempotency-Key` it generated and its session ID header. | none |
| 2 | Edge | Verifies SSO. Forwards with the principal email. | none |
| 3 | API | **Session attach.** Looks up the session by ID, checks it belongs to this principal and is live. If missing or stale, creates a new one. This is a separate, cheap write. It is never inside the provisioning transaction. | `session` row live |
| 4 | API | **Validate.** Principal maps to a user. User may act on this ML workspace and use case. Requested configuration is within policy, for example GPU count. Any failure returns 4xx here. Nothing has been written. | unchanged |
| 5 | API | **Idempotency check.** Looks up `(user_id, idempotency_key)`. If an operation already exists, return `200` with it and stop. | unchanged |
| 6 | API | **Local transaction one.** Inserts the configuration, the workstation row as `PROVISIONING`, the operation as `PENDING`, and the first event. Commits. | Intent is durable. Nothing exists in GCP yet. |
| 7 | API | Returns `202 Accepted` with the operation ID and a `Location` header. | unchanged |
| 8 | Worker | **Claim.** One statement moves the oldest ready `PENDING` row to `RUNNING`, sets `locked_by` to the pod name, `locked_at` to now, and increments `attempt_count`. `SKIP LOCKED` guarantees no two workers take the same row. | operation `RUNNING`, lease held |
| 9 | Worker | Writes the `PENDING → RUNNING` event. | event appended |
| 10 | Worker | **Remote call.** Calls the orchestrator synchronously. Passes the operation ID as the idempotency key. Timeout of, say, 20 minutes. As soon as a correlation ID comes back in the response headers or an early body, writes it to the operation row. | `orchestrator_correlation_id` set |
| 11 | Orchestrator | Runs Terraform. Creates the Cloud Workstation. May wait on an approval. | Resource exists in GCP |
| 12 | Worker | **Local transaction two.** Marks the operation `SUCCEEDED` with the result, flips the workstation to `READY` with its URLs and external resource name, writes the event. Commits. | Atlas and GCP agree |
| 13 | Client | Has been polling the operation. Sees `SUCCEEDED`. Fetches the workstation and gets a launch URL. | none |

### 2.2 State after each commit

| After step | `operation.status` | `workstation.lifecycle_status` | Exists in GCP | Recoverable if we crash now? |
|---|---|---|---|---|
| 6 | `PENDING` | `PROVISIONING` | no | yes, another worker picks it up |
| 8 | `RUNNING` | `PROVISIONING` | no | yes, lease expires and it returns to pending |
| 10 | `RUNNING` | `PROVISIONING` | unknown | yes, reconcile by idempotency key before retrying |
| 11 | `RUNNING` | `PROVISIONING` | yes | yes, retry with same key returns the existing resource |
| 12 | `SUCCEEDED` | `READY` | yes | nothing left to recover |

---

## 3. Why persist first

Two orders are possible. Only one is safe.

**Call first, then write.** If the orchestrator succeeds and the database write fails, a workstation exists that costs money and has no record of who asked for it. If the database is unreachable, the API cannot even know whether it already made the call. This is unrecoverable without a manual audit.

**Write first, then call.** The worst case is a recorded intent that has not happened yet. Every failure from that point is a retry or a reconcile. This is the transactional outbox pattern. The `operation` table is the outbox, the worker is the relay.

---

## 4. Failure windows and recovery

The chain has exactly five places a component can die between the commit of intent and the commit of outcome. Each has a specific answer.

| Window | What died | Observable state | Recovery | Who does it |
|---|---|---|---|---|
| **A** | API pod, after transaction one committed, before the 202 left | Operation `PENDING`, client got a network error | Client retries with the **same** `Idempotency-Key`. API finds the existing operation and returns `200` with it. Worker proceeds normally. | Client retry + idempotency check |
| **B** | Worker, after claim, before calling the orchestrator | Operation `RUNNING`, lock held by a dead pod, no correlation ID | Stale-lease sweep resets it to `PENDING` after 30 minutes. Another worker claims it. Nothing was created. | Stale-lease sweep |
| **C** | Worker, during the orchestrator call | Operation `RUNNING`, correlation ID may or may not be set, resource may or may not exist | Sweep resets to `PENDING`. Next worker **first** asks the orchestrator for the status of this idempotency key. If a resource exists, record success. If not, call again. | Sweep + reconcile-before-retry |
| **D** | Worker, after orchestrator returned success, before transaction two committed | Operation `RUNNING`, resource exists in GCP, Atlas says `PROVISIONING` | Same as C. The retry carries the same key. The orchestrator returns the existing resource instead of creating another. Worker records success. | Sweep + idempotent orchestrator |
| **E** | Orchestrator, mid-Terraform | Worker gets a 5xx or timeout | Worker sets `PENDING` with `next_attempt_at = now + 2^attempt minutes`. On the retry, reconcile first as in C. After `max_attempts`, `FAILED`. Workstation flips to `FAILED`. | Worker backoff |

Two things make every row of this table work:

1. **At-least-once execution.** No operation is ever lost, because it was committed before anything else happened.
2. **An idempotent receiver.** The orchestrator, given the same key twice, produces one resource and returns it both times.

Together they give exactly-once *effect* without exactly-once *delivery*, which is the only kind of exactly-once that exists across a network.

If the orchestrator cannot be made idempotent, the fallback is weaker but workable: the worker derives the resource name deterministically from the operation ID, and before every create it lists resources by that name.

---

## 5. Where the session sits in this

The session is deliberately kept out of the unit of work.

- **Attach** is step 3. It is a read, or at most a single-row insert, and it happens before validation. If the client sent a session ID that belongs to another user or has expired, the API creates a fresh session rather than failing the request.
- **Latching** onto an existing session means the client stored the session ID from an earlier response and sends it as a header. VS Code and the web UI would each hold their own.
- **The operation carries `session_id`** for one reason: so the UI can show "operations started from this session" and so audit can answer "what was this person doing at the time". It is nullable because the reaper, the reconciler, and the backfill create operations with no session.
- **Session expiry never cancels an operation.** If the user closes the laptop at step 10, the workbench still gets built. The next session they open lists it as ready.

---

## 6. Timing you should expect

| Segment | Typical | Bound by |
|---|---|---|
| Client request to 202 | 20 to 80 ms | One session lookup, a few validation reads, one transaction |
| 202 to worker claim | under 2 s with polling, under 200 ms with `LISTEN/NOTIFY` | Poll interval |
| Worker call to orchestrator response | 3 to 15 minutes | Terraform apply, Cloud Workstations create |
| With a GPU or cloud-platform approval | hours to days | Human approver. Operation sits in `AWAITING_APPROVAL`. |
| Orchestrator response to `READY` visible | under 100 ms | One transaction |

The client-visible latency is the first row. Everything else is background.

---

## 7. Poller or listener

The default is a poller running `FOR UPDATE SKIP LOCKED` every 1 to 2 seconds. It is simple, has no extra infrastructure, and is correct on its own.

A listener reduces pickup latency. Two options:

- **Postgres `LISTEN/NOTIFY`.** The API issues `NOTIFY operations` after commit. Workers hold a listening connection and wake immediately. Note that a listening connection cannot go through PgBouncer in transaction mode; give workers one direct connection for the listen.
- **Pub/Sub or Cloud Tasks.** The API publishes the operation ID after commit. Slightly more moving parts and a second place a message can be lost.

Whichever you add, **keep the poller.** A notification can be dropped. The poller is what guarantees no operation stays pending forever.

---

## 8. A synchronous façade, if someone needs one

Some clients, a CLI for example, want a blocking call. Do not build a second path that skips the outbox. Instead:

1. Accept the request exactly as above. Commit intent. Get an operation ID.
2. Long-poll the operation row for up to 30 seconds.
3. Return whatever state it reached, with the operation ID so the client can keep polling if it is not terminal.

The client gets a blocking feel for fast operations. The persistence and recovery story underneath is identical.

---

## 9. Invariants the chain guarantees

- An operation row exists before any call leaves the cluster.
- No two workers hold the same operation at once.
- A resource is never created twice for one user request.
- A user request is never silently lost.
- Every status change has an event row with an actor and timestamp.
- The database can be rebuilt from the operation and event tables plus the cloud inventory. The reverse is also true, which is what the reconciler in the spec relies on.
