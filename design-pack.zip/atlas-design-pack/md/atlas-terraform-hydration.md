# Hydrating Operational Metadata from Terraform

**Scope:** Populating the Atlas session and operation database from resources that already exist and were deployed with Terraform.
**Companions:** [atlas-session-persistence-spec.md](atlas-session-persistence-spec.md) (schema, Part 2 inventory backfill), [atlas-provisioning-chain-of-events.md](atlas-provisioning-chain-of-events.md) (runtime mechanics)

---

## 1. What Terraform adds that the inventory does not

Part 2 of the spec hydrates *what exists* from Cloud Asset Inventory. That gives you the resource rows. It does not give you the operational history: who asked for each resource, when it was applied, what it looked like before the last resize, or whether an apply failed on the way.

Terraform has that history, because every resource Atlas cares about passed through a state file and an apply run. So Terraform is the source for three things the inventory cannot provide:

| Atlas table | What Terraform supplies | Where it comes from |
|---|---|---|
| `operation` | One row per apply that created, changed, or destroyed a resource: type, outcome, timestamps, requester, correlation ID, request and result payloads | Run history plus state snapshot diffs |
| `operation_event` | The status transitions of each of those runs | Run lifecycle timestamps |
| Resource rows | Intent-level attributes the cloud API flattens away: the module inputs, the variable values, the git commit, the Backstage template that generated it | State `values`, HCL and tfvars in git, scaffolder PR metadata |

The rule for precedence: **Cloud Asset Inventory wins on existence and current state. Terraform wins on intent, ownership, and history.** When they disagree, that disagreement is itself a finding and is recorded as drift.

---

## 2. Terraform artefacts and what each yields

| Artefact | Yields | How to read it |
|---|---|---|
| **Current state file** per workspace | Every managed resource instance with resolved attributes, its module address, provider, and dependencies | `terraform show -json` against the state, or read the JSON state directly from the GCS backend |
| **State history** | One snapshot per apply. Diffing consecutive snapshots reconstructs every create, update, and destroy | GCS object versioning on the backend bucket: `gsutil ls -a gs://<bucket>/<prefix>/default.tfstate` lists every generation with its timestamp |
| **Run records** | Who triggered, when it started and finished, plan and apply outcome, the commit applied | Terraform Cloud/Enterprise API (`/runs`, `/applies`), Atlantis, or the CI system (Cloud Build, GitHub Actions, GitLab) that ran `terraform apply` |
| **HCL and tfvars in git** | Module inputs by name: use case, owner, environment, machine type, GPU, image. Commit author and date. | `git log --follow` on the module directory; parse tfvars at the applied commit |
| **Backstage scaffolder metadata** | The original request: template used, requester, form inputs, resulting PR | Scaffolder task API, or the PR description the template wrote |
| **Workspace and module naming** | Business unit and use case, when the convention encodes them | Crosswalk `TF_WORKSPACE` and `TF_MODULE` |

Which resource types to look for in state:

| Terraform type | Atlas entity |
|---|---|
| `google_workstations_workstation` | `workstation` |
| `google_workstations_workstation_config` | `workstation_configuration` |
| `google_workstations_workstation_cluster` | context only, not modelled |
| `google_workbench_instance`, `google_notebooks_instance` | `notebook` (or `workstation` with `JUPYTER`, per the day-one decision) |
| `google_vertex_ai_endpoint` | `model_endpoint` |
| `google_vertex_ai_metadata_store` | context for `experiment` |
| `google_project` | crosswalk to `use_case` |

Vertex pipeline jobs, models, and experiments are usually created by SDK calls, not Terraform. They stay on the inventory path from Part 2. If your pipelines do register models through Terraform, add `google_vertex_ai_model` here.

---

## 3. Staging tables

These sit alongside `inventory_asset` and `entity_crosswalk` from Part 2.

```sql
-- One row per state snapshot captured from the backend
CREATE TABLE tf_state_snapshot (
    snapshot_id     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace       VARCHAR(255) NOT NULL,          -- TFC workspace or backend prefix
    backend_uri     TEXT NOT NULL,                  -- gs://bucket/prefix/default.tfstate#generation
    generation      BIGINT,                         -- GCS generation, NULL for TFC
    serial          BIGINT NOT NULL,                -- state serial, monotonic per lineage
    lineage         UUID NOT NULL,                  -- state lineage
    terraform_version VARCHAR(20),
    captured_at     TIMESTAMPTZ NOT NULL,           -- object update time = apply time
    raw_state       JSONB NOT NULL,
    run_id          UUID REFERENCES reconcile_run(run_id),
    UNIQUE (lineage, serial)
);

-- One row per resource instance per snapshot, with its change relative to the prior snapshot
CREATE TYPE tf_change_kind_enum AS ENUM ('CREATE', 'UPDATE', 'DELETE', 'NO_OP', 'REPLACE');

CREATE TABLE tf_resource_instance (
    instance_id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    snapshot_id         UUID NOT NULL REFERENCES tf_state_snapshot(snapshot_id),
    address             TEXT NOT NULL,              -- module.ds_workbench["alice"].google_workstations_workstation.this
    module_path         TEXT,                       -- module.ds_workbench["alice"]
    resource_type       VARCHAR(120) NOT NULL,
    provider            VARCHAR(120),
    external_id         TEXT,                       -- attributes.id or attributes.name
    attributes          JSONB NOT NULL,
    change_kind         tf_change_kind_enum NOT NULL,
    changed_attributes  JSONB,                      -- {attr: {before, after}} for UPDATE and REPLACE
    UNIQUE (snapshot_id, address)
);

CREATE INDEX idx_tf_instance_external ON tf_resource_instance(external_id);
CREATE INDEX idx_tf_instance_type     ON tf_resource_instance(resource_type, change_kind);

-- One row per run, from whichever system executed the apply
CREATE TABLE tf_run (
    tf_run_id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_system   VARCHAR(50) NOT NULL,           -- 'TFC' | 'ATLANTIS' | 'CLOUD_BUILD' | 'GITHUB_ACTIONS' | 'GCS_GENERATION'
    source_run_ref  TEXT NOT NULL,                  -- run-abc123, build id, or the GCS generation
    workspace       VARCHAR(255) NOT NULL,
    snapshot_id     UUID REFERENCES tf_state_snapshot(snapshot_id),
    triggered_by    VARCHAR(255),                   -- principal email, or CI service account
    commit_sha      CHAR(40),
    commit_author   VARCHAR(255),
    scaffolder_task TEXT,                           -- Backstage task id if the PR came from a template
    requester       VARCHAR(255),                   -- resolved: scaffolder requester > commit author > triggered_by
    status          VARCHAR(20) NOT NULL,           -- 'APPLIED' | 'ERRORED' | 'DISCARDED'
    created_at      TIMESTAMPTZ NOT NULL,
    apply_started_at TIMESTAMPTZ,
    apply_finished_at TIMESTAMPTZ,
    error_summary   TEXT,
    UNIQUE (source_system, source_run_ref)
);
```

Add these operation types so imported history keeps its meaning:

```sql
ALTER TYPE operation_type_enum ADD VALUE 'TF_IMPORT_CREATE';
ALTER TYPE operation_type_enum ADD VALUE 'TF_IMPORT_UPDATE';
ALTER TYPE operation_type_enum ADD VALUE 'TF_IMPORT_DELETE';
```

Where the change is recognisably one of the native types, use the native type instead. A `machine_type` change on a workstation is `RESIZE_WORKSTATION`. A first appearance is `CREATE_WORKSTATION`. The `TF_IMPORT_*` types are for changes that do not map cleanly, such as a label-only update.

---

## 4. The hydration pipeline

```mermaid
flowchart TB
    subgraph collect[Collect]
        GCS[GCS backend<br/>every state generation]
        TFC[Run system<br/>TFC, Atlantis, Cloud Build]
        GIT[Git<br/>HCL, tfvars, commit author]
        SCF[Backstage scaffolder<br/>template, requester, PR]
    end

    subgraph stage[Staging]
        SNAP[(tf_state_snapshot<br/>one per apply)]
        RUNS[(tf_run<br/>who, when, outcome)]
        INST[(tf_resource_instance<br/>address, attributes,<br/>change_kind)]
    end

    subgraph transform[Transform]
        DIFF[Diff consecutive snapshots<br/>CREATE UPDATE DELETE REPLACE]
        REQ[Resolve requester<br/>scaffolder > commit author<br/>> trigger > terraform-ci]
        TYPE[Derive operation type<br/>resize, create, delete,<br/>promote, TF_IMPORT_*]
    end

    subgraph write[Atlas tables]
        OP[(operation<br/>SUCCEEDED or FAILED<br/>idempotency_key tf:ws:serial:addr)]
        EV[(operation_event<br/>PENDING, RUNNING, terminal)]
        RES[(resource rows<br/>provisioning_spec,<br/>tf_address, tf_workspace)]
    end

    subgraph recon[Reconcile against inventory]
        INV[(inventory_asset)]
        ST{Compare}
        SYNC[IN_SYNC]
        DR[DRIFTED<br/>changed in console]
        OR[ORPHANED<br/>no Terraform history]
        MI[MISSING<br/>gone from cloud]
    end

    GCS --> SNAP
    TFC --> RUNS
    GIT --> RUNS
    SCF --> RUNS
    SNAP --> DIFF --> INST
    RUNS --> REQ
    INST --> TYPE
    REQ --> OP
    TYPE --> OP
    OP --> EV
    INST --> RES
    RES --> ST
    INV --> ST
    ST --> SYNC
    ST --> DR
    ST --> OR
    ST --> MI

    HOOK[Post-apply hook<br/>POST /internal/terraform/applies] -.->|after baseline| SNAP
    SWEEP[Nightly state sweep] -.->|after baseline| GCS
```

![Terraform hydration flow: collect, stage, transform, write, reconcile](atlas-design-pack/diagrams/terraform-hydration-flow.png)

*Rendered: [PNG](atlas-design-pack/diagrams/terraform-hydration-flow.png) · [SVG](atlas-design-pack/diagrams/terraform-hydration-flow.svg) · [Mermaid source](atlas-design-pack/diagrams/terraform-hydration-flow.mmd)*

### 4.1 Collect

1. **Enumerate workspaces.** From Terraform Cloud, or by listing state objects under the backend bucket prefix.
2. **Pull every state generation.** For GCS backends with versioning, list all generations and download each. For Terraform Cloud, page through state versions. One row per generation into `tf_state_snapshot`. The object's update time is the apply time.
3. **Pull run records** for the same period into `tf_run`. Join to snapshots on workspace and the closest `apply_finished_at` at or before `captured_at`, or on the state serial where the run system records it.
4. **Resolve the requester** for each run in this order: Backstage scaffolder requester, then git commit author, then the run's `triggered_by`. If it is a CI service account with no human behind it, map it to a system user named `terraform-ci` so the foreign key holds and the audit trail is honest.
5. **Index git.** For each module directory, record which commit was applied by which run, and parse the tfvars at that commit for the human-readable inputs.

### 4.2 Diff

For each workspace, walk snapshots in serial order. For each resource address:

- Present now, absent before → `CREATE`
- Present in both, attributes differ → `UPDATE`, with `changed_attributes`
- Absent now, present before → `DELETE`
- Address unchanged but `id` changed → `REPLACE`

Write one `tf_resource_instance` row per address per snapshot. This step is pure computation over the staged JSON and can be re-run at will.

### 4.3 Transform into operations

For every `tf_resource_instance` whose `change_kind` is not `NO_OP`, create one `operation` and its events.

| `operation` column | Value |
|---|---|
| `session_id` | `NULL` |
| `user_id` | `tf_run.requester` resolved to a user |
| `use_case_id` | crosswalk from module path, workspace, or project |
| `operation_type` | derived: see 4.4 |
| `target_entity_type` | from the Terraform type |
| `target_entity_id` | the Atlas row matched by `external_id` |
| `idempotency_key` | `'tf:' \|\| workspace \|\| ':' \|\| serial \|\| ':' \|\| address` |
| `status` | `SUCCEEDED` for `APPLIED` runs, `FAILED` for `ERRORED` |
| `request_payload` | module inputs from tfvars at the applied commit, plus `changed_attributes.before` for updates |
| `result_payload` | `attributes` after apply |
| `orchestrator_correlation_id` | `tf_run.source_system \|\| ':' \|\| source_run_ref` |
| `attempt_count` | 1 |
| `started_at`, `completed_at` | `apply_started_at`, `apply_finished_at`, falling back to `captured_at` for both |
| `created_at` | `tf_run.created_at`, falling back to `captured_at` |

Events, three per operation:

| `from_status` | `to_status` | `created_at` | `actor` |
|---|---|---|---|
| `NULL` | `PENDING` | `tf_run.created_at` | requester |
| `PENDING` | `RUNNING` | `apply_started_at` | `terraform:` + source system |
| `RUNNING` | `SUCCEEDED` or `FAILED` | `apply_finished_at` | `terraform:` + source system |

Set `detail` to `{"imported_from": "terraform", "workspace": ..., "serial": ..., "address": ...}` so nobody mistakes reconstructed history for events Atlas observed live.

### 4.4 Deriving the operation type

| Terraform type | `change_kind` | Signal | Operation type |
|---|---|---|---|
| workstation | `CREATE` | | `CREATE_WORKSTATION` |
| workstation | `DELETE` | | `DELETE_WORKSTATION` |
| workstation or its config | `UPDATE` | `machine_type`, `accelerators`, `boot_disk_size_gb` changed | `RESIZE_WORKSTATION` |
| workstation | `UPDATE` | only `labels`, `annotations`, `display_name` changed | `TF_IMPORT_UPDATE` |
| workstation | `REPLACE` | | `DELETE_WORKSTATION` then `CREATE_WORKSTATION`, two operations |
| workbench or notebooks instance | as above with notebook types | | |
| vertex endpoint | `CREATE` | | `DEPLOY_MODEL_ENDPOINT` |
| vertex endpoint | `UPDATE` | `labels.env` or project moved to a higher stage | `PROMOTE_MODEL_ENDPOINT` |
| anything else | any | | `TF_IMPORT_CREATE` / `UPDATE` / `DELETE` |

Start and stop are not Terraform actions, so no `START_WORKSTATION` or `STOP_WORKSTATION` history exists. Current running state comes from the inventory.

### 4.5 Enrich the resource rows

For each resource row created by the Part 2 backfill, where a `tf_resource_instance` matches on `external_id`:

- Set `source_labels` to the union of cloud labels and Terraform-declared labels, keeping the Terraform values where they differ, and record the difference as drift.
- Store the module inputs in a new `provisioning_spec JSONB` column on the resource table. This is the intent the user expressed, as distinct from what the cloud reports. For a workstation it is the tfvars block: machine type, GPU, image, idle timeout, persistent disk.
- Set `reconcile_status` to `DRIFTED` where Terraform's last-applied attributes differ from the current inventory attributes on any field Atlas models. This is out-of-band change: someone edited the resource in the console after Terraform applied it.

```sql
ALTER TABLE workstation ADD COLUMN provisioning_spec JSONB;
ALTER TABLE workstation ADD COLUMN tf_address TEXT;          -- last known Terraform address
ALTER TABLE workstation ADD COLUMN tf_workspace VARCHAR(255);
-- repeat for notebook, ml_workspace, model_endpoint
```

The Terraform address matters after cutover. When Atlas asks the orchestrator to resize an imported workstation, the orchestrator needs to know which Terraform resource to change.

### 4.6 Write

Upsert in this order, each idempotent on the keys shown:

1. `tf_state_snapshot` on `(lineage, serial)`
2. `tf_run` on `(source_system, source_run_ref)`
3. `tf_resource_instance` on `(snapshot_id, address)`
4. `operation` on `(user_id, idempotency_key)`, oldest first so `created_at` ordering matches history
5. `operation_event`, insert only if no event exists for that operation and transition
6. Resource row enrichment on `external_resource_name`

A second run over the same snapshots must change zero rows.

---

## 5. What Terraform cannot tell you, and how to record the gap

| Missing | Why | What to write |
|---|---|---|
| The human requester, when CI applied it | The run system only knows the service account | `user_id` of the `terraform-ci` system user, and `request_payload.requester_unknown = true` |
| Approval history | Approvals happened in a ticketing tool or a PR review, not in Terraform | Nothing. Do not fabricate `AWAITING_APPROVAL` events. If the PR review is retrievable, put the approver in `detail.pr_approved_by`. |
| Sessions | There were none | `session_id = NULL` |
| Runs whose state was never written | A failed plan or an apply that errored before touching state leaves no snapshot | An operation with `status = FAILED` and no `target_entity_id`, from `tf_run` alone |
| Anything before the backend was versioned | No history exists | The first snapshot's resources get a `CREATE` operation dated at that snapshot with `detail.history_truncated = true` |
| Manual `terraform import` or `state mv` | Shows as a create or address change with no cloud-side change | Recognise it when the `id` already existed in an earlier inventory; mark `TF_IMPORT_UPDATE` with `detail.state_only = true` |

---

## 6. Reconciling Terraform against the inventory

Run this after both hydration paths have loaded. Every row is a finding to report, not something to auto-correct.

| Condition | Meaning | Status to set |
|---|---|---|
| In inventory, in state, attributes agree | Healthy Terraform-managed resource | `IN_SYNC` |
| In inventory, in state, attributes differ | Changed in the console after apply | `DRIFTED`, with the differing fields in `detail` |
| In inventory, not in any state | Created outside Terraform: console, gcloud, SDK, or a state that was lost | `ORPHANED`. These are the ones the workshop worried about. Count them by project. |
| In state, not in inventory | Destroyed outside Terraform, or the inventory export lacks permission on that project | `MISSING`. Check the project's IAM before assuming deletion. |
| In state twice under different lineages | Two workspaces both claim the resource | Report. Do not load until resolved. |

The orphaned count per project is the single most useful number this exercise produces. It tells you how much of the estate is already under infrastructure-as-code and therefore how much can be brought under Atlas without a migration.

---

## 7. Keeping it flowing after the baseline

Until every provisioning path goes through Atlas, Terraform will keep being applied by legacy pipelines. Two mechanisms keep the operational metadata current:

1. **Post-apply hook.** Each pipeline that runs `terraform apply` adds a final step that posts `terraform show -json` and the run metadata to an internal ingest endpoint:

   ```
   POST /api/v1/internal/terraform/applies
   Authorization: workload identity of the CI service account
   {
     "sourceSystem": "CLOUD_BUILD",
     "sourceRunRef": "build-7f3a…",
     "workspace": "ds-workbenches-prod",
     "triggeredBy": "ci-terraform@atlas-prod.iam.gserviceaccount.com",
     "commitSha": "…",
     "commitAuthor": "alice@…",
     "scaffolderTask": "task-91c2…",
     "status": "APPLIED",
     "applyStartedAt": "…", "applyFinishedAt": "…",
     "state": { …terraform show -json output… }
   }
   ```

   The endpoint runs steps 4.2 through 4.6 for that single snapshot. The operation rows it creates carry `origin = IMPORTED` and appear in the same lists and audit views as Atlas-originated operations.

2. **Nightly state sweep.** The full collect-and-diff pipeline runs against every backend to catch pipelines that did not adopt the hook. Anything it finds that the hook missed is reported, so the missing hook gets added.

When a legacy pipeline is retired and its resources are provisioned through Atlas instead, its workspace is marked closed in a small `tf_workspace` registry table and the sweep stops expecting it.

---

## 8. Acceptance for the Terraform hydration

| Check | Pass condition |
|---|---|
| Snapshot coverage | Every state generation in every backend has a `tf_state_snapshot` row |
| Serial continuity | Within a lineage, serials are contiguous; gaps are listed |
| Run join rate | At least 90 percent of snapshots joined to a `tf_run` with a requester |
| Requester resolution | Percentage of operations with a human `user_id` versus `terraform-ci`, reported by workspace |
| Operation conservation | Non-no-op `tf_resource_instance` rows equal `operation` rows with a `tf:` idempotency key, allowing two for each `REPLACE` |
| Event shape | Every imported operation has exactly the three events, in timestamp order |
| Cross-check with inventory | Every Terraform-managed workstation in the current inventory has a `CREATE` operation older than its inventory `create_time` plus clock skew |
| Idempotency | A second run over the same snapshots changes zero rows |
| Orphan report | Published: inventory resources with no Terraform history, by project and type |

---

## 9. Decisions to make before running

- **Which backend history exists.** If the GCS bucket has no object versioning, you have current state only and no timeline. Turn versioning on today regardless, so history accrues from now.
- **Which run system is authoritative** where more than one applied to the same workspace over time.
- **Whether `terraform-ci` is an acceptable requester** for old operations, or whether the team wants a one-off effort to backfill requesters from PR history.
- **The Terraform address contract with the orchestrator.** Atlas will store `tf_address` and `tf_workspace` on imported resources. The orchestrator needs to accept them as the handle for changing an imported resource, or provide its own handle that Atlas stores instead.
