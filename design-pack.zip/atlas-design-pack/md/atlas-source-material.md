# Atlas Source Material (text transcription)

Text transcription of the inputs this design pack was built from, so they can be read in an environment without image or PDF tooling.

- **Section A** transcribes the 15 Confluence screenshots in `matlas-session/` (dated 3 September 2026): the workshop summary, open questions, entity model, PostgreSQL DDL, and storage comparison.
- **Section B** summarises the Gemini chat export `Atlas ML Platform Architecture Review.pdf` (15 pages), including its proposed session DDL and API table, and the review notes on it.

Where a screenshot was partially cut off, the gap is marked. Nothing here has been "improved"; the design documents in this pack are where changes are proposed.

---

# Section A: Confluence page "Atlas Entity Model and Storage"

## A.1 Page introduction

> As an API-first service that provides a level of abstraction over the underlying infrastructure services, Atlas needs to store certain business and technical data related to the use case in order to orchestrate and manage Atlas resources. This page describes the entity model and storage for such data.

**Atlas Entity Model.** This section describes the entities comprising the Atlas data model and their relationships. It should be considered a living document and will be updated as the data model matures.

**Updates.** A number of user journey workshops with the Atlas product and engineering team have been run to drive out some of the detailed requirements and refine the entity model.

## A.2 Workshop: Atlas Onboarding and Atlas Experiment (30 Jul 2026)

The following is based on the Copilot summary of the workshop transcript, with key points highlighted. The summary has been reviewed and corrected for errors. (Highlighted phrases are marked **[H]** below.)

The discussion focused on how users, business units, use cases, ML workspaces, workbenches, approvals, and self-serve provisioning should work in the Atlas user journey. A major theme was whether Atlas should rely on information from identity/SSO/AD claims to infer business unit membership, or whether Atlas needs its own manual or semi-automated onboarding and approval process.

### User onboarding and business unit assignment

Users may need to be assigned to a business unit before they can work within Atlas. There was uncertainty about whether the business unit could be inferred automatically from identity/SSO/AD claims, or whether Atlas would need manual onboarding initially. **[H]** If claims do not provide reliable business unit information, Atlas may need to store mappings between users and business units itself, potentially through manual entries at first.

Approval routes: one proposed flow was that a user selects a business unit and an approval request is sent to a business approver. The group considered whether approval should happen through Atlas screens, email replies, ServiceNow integration, or another process. **[H]** ServiceNow was mentioned as a possible future integration rather than a day-one dependency.

### Use case ownership and access model

**[H]** Use cases should always be owned by a business unit, but users working on those use cases may come from the same business unit or from CDAO teams. The discussion explored whether users should request access to a use case themselves or whether access should be driven by the use case owner. **[H]** The direction leaned towards the use case owner managing access, because they should be accountable for who works on the use case and for joiner, mover, leaver and recertification-style processes.

The call also raised the need to support multiple owners for a use case, so that access management does not block when a single owner is unavailable.

### Views, labels and grouping of use cases

A flat list of use cases would not work well for business units that have many experiments or workstreams. The group discussed folders, labels, business segments, or one-level filtering. **[H]** Labels may be a more flexible approach than rigid folders, particularly if different business units want to group work differently. **[H]** Day one may only need one level of grouping or filtering, with extensibility for more complex views later.

### Workspace, workbench and terminology

The term "workspace" is overloaded. In the call it described a logical container for experiment tools and resources, but this may conflict with existing IDP or platform terminology. Alternatives such as "**[H]** ML workspace", "project", "experiment" were discussed; no final name was settled.

There is a distinction between a logical ML workspace and actual compute environments such as workbenches, workstations, notebooks or VS Code environments.

In the meeting chat, Buchanan, Donald asked whether users can have more than one workbench, noting that some users currently have a small workbench and a GPU workbench. He also noted that GPU use may need approval due to cost, with later chat clarifying GPU reservation considerations. **[H]** A user may need more than one workbench for a single use case, for example a smaller workbench and a GPU-backed workbench.

### Workbench provisioning and self-service

Should workbenches be provisioned automatically when a user is added to a use case, or created by users on first access? **[H]** The discussion moved towards creating the use case and logical workspace first, while the actual workbench creation could be self-service from the "view use case" experience.

Whether users should be able to change or resize workbenches after creation: some participants wanted flexibility to amend size, location or GPU capability, but each additional action implies additional API logic, state management and rules.

### API and provisioning implications

The conversation covered the split between experience APIs, implementation APIs and orchestrator APIs. The described flow: a user action in Atlas calls an experience API, which calls an implementation API, which then calls an orchestrator API that may plug values into Terraform and run provisioning.

A major friction point was approval in the Terraform or deployment process. **[H]** If every provisioning action requires manual cloud platform approval, that would be problematic for user experience and scalability, especially for frequent actions such as adding or resizing workbenches.

### Integration with Envoy, Model Risk and broader A&AI services

Atlas should not necessarily be isolated from other Agentic & AI services. Envoy and agent use cases were discussed where a user may need both model development and agent-building capabilities. A broader shared abstraction around use cases was raised, so that other services might consume or reuse Atlas APIs or data.

Model Risk was mentioned; current Model Risk processes were described as SharePoint-based and not API-enabled. **[H]** Integration with Model Risk may be sensible later, but not necessarily as the starting point for early experiments.

### Data access and EDP risks

**[H]** Data access through EDP was identified as a significant unresolved risk. Uncertainty around how Atlas users would get access to the right data, whether views need to be created, and how business unit membership maps to EDP access models. Concern that users could end up with a platform or pipeline but no usable data. The EDP access model was not yet clear enough and this could be one of the biggest risks to the Atlas journey.

### Logging, audit and operational concerns

Where logs would go, how users access their own logs, how logs are segregated, whether logs might contain sensitive data. Business unit-level logging, log sinks, blast radius, governance, and potential scanning of logs for sensitive content.

### DS persona and console access

**[H]** If users retain broad permissions in VS Code or console, they may bypass the Atlas APIs and undermine the controlled self-serve model. **[H]** Permissions may eventually need to be reduced if more actions are intended to go through APIs rather than direct Google console or gcloud access.

Risk-specific persona needs were discussed, including whether Risk users might need more restricted capabilities than general data scientists. This likely needs a separate follow-up workshop.

### Key open questions captured from the call

- Can business unit membership be inferred from Identity/SSO/AD claims, or does Atlas need its own mapping and approval process?
- Should user access be request-driven or use case owner-driven? The discussion leant towards owner-driven access.
- Should use cases support multiple owners? Raised as a need to avoid dependency on one person.
- Should Atlas support folders, labels, or one-level filtering for grouping use cases?
- What should the logical "workspace" concept be called to avoid confusion with existing platform terminology?
- Should workbenches be provisioned automatically, or created by users on demand?
- Can users create multiple workbenches for the same use case, including GPU-backed workbenches? The transcript indicates this is a realistic requirement.
- How will GPU approvals, reservations and spend controls work?
- How can provisioning avoid manual approval bottlenecks in Terraform or cloud platform workflows?
- How will Atlas align with Envoy, Model Risk and broader A&AI use case abstractions?
- How will EDP data access be made usable for Atlas users?
- How will logs be segregated, accessed and governed?
- What happens to DS persona and console access in a future API-led Atlas model?

### Changes made as a result of the workshop

- Entity model updated to remove Notebook and add Workstation as a day one feature, on the basis that (1) a Notebook is the logical abstraction of a Jupyterlab notebook, in any hosting environment, (2) Vertex Workbench is currently being used as the hosting environment for a cloud-hosted VS Code IDE, which could later be replaced with a different *implementation* using Cloud Workstations, once curated.

> Note: despite this statement, the ERD and DDL on the page still contain Notebook and NotebookSpec alongside Workstation and Workstation Configuration.

## A.3 Entity relationship diagram

As drawn on the page. For brevity, the diagram omits common fields such as status fields used for soft deletes and modification timestamps.

```mermaid
erDiagram
    ROLE ||--o{ USER : "role"
    USER ||--o{ BUSINESS_UNIT : "owner"
    BUSINESS_UNIT ||--o{ USE_CASE : "businessUnitId"
    USE_CASE ||--o{ EXPERIMENT : "useCaseId"
    USE_CASE ||--o{ ML_WORKSPACE : "useCaseId"
    USER ||--o{ ML_WORKSPACE : "owner"
    ML_WORKSPACE ||--o{ NOTEBOOK : "workspaceId"
    ML_WORKSPACE ||--o{ WORKSTATION : "mlWorkspace"
    NOTEBOOK }o--|| NOTEBOOK_SPEC : "notebookSpecJson"
    WORKSTATION }o--|| WORKSTATION_CONFIGURATION : "configuration"
    EXPERIMENT ||--o{ PIPELINE_JOB : "experimentId"
    EXPERIMENT ||--o{ MODEL_ENDPOINT : "experiment"
    PIPELINE_JOB }o--|| PIPELINE_TEMPLATE : "templateId"
    PIPELINE_JOB ||--o{ MODEL : "pipelineJob"
    MODEL }o--o| MODEL_ENDPOINT : "modelEndpoint"
    MODEL_ENDPOINT }o--|| RTL_STAGE : "rtlStage"
    MODEL_ENDPOINT }o--o| APPLICATION : "applicationId (TBD)"
    RTL_STAGE |o--o| RTL_STAGE : "nextStage / prevStage"

    ROLE { enum roleEnum PK
           string name
           string description }
    USER { uuid userId PK
           string principalEmail
           string name
           string staffId
           enum role FK }
    BUSINESS_UNIT { uuid businessUnitId PK
                    uuid owner FK
                    string name }
    USE_CASE { uuid useCaseId PK
               uuid businessUnitId FK
               string name
               string costCentre }
    ML_WORKSPACE { uuid mlWorkspaceId PK
                   uuid useCaseId FK
                   enum hostingEnv
                   uuid owner FK }
    NOTEBOOK { uuid notebookId PK
               uuid workspaceId FK
               enum implementation
               string url
               uuid notebookSpecJson FK }
    NOTEBOOK_SPEC { uuid notebookSpecId PK
                    int cpuCount
                    string memory
                    string container
                    int gpuCount }
    WORKSTATION { uuid workstationId PK
                  uuid mlWorkspace FK
                  enum implementation
                  string url
                  string launchUrl
                  uuid configuration FK }
    WORKSTATION_CONFIGURATION { uuid workstationConfigId PK
                                int cpuCount
                                string memory
                                string container
                                int gpuCount }
    EXPERIMENT { uuid experimentId PK
                 uuid useCaseId FK
                 string name }
    PIPELINE_TEMPLATE { uuid pipelineTemplateId PK
                        string templateUrl
                        string name
                        string description }
    PIPELINE_COMPONENT { uuid pipelineComponentId PK
                         string pipelineComponentUrl
                         string componentType
                         string name
                         string description }
    PIPELINE_JOB { uuid pipelineJobId PK
                   uuid templateId FK
                   uuid experimentId FK
                   timestamp timestamp
                   string jobIdentifier }
    MODEL { uuid modelId PK
            json registrationInfoJson
            enum onlineOrBatch
            string version
            uuid modelEndpoint FK
            uuid pipelineJob FK }
    MODEL_ENDPOINT { uuid modelEndpointId PK
                     uuid experiment FK
                     string inferenceUrl
                     enum rtlStage FK
                     uuid applicationId FK
                     json containerSpec
                     json computeSpec }
    RTL_STAGE { enum stageId PK
                string name
                enum nextStage FK
                enum prevStage FK }
    APPLICATION { uuid applicationId PK
                  string alNumber }
```

Pipeline Component is drawn on the diagram without a relationship line; the DDL connects it to Pipeline Template through a bridge table.

### Notes on relationships (as written on the page)

1. A Use Case is owned and developed by a Business Unit (e.g. Consumer Lending, Risk).
2. A Team Member has 1 or more ML Workspaces.
3. An ML Workspace is associated with exactly one Use Case.
4. An ML Workspace may contain 1 or more Notebooks and/or Workstations.
5. A Notebook is the abstraction of a Jupyter notebook-type environment. A Workstation is an abstraction of a managed IDE, such as Cloud Workstations.
6. A Use Case can have 1 or more Experiments.
7. A data scientist may (from a Notebook or Workstation) run a Pipeline Job that uses a Pipeline Template. That could be through a REST API (e.g. `POST /atlas/useCases/1234/experiments/4567/pipelineJobs`) or, ultimately, a Python SDK (e.g. `atlas.pipelines.run({...})`).
8. A Pipeline Template may be composed of multiple reusable Pipeline Components.
9. Running a Pipeline Job creates a Model (should this be split into a Model Artefact and a Model Version?)
10. A Model can be served through a Model Endpoint (does this work for Batch Prediction models?). This Model Endpoint belongs to the Experiment.
11. Promoting an Experiment to Data Test would promote the Model and Model Endpoint entities. Promoting to Data Run would promote the Model and Model Endpoint entities and link these to an Application entity.

## A.4 PostgreSQL DDL (as on the page)

> Cloud SQL for PostgreSQL is the standard relational database service for workloads on Google Cloud, except where required to support Cat A services with strong consistency across two or more regions. The following provides an implementation of the above logical schema for PostgreSQL v16 or v17.

```sql
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================================
-- ENUMS
-- ============================================================================

CREATE TYPE hosting_environment_enum AS ENUM (
    'GCP',
    'AZURE',
    'ON_PREMISES'
);

CREATE TYPE implementation_type_enum AS ENUM (
    'JUPYTER',
    'VSCODE',
    'CUSTOM'
);

CREATE TYPE model_execution_mode_enum AS ENUM (
    'ONLINE',
    'BATCH'
);

-- ============================================================================
-- CORE / IDENTITY TABLES
-- ============================================================================

CREATE TABLE role (
    role_id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE "user" (
    user_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    principal_email VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    staff_id VARCHAR(50),
    role_id VARCHAR(50) NOT NULL REFERENCES role(role_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

-- Partial Unique Indexes for soft-delete safety
CREATE UNIQUE INDEX uq_user_principal_email_active ON "user"(principal_email) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX uq_user_staff_id_active ON "user"(staff_id) WHERE deleted_at IS NULL AND staff_id IS NOT NULL;

CREATE TABLE business_unit (
    business_unit_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    owner_id UUID NOT NULL REFERENCES "user"(user_id) ON DELETE RESTRICT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE use_case (
    use_case_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_unit_id UUID NOT NULL REFERENCES business_unit(business_unit_id) ON DELETE RESTRICT,
    name VARCHAR(255) NOT NULL,
    cost_centre VARCHAR(100) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

-- ============================================================================
-- WORKSPACE & COMPUTE CONFIGURATION
-- ============================================================================

CREATE TABLE ml_workspace (
    ml_workspace_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    use_case_id UUID NOT NULL REFERENCES use_case(use_case_id) ON DELETE RESTRICT,
    owner_id UUID NOT NULL REFERENCES "user"(user_id) ON DELETE RESTRICT,
    hosting_env hosting_environment_enum NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE notebook_spec (
    notebook_spec_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    cpu_count INT NOT NULL CHECK (cpu_count > 0),
    memory VARCHAR(50) NOT NULL,
    container VARCHAR(255) NOT NULL,
    gpu_count INT DEFAULT 0 NOT NULL CHECK (gpu_count >= 0),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE notebook (
    notebook_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL REFERENCES ml_workspace(ml_workspace_id) ON DELETE RESTRICT,
    notebook_spec_id UUID NOT NULL REFERENCES notebook_spec(notebook_spec_id) ON DELETE RESTRICT,
    implementation implementation_type_enum NOT NULL,
    url TEXT NOT NULL,
    notebook_spec_json JSONB,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE workstation_configuration (
    workstation_config_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    cpu_count INT NOT NULL CHECK (cpu_count > 0),
    memory VARCHAR(50) NOT NULL,
    container VARCHAR(255) NOT NULL,
    gpu_count INT DEFAULT 0 NOT NULL CHECK (gpu_count >= 0),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE workstation (
    workstation_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ml_workspace_id UUID NOT NULL REFERENCES ml_workspace(ml_workspace_id) ON DELETE RESTRICT,
    workstation_config_id UUID NOT NULL REFERENCES workstation_configuration(workstation_config_id) ON DELETE RESTRICT,
    implementation implementation_type_enum NOT NULL,
    url TEXT NOT NULL,
    launch_url TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

-- ============================================================================
-- PIPELINES, TEMPLATES & COMPONENTS
-- ============================================================================

CREATE TABLE pipeline_template (
    pipeline_template_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    template_url TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE pipeline_component (
    pipeline_component_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    component_type VARCHAR(100) NOT NULL,
    pipeline_component_url TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

-- Bridge entity for pipeline template DAG components
CREATE TABLE pipeline_template_component (
    pipeline_template_id UUID NOT NULL REFERENCES pipeline_template(pipeline_template_id) ON DELETE RESTRICT,
    pipeline_component_id UUID NOT NULL REFERENCES pipeline_component(pipeline_component_id) ON DELETE RESTRICT,
    execution_order INT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL,
    PRIMARY KEY (pipeline_template_id, pipeline_component_id)
);

CREATE TABLE experiment (
    experiment_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    use_case_id UUID NOT NULL REFERENCES use_case(use_case_id) ON DELETE RESTRICT,
    name VARCHAR(255) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE pipeline_job (
    pipeline_job_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    template_id UUID NOT NULL REFERENCES pipeline_template(pipeline_template_id) ON DELETE RESTRICT,
    experiment_id UUID NOT NULL REFERENCES experiment(experiment_id) ON DELETE RESTRICT,
    timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    job_identifier VARCHAR(255) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

CREATE UNIQUE INDEX uq_pipeline_job_identifier_active ON pipeline_job(job_identifier) WHERE deleted_at IS NULL;

-- ============================================================================
-- STAGING, APPLICATIONS & ENDPOINTS
-- ============================================================================

CREATE TABLE rtl_stage (
    stage_id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    next_stage_id VARCHAR(50) REFERENCES rtl_stage(stage_id) ON DELETE RESTRICT,
    prev_stage_id VARCHAR(50) REFERENCES rtl_stage(stage_id) ON DELETE RESTRICT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE application (
    application_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    al_number VARCHAR(100) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

CREATE UNIQUE INDEX uq_application_al_number_active ON application(al_number) WHERE deleted_at IS NULL;

CREATE TABLE model_endpoint (
    model_endpoint_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    experiment_id UUID NOT NULL REFERENCES experiment(experiment_id) ON DELETE RESTRICT,
    rtl_stage_id VARCHAR(50) NOT NULL REFERENCES rtl_stage(stage_id) ON DELETE RESTRICT,
    application_id UUID REFERENCES application(application_id) ON DELETE RESTRICT,
    inference_url TEXT NOT NULL,
    container_spec JSONB,
    compute_spec JSONB,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE model (
    model_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    model_endpoint_id UUID REFERENCES model_endpoint(model_endpoint_id) ON DELETE RESTRICT,
    pipeline_job_id UUID REFERENCES pipeline_job(pipeline_job_id) ON DELETE RESTRICT,
    version VARCHAR(50) NOT NULL,
    online_or_batch model_execution_mode_enum NOT NULL,
    registration_info_json JSONB,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

-- ============================================================================
-- PERFORMANCE INDEXES (Filtered on active records)
-- ============================================================================

CREATE INDEX idx_user_role ON "user"(role_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_business_unit_owner ON business_unit(owner_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_use_case_business_unit ON use_case(business_unit_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_ml_workspace_use_case ON ml_workspace(use_case_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_ml_workspace_owner ON ml_workspace(owner_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_notebook_workspace ON notebook(workspace_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_notebook_spec ON notebook(notebook_spec_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_workstation_workspace ON workstation(ml_workspace_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_workstation_config ON workstation(workstation_config_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_experiment_use_case ON experiment(use_case_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_pipeline_job_experiment ON pipeline_job(experiment_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_pipeline_job_template ON pipeline_job(template_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_model_endpoint_experiment ON model_endpoint(experiment_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_model_endpoint_stage ON model_endpoint(rtl_stage_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_model_endpoint_app ON model_endpoint(application_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_model_pipeline_job ON model(pipeline_job_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_model_endpoint ON model(model_endpoint_id) WHERE deleted_at IS NULL;
```

Observations recorded during transcription (not changes):

- `notebook` carries both a `notebook_spec_id` foreign key and a `notebook_spec_json` JSONB column.
- `use_case` has no owner column and there is no user-to-use-case or user-to-business-unit membership table, although the workshop asked for owner-managed access and multiple owners.
- Neither `workstation` nor `ml_workspace` has a lifecycle or status column beyond soft delete.

## A.5 Data Storage Service

> The above entity relationships will map to the database schema design and align with the proposed database technologies proposed. The service must align with the Technology Resilience Framework.

Comparison between the two primary technologies considered for the Atlas Product use case:

1. Cloud SQL (Postgres) - Enterprise Plus
2. Cloud Spanner

| Feature/Requirement | Google Cloud SQL (Postgres) | Google Cloud Spanner |
|---|---|---|
| Scalability | Scaling can be configured both for read and write. Write scalability (vertical) is via adding more compute power to the primary instance as required. Read scaling (horizontal) is via adding read-replicas in additional regions. | Scales horizontally for both read and write operations automatically across multiple regions. |
| DR and Resilience | Requires configuring a cross-region replica and supports automated backups. | Automatic replication across multi-regions (when configured to do so). |
| High Availability | HA configuration possible through multi-zone in the same region. | HA provided by the distributed architecture model within regions. |
| Security | Meets LBG requirements as a curated product. | Meets LBG requirements as a curated product. |
| Latency | Typically low. | Typically low. |
| Data Suitability | Suitable for API and configuration data including JSON. | Suitable for API and configuration data including JSON. |
| Request Volume | Typically not an issue unless very high volumes. | Typically not an issue. |
| Cost | Low starting cost, cost increases per replica. | Higher starting cost. |
| Complexity | In use currently within Atlas 1 and familiar to the existing teams. | May require additional effort to understand and configure both the service and the required integrations. |

---

# Section B: Gemini chat export "Atlas ML Platform Architecture Review"

Source: `Atlas ML Platform Architecture Review.pdf`, 15 pages, exported from https://gemini.google.com/app/79a441213cadf935. The same screenshots above were fed to Gemini.

## B.1 Prompts in order

1. "consume this first" (screenshots batch 1). Gemini acknowledged.
2. "These too" (screenshots batch 2). Gemini listed what it had consumed: DDL and indexing strategy, storage decision, pipeline and execution entities.
3. "Did you read the ER diagram?" Gemini restated the relationships (identity and governance, workspaces and compute, pipelines and experiments, models and endpoints). It noted "Notebook is slated for removal in favor of standardizing on Workstation."
4. "We're planning to build a database in cloud sql to act as a persistent store for sessio information, we will have apis build that will talk to these tables, I also want to think of these api functions/calls that will CRUD into the sql databases, I want your thoughts"
5. "Now you know the data model, the relationships, I want you to document a clear markdown with the actions, how they translate into api calls that read/write the session information from the database"

## B.2 Gemini's response to prompt 4 (summary)

Key architectural considerations: high-frequency writes versus connection limits (use Cloud SQL Managed Connection Pooling or PgBouncer; consider Memorystore for ephemeral state), schema granularity (relational metadata plus JSONB context), soft deletes versus auto-expiry (`deleted_at` plus `expires_at` with pg_cron sweeps).

Proposed table (version 1):

```sql
CREATE TABLE session (
    session_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES "user"(user_id) ON DELETE RESTRICT,
    use_case_id UUID REFERENCES use_case(use_case_id) ON DELETE RESTRICT,
    workstation_id UUID REFERENCES workstation(workstation_id) ON DELETE SET NULL,
    session_token_hash VARCHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'ACTIVE', -- ACTIVE, EXPIRED, REVOKED
    context_data JSONB DEFAULT '{}'::jsonb,
    ip_address INET,
    user_agent TEXT,
    last_heartbeat_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);
CREATE UNIQUE INDEX uq_session_token_active ON session(session_token_hash) WHERE deleted_at IS NULL;
CREATE INDEX idx_session_user_active ON session(user_id, expires_at) WHERE deleted_at IS NULL AND status = 'ACTIVE';
CREATE INDEX idx_session_expiry ON session(expires_at) WHERE deleted_at IS NULL AND status = 'ACTIVE';
```

API table (version 1):

| Operation | Route | DB | Behaviour |
|---|---|---|---|
| Create Session | `POST /v1/sessions` | INSERT | Validates user and compute constraints, computes `expires_at`, stores token hash and initial context |
| Get Session | `GET /v1/sessions/{id}` | SELECT | Active, non-expired only |
| List User Sessions | `GET /v1/users/{id}/sessions` | SELECT | Security audit, concurrency, multi-device |
| Update Context | `PATCH /v1/sessions/{id}` | UPDATE | JSONB merge with `\|\|` |
| Heartbeat / Touch | `POST /v1/sessions/{id}/touch` | UPDATE | Rolls `expires_at` forward; debounce to once per 60 s |
| Revoke / End | `DELETE /v1/sessions/{id}` | UPDATE | Soft delete, status REVOKED |
| Evict Expired | internal worker / cron | UPDATE | Batch status EXPIRED where `expires_at < NOW()` |

Gemini then asked two clarifying questions that were not answered in the chat: (1) are these interactive developer sessions, end-user auth tokens, or pipeline execution state machines; (2) expected write frequency.

## B.3 Gemini's response to prompt 5 (summary)

Document titled "Atlas ML Platform: Session State Persistence & API Specification". It assumed sessions are interactive workstation sessions.

Version 2 of the table replaced the VARCHAR status with an enum and made `use_case_id` NOT NULL:

```sql
CREATE TYPE session_status_enum AS ENUM ('INITIALIZING', 'ACTIVE', 'IDLE', 'TERMINATED', 'EXPIRED');

CREATE TABLE session (
    session_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES "user"(user_id) ON DELETE RESTRICT,
    use_case_id UUID NOT NULL REFERENCES use_case(use_case_id) ON DELETE RESTRICT,
    workstation_id UUID REFERENCES workstation(workstation_id) ON DELETE RESTRICT,
    session_token_hash VARCHAR(64) NOT NULL,
    status session_status_enum DEFAULT 'INITIALIZING' NOT NULL,
    session_data JSONB DEFAULT '{}'::jsonb NOT NULL,
    client_ip INET,
    user_agent TEXT,
    last_heartbeat_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMPTZ DEFAULT NULL
);

CREATE UNIQUE INDEX uq_session_token_active ON session(session_token_hash) WHERE deleted_at IS NULL;
CREATE INDEX idx_session_user_active ON session(user_id, expires_at) WHERE deleted_at IS NULL AND status IN ('INITIALIZING', 'ACTIVE', 'IDLE');
CREATE INDEX idx_session_workstation_active ON session(workstation_id) WHERE deleted_at IS NULL AND status IN ('INITIALIZING', 'ACTIVE', 'IDLE');
CREATE INDEX idx_session_use_case ON session(use_case_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_session_reaper_sweep ON session(expires_at) WHERE deleted_at IS NULL AND status NOT IN ('TERMINATED', 'EXPIRED');
```

Seven actions, each with route, payload, and SQL:

| # | Action | Route | SQL essentials |
|---|---|---|---|
| 1 | Start workstation session / launch IDE | `POST /api/v1/sessions` | INSERT with status `'ACTIVE'`, `expires_at = now + 8 hours`; returns 201 with token |
| 2 | Session validation and state hydration | `GET /api/v1/sessions/current` (bearer token) | SELECT joining user, use_case, workstation WHERE token hash matches AND `status = 'ACTIVE'` AND not expired; 401 otherwise |
| 3 | Client heartbeat / keep-alive | `POST /api/v1/sessions/{id}/heartbeat` with body `{"status": "ACTIVE"}` | UPDATE `last_heartbeat_at`, `expires_at = now + 8 hours`, `status = $2` WHERE status NOT IN (TERMINATED, EXPIRED); debounced 60 s |
| 4 | Patch session context | `PATCH /api/v1/sessions/{id}/context` | UPDATE `session_data = session_data \|\| $2::jsonb` WHERE `status = 'ACTIVE'` |
| 5 | Query active sessions by user | `GET /api/v1/users/{userId}/sessions?status=ACTIVE` | SELECT with LEFT JOIN to workstation_configuration for `gpu_count`; `status = 'ACTIVE'` |
| 6 | Graceful logout / teardown | `DELETE /api/v1/sessions/{id}` | UPDATE `status = 'TERMINATED'`, `deleted_at = now` |
| 7 | Background TTL reaper | scheduled, every 5 to 15 minutes | UPDATE `status = 'EXPIRED'` WHERE status IN (INITIALIZING, ACTIVE, IDLE) AND expired |

Closing recommendations: connection pooling in transaction mode; route reads to replicas if volume grows; partition `session` by month if history must be kept.

## B.4 Review notes on the Gemini design (why the pack diverges from it)

- **Scope was assumed, not confirmed.** Gemini's own question about whether a session is an IDE connection, an auth token, or an execution state machine went unanswered. It designed for IDE keep-alive sessions. The pack instead models the user's operational context plus an operation ledger, because the actual need is durable provisioning state across GKE pod restarts.
- **Status handling was inconsistent.** Default `INITIALIZING` but the insert wrote `ACTIVE`. Validation and context patch required `ACTIVE` while heartbeat and the indexes treated `IDLE` as live, so an idle user would fail validation.
- **The heartbeat let the client set status** from the request body, allowing any enum value to be written.
- **The JSONB `||` merge is shallow**, replacing top-level keys, though described as a deep merge.
- **The workstation index was not unique** despite the comment claiming it enforced a single-tenant lock.
- **Token hashes were stored** although identity comes from SSO upstream, so Atlas does not need to be a token store.
- **No modelling of the provisioning call itself**: nothing recorded the request to the orchestrator, its retries, or its outcome. That gap is what the `operation` and `operation_event` tables in the pack fill.
