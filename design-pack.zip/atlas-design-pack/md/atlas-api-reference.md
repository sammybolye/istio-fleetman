# Atlas Experience API Reference

**Part 3 of the session persistence spec.** This closes the gaps in section 6 of [atlas-session-persistence-spec.md](atlas-session-persistence-spec.md): every session route with request and response bodies, the routes that were missing, an error table, the context contract, a concurrency rule, a session audit trail, and the admin routes for reconciliation. A machine-readable version is in [openapi/atlas-experience-api.yaml](../openapi/atlas-experience-api.yaml).

---

## 1. Conventions

| Item | Rule |
|---|---|
| Base path | `/api/v1` |
| Content type | `application/json; charset=utf-8` on every request and response body |
| Identity | Injected by the edge after SSO as `X-Atlas-Principal` (email) and `X-Atlas-Principal-Groups`. The API never reads a password or SSO token. Requests without the header are rejected with `401` before routing. |
| Session header | `X-Atlas-Session-Id` (UUID). Optional on every route. When present, the API verifies the session belongs to the principal and is live, and stamps `session_id` on any operation created. When absent on a route that needs one, the API creates a session. |
| Idempotency | `Idempotency-Key` (1 to 128 chars, client-generated, UUID recommended). **Required** on every `POST`, `PATCH`, and `DELETE` except the two below. A replay with the same key and same body returns the original result with `Idempotent-Replayed: true`. Same key with a different body returns `409 IDEMPOTENCY_KEY_REUSED`. Keys are scoped per user and retained 24 hours for session routes, indefinitely for operations. |
| Idempotency exemptions | `POST /sessions/{id}/heartbeat` is idempotent by nature and takes no key. `POST /sessions` accepts an optional key; without one, a network retry may create a second session, which the concurrency rule then bounds. |
| Request ID | Every response carries `X-Request-Id`. Errors echo it in the body. |
| Pagination | `?limit=` (default 50, max 200) and `?cursor=`. Responses carry `nextCursor` or `null`. Cursors are opaque and expire after one hour. |
| Timestamps | RFC 3339 UTC, millisecond precision. |
| Field naming | camelCase in JSON, snake_case in the database. The mapping is mechanical. |
| Authorisation levels | `SELF` (the resource belongs to the principal), `USE_CASE_OWNER` (principal owns the use case in scope), `PLATFORM_ADMIN` (role), `SYSTEM` (workload identity of an internal job). Each route states the minimum. |

### 1.1 Error envelope

```json
{
  "error": {
    "code": "SESSION_GONE",
    "message": "Session d290f1ee-… ended at 2026-09-07T12:04:11.020Z.",
    "details": { "status": "ENDED" },
    "requestId": "8c6f3e2a-…"
  }
}
```

### 1.2 Error table

| HTTP | `code` | When |
|---|---|---|
| 400 | `VALIDATION_FAILED` | Body or query fails schema. `details.fields` lists offenders. |
| 400 | `CONTEXT_REJECTED` | Session context violates the contract in section 3. `details.reason` says why. |
| 401 | `UNAUTHENTICATED` | Missing or unverifiable principal header. |
| 403 | `FORBIDDEN` | Principal lacks the level the route requires, or the session header belongs to another user. |
| 404 | `NOT_FOUND` | Resource does not exist or is soft-deleted and the caller is not an admin. |
| 409 | `IDEMPOTENCY_KEY_REUSED` | Same key, different body. |
| 409 | `INVALID_STATE` | Transition not allowed from the current status, for example cancelling a running operation. `details.currentStatus`. |
| 409 | `SESSION_LIMIT` | Concurrency rule in section 4 could not free a slot. |
| 410 | `SESSION_GONE` | Session exists but is `ENDED` or `EXPIRED`. Client should start a new one. |
| 422 | `POLICY_DENIED` | Request is well-formed but policy forbids it, for example GPU count above the use case cap. |
| 429 | `RATE_LIMITED` | Per-principal limit hit. `Retry-After` header set. |
| 503 | `UPSTREAM_UNAVAILABLE` | Database or orchestrator unreachable. Safe to retry with the same idempotency key. |

---

## 2. Session resource

```json
{
  "sessionId": "d290f1ee-6c54-4b01-90e6-d701748f0851",
  "userId": "7c9e6679-7425-40de-944b-e07fc1f90ae7",
  "principalEmail": "alice@example.com",
  "useCaseId": "a1b2c3d4-e5f6-7a8b-9c0d-1e2f3a4b5c6d",
  "useCaseName": "Consumer Lending Affordability",
  "mlWorkspaceId": "9b1e2f3a-…",
  "status": "ACTIVE",
  "clientType": "WEB",
  "context": { "lastViewedExperimentId": "3fa85f64-…", "useCaseFilter": ["risk"] },
  "startedAt": "2026-09-07T09:00:00.000Z",
  "lastSeenAt": "2026-09-07T09:41:12.515Z",
  "expiresAt": "2026-09-07T21:41:12.515Z",
  "endedAt": null,
  "endReason": null,
  "inFlightOperations": 1,
  "links": {
    "self": "/api/v1/sessions/d290f1ee-…",
    "operations": "/api/v1/operations?sessionId=d290f1ee-…",
    "events": "/api/v1/sessions/d290f1ee-…/events"
  }
}
```

`clientIp` and `userAgent` are stored but returned only to `PLATFORM_ADMIN`.

### 2.1 Schema additions this reference introduces

```sql
-- Why a session ended
CREATE TYPE session_end_reason_enum AS ENUM (
    'USER',               -- DELETE by the owner
    'ADMIN',              -- forceEnd by an admin
    'EXPIRED',            -- reaper, expires_at passed
    'CONCURRENCY_LIMIT',  -- ended to make room for a new session of the same user
    'USER_DEACTIVATED'    -- leaver sync soft-deleted the user
);
ALTER TABLE session ADD COLUMN end_reason session_end_reason_enum;

-- Session audit trail. Heartbeats are NOT logged; status and context changes are.
CREATE TABLE session_event (
    session_event_id  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id        UUID NOT NULL REFERENCES session(session_id) ON DELETE RESTRICT,
    event_type        VARCHAR(30) NOT NULL,        -- STARTED | CONTEXT_CHANGED | IDLE | RESUMED | ENDED | EXPIRED
    from_status       session_status_enum,
    to_status         session_status_enum,
    actor             VARCHAR(255) NOT NULL,       -- principal email, 'atlas-reaper', admin email
    detail            JSONB NOT NULL DEFAULT '{}'::jsonb,  -- e.g. {"useCaseId": {"from": ..., "to": ...}}
    created_at        TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_session_event_type CHECK (event_type IN
        ('STARTED', 'CONTEXT_CHANGED', 'IDLE', 'RESUMED', 'ENDED', 'EXPIRED'))
);
CREATE INDEX idx_session_event_session ON session_event(session_id, created_at);

-- Idempotency replay store for session routes (operations use their own key column)
CREATE TABLE idempotency_key (
    user_id         UUID NOT NULL REFERENCES "user"(user_id) ON DELETE RESTRICT,
    idempotency_key VARCHAR(128) NOT NULL,
    route           VARCHAR(100) NOT NULL,
    request_hash    CHAR(64) NOT NULL,             -- sha256 of canonical body
    response_status SMALLINT NOT NULL,
    response_body   JSONB NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at      TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (user_id, idempotency_key)
);
CREATE INDEX idx_idempotency_expiry ON idempotency_key(expires_at);
```

The reaper deletes `idempotency_key` rows past `expires_at` in the same sweep that expires sessions.

---

## 3. Context contract

`session.context` is UI state the client wants to survive a reload or a device switch. The API enforces this contract on `POST /sessions` and `PATCH /sessions/{id}` and rejects violations with `400 CONTEXT_REJECTED`.

| Rule | Value |
|---|---|
| Shape | JSON object at the top level |
| Size | 16 KiB serialised, measured after merge |
| Depth | 3 levels |
| Keys | `^[a-zA-Z][a-zA-Z0-9_]{0,63}$`, at most 64 top-level keys |
| Values | string (max 2 KiB), number, boolean, null, object, or array of at most 100 scalars |
| Reserved prefixes | Keys beginning with `atlas_` are written only by the server |
| Forbidden content | Any string matching a credential shape is rejected: JWT (`^eyJ[A-Za-z0-9_-]+\.`), Google API key (`AIza[0-9A-Za-z_-]{35}`), OAuth token (`ya29\.`), private key headers (`-----BEGIN`), AWS key (`AKIA[0-9A-Z]{16}`), Slack or GitHub token prefixes |
| Merge | Top-level keys only. A key present in the patch replaces the whole value. A key set to `null` is removed. Nested merge is not performed. |

Clients that need larger or structured state keep it elsewhere and store a reference in context.

---

## 4. Concurrency rule

A user may hold at most **5 live sessions per client type** (`WEB`, `VSCODE`, `SDK`, `CLI`), where live means `ACTIVE` or `IDLE`. The limit is a configuration value, not a constant.

On `POST /sessions` when the limit is reached:

1. If any live session of that client type is `IDLE`, the oldest by `last_seen_at` is ended with `end_reason = 'CONCURRENCY_LIMIT'` and the new session is created. The response includes `evictedSessionId`.
2. If all are `ACTIVE`, the request fails with `409 SESSION_LIMIT` and `details.liveSessions` listing them so the client can offer the user a choice.

```sql
-- Inside the start transaction, after locking the user's live sessions
SELECT session_id, status, last_seen_at
FROM session
WHERE user_id = $1 AND client_type = $2
  AND deleted_at IS NULL AND status IN ('ACTIVE', 'IDLE')
ORDER BY (status = 'IDLE') DESC, last_seen_at ASC
FOR UPDATE;
```

---

## 5. Session routes

### 5.1 `POST /sessions` — start a session

Auth: any authenticated principal. Idempotency-Key optional.

Request:

```json
{
  "clientType": "WEB",
  "useCaseId": "a1b2c3d4-…",
  "mlWorkspaceId": null,
  "context": { "useCaseFilter": ["risk"] }
}
```

Behaviour: resolves principal to a user; if `useCaseId` is given, verifies access; applies the concurrency rule; inserts the session with `expires_at = now + 12h`; inserts a `STARTED` event. `clientIp` and `userAgent` are taken from the request, never from the body.

Response `201 Created`, body is the session resource, plus `"evictedSessionId"` when the concurrency rule ended one. Header `Location: /api/v1/sessions/{sessionId}`.

Errors: `400`, `403` (no access to use case), `409 SESSION_LIMIT`, `409 IDEMPOTENCY_KEY_REUSED`.

### 5.2 `GET /sessions/current` — the session named in the header

Auth: `SELF` via `X-Atlas-Session-Id`.

Behaviour: loads the session, verifies `user_id` matches the principal. Does **not** refresh `last_seen_at`; that is the heartbeat's job.

Response `200` session resource. Errors: `400` (header missing or not a UUID), `403` (another user's session), `404`, `410 SESSION_GONE`.

### 5.3 `GET /sessions/{sessionId}` — a specific session

Auth: `SELF`, or `USE_CASE_OWNER` for sessions whose `use_case_id` they own, or `PLATFORM_ADMIN`.

Response `200` session resource. Admins also receive `clientIp` and `userAgent`, and can read `ENDED` and `EXPIRED` sessions (`200`, not `410`) for 90 days. Errors: `403`, `404`.

### 5.4 `GET /sessions` — list sessions

Auth: `PLATFORM_ADMIN` for the unfiltered list. `USE_CASE_OWNER` may call it with `useCaseId` set to a use case they own. Everyone may call it with `userId` equal to their own id, which is what `GET /users/{userId}/sessions` (5.10) aliases.

Query: `status` (`live` | `ACTIVE` | `IDLE` | `ENDED` | `EXPIRED`, default `live`), `userId`, `useCaseId`, `clientType`, `since` (RFC 3339, filters `last_seen_at`), `limit`, `cursor`.

Response `200`:

```json
{ "items": [ { "...session resource": "..." } ], "nextCursor": "eyJsYXN0U2VlbkF0Ijoi…", "total": 137 }
```

`total` is present only when `status` is `live`, because counting history is expensive.

```sql
SELECT s.*, u.principal_email, uc.name AS use_case_name,
       (SELECT count(*) FROM operation o
         WHERE o.session_id = s.session_id AND o.deleted_at IS NULL
           AND o.status IN ('PENDING','RUNNING','AWAITING_APPROVAL')) AS in_flight_operations
FROM session s
JOIN "user" u ON u.user_id = s.user_id
LEFT JOIN use_case uc ON uc.use_case_id = s.use_case_id
WHERE s.deleted_at IS NULL
  AND ($status_live IS FALSE OR s.status IN ('ACTIVE','IDLE'))
  AND ($user_id IS NULL OR s.user_id = $user_id)
  AND ($use_case_id IS NULL OR s.use_case_id = $use_case_id)
  AND ($client_type IS NULL OR s.client_type = $client_type)
  AND ($since IS NULL OR s.last_seen_at >= $since)
  AND ($cursor_last_seen IS NULL OR (s.last_seen_at, s.session_id) < ($cursor_last_seen, $cursor_id))
ORDER BY s.last_seen_at DESC, s.session_id DESC
LIMIT $limit + 1;
```

### 5.5 `PATCH /sessions/{sessionId}` — switch context

Auth: `SELF`. Idempotency-Key required.

Request, all fields optional, at least one present:

```json
{
  "useCaseId": "a1b2c3d4-…",
  "mlWorkspaceId": "9b1e2f3a-…",
  "context": { "lastViewedExperimentId": "3fa85f64-…", "useCaseFilter": null }
}
```

Behaviour: if `useCaseId` changes, verifies access and clears `mlWorkspaceId` unless the body sets one in the same use case; applies the context contract; merges context at the top level; inserts a `CONTEXT_CHANGED` event with the before and after of `useCaseId` and `mlWorkspaceId` (not of context, which may be large). A `PATCH` also counts as activity: sets `status = 'ACTIVE'` and `last_seen_at`, but does **not** slide `expires_at`.

```sql
UPDATE session
SET use_case_id     = COALESCE($use_case_id, use_case_id),
    ml_workspace_id = CASE WHEN $use_case_id IS DISTINCT FROM use_case_id AND $ml_workspace_id IS NULL
                           THEN NULL ELSE COALESCE($ml_workspace_id, ml_workspace_id) END,
    context         = jsonb_strip_nulls(context || $context::jsonb),
    status          = 'ACTIVE',
    last_seen_at    = CURRENT_TIMESTAMP,
    updated_at      = CURRENT_TIMESTAMP
WHERE session_id = $1 AND user_id = $2 AND deleted_at IS NULL AND status IN ('ACTIVE','IDLE')
RETURNING *;
```

Response `200` session resource. Errors: `400 CONTEXT_REJECTED`, `403` (use case access, or not owner), `404`, `410`.

### 5.6 `POST /sessions/{sessionId}/heartbeat` — keep alive

Auth: `SELF`. No body. No Idempotency-Key.

Behaviour: the debounced update from spec section 6.1. Zero rows updated with a live session means debounced. If the session was `IDLE`, the transition back to `ACTIVE` inserts a `RESUMED` event; heartbeats on an already active session insert nothing.

Response `200`:

```json
{ "sessionId": "d290f1ee-…", "status": "ACTIVE", "expiresAt": "2026-09-07T21:41:12.515Z", "debounced": true }
```

Errors: `403`, `404`, `410`.

### 5.7 `DELETE /sessions/{sessionId}` — end own session

Auth: `SELF`. Idempotency-Key required. Query `?reason=` free text up to 200 chars, stored in the event detail.

Behaviour: sets `status = 'ENDED'`, `end_reason = 'USER'`, `ended_at`, `deleted_at`; inserts an `ENDED` event. In-flight operations continue. A second `DELETE` on an already ended session returns `204` (idempotent), not `410`.

Response `204 No Content`. Errors: `403`, `404`.

### 5.8 `POST /sessions/{sessionId}:forceEnd` — admin end

Auth: `PLATFORM_ADMIN`, or `USE_CASE_OWNER` for the session's use case. Idempotency-Key required.

Request:

```json
{ "reason": "Incident INC0451: credential rotation", "endInFlightOperations": false }
```

Behaviour: as `DELETE` but `end_reason = 'ADMIN'`, actor is the admin, and `reason` is mandatory. When `endInFlightOperations` is true, every `PENDING` or `AWAITING_APPROVAL` operation started from the session is cancelled with the same reason; `RUNNING` operations are never touched.

Response `200`:

```json
{ "sessionId": "d290f1ee-…", "status": "ENDED", "cancelledOperations": ["3fa85f64-…"] }
```

### 5.9 `GET /sessions/{sessionId}/events` — session audit trail

Auth: as 5.3.

Response `200`:

```json
{
  "items": [
    { "eventType": "STARTED", "toStatus": "ACTIVE", "actor": "alice@example.com", "detail": {}, "createdAt": "…" },
    { "eventType": "CONTEXT_CHANGED", "actor": "alice@example.com", "detail": { "useCaseId": { "from": null, "to": "a1b2…" } }, "createdAt": "…" },
    { "eventType": "IDLE", "fromStatus": "ACTIVE", "toStatus": "IDLE", "actor": "atlas-reaper", "detail": {}, "createdAt": "…" }
  ],
  "nextCursor": null
}
```

### 5.10 `GET /users/{userId}/sessions` — a user's sessions

Auth: `SELF` or `PLATFORM_ADMIN`. Alias for `GET /sessions?userId={userId}`. Kept because clients find it more discoverable.

### 5.11 Reaper transitions

Not routes, but they write the same tables and appear in the same audit trail. Every 5 minutes:

| Transition | Condition | Event |
|---|---|---|
| `ACTIVE` → `IDLE` | `last_seen_at` older than 15 minutes | `IDLE`, actor `atlas-reaper` |
| `ACTIVE` or `IDLE` → `EXPIRED` | `expires_at` passed | `EXPIRED`, `end_reason = 'EXPIRED'` |
| any live → `ENDED` | user soft-deleted by leaver sync | `ENDED`, `end_reason = 'USER_DEACTIVATED'` |

---

## 6. Operation routes (summary)

Defined in spec section 6.3. Restated here with bodies so the OpenAPI file is complete.

| Route | Auth | Body | Response |
|---|---|---|---|
| `GET /operations/{operationId}` | `SELF`, `USE_CASE_OWNER`, `PLATFORM_ADMIN` | — | `200` operation resource |
| `GET /operations` | as `GET /sessions` | query `sessionId`, `useCaseId`, `userId`, `status`, `operationType`, `targetEntityType`, `targetEntityId`, `since`, `limit`, `cursor` | `200` page of operations |
| `POST /operations/{operationId}:cancel` | `SELF`, `PLATFORM_ADMIN` | `{ "reason": "…" }` | `200` operation, or `409 INVALID_STATE` |
| `POST /operations/{operationId}:approve` | `BUSINESS_APPROVER` role, `PLATFORM_ADMIN` | `{ "note": "…" }` | `200` operation, or `409 INVALID_STATE` |
| `GET /operations/{operationId}/events` | as get | — | `200` page of events |

Operation resource:

```json
{
  "operationId": "3fa85f64-…",
  "sessionId": "d290f1ee-…",
  "userId": "7c9e6679-…",
  "useCaseId": "a1b2c3d4-…",
  "operationType": "CREATE_WORKSTATION",
  "targetEntityType": "WORKSTATION",
  "targetEntityId": "f47ac10b-…",
  "status": "RUNNING",
  "attemptCount": 1,
  "requestPayload": { "implementation": "VSCODE", "configuration": { "cpuCount": 8, "memory": "32Gi", "gpuCount": 1 } },
  "resultPayload": null,
  "error": null,
  "orchestratorCorrelationId": "run-8f2c…",
  "createdAt": "…", "startedAt": "…", "completedAt": null, "nextAttemptAt": null,
  "links": { "self": "…", "events": "…", "target": "/api/v1/workstations/f47ac10b-…" }
}
```

`error` is `{ "code", "message" }` when `status` is `FAILED`. `requestPayload` is returned to the requester and admins; `resultPayload` is projected to remove orchestrator internals before it reaches non-admins.

---

## 7. Admin routes for reconciliation

These were referenced by the backfill and classification documents but never defined. All require `PLATFORM_ADMIN` unless stated.

### 7.1 Unmatched review queue

`GET /admin/reconcile/unmatched` — query `assetType`, `projectId`, `limit`, `cursor`. Response items:

```json
{
  "assetName": "//workstations.googleapis.com/projects/p/locations/l/workstationClusters/c/workstationConfigs/cfg/workstations/w",
  "assetType": "workstations.googleapis.com/Workstation",
  "projectId": "cl-affordability-dev",
  "labels": { "env": "dev", "team": "cl-ds" },
  "creatorEmail": "bob@example.com",
  "createTime": "2025-11-02T10:14:00Z",
  "suggestions": [
    { "useCaseId": "a1b2…", "useCaseName": "Consumer Lending Affordability", "rule": "project-name-similarity", "confidence": 40 }
  ]
}
```

`POST /admin/reconcile/unmatched/{assetName}:assign` — Idempotency-Key required. Auth also `USE_CASE_OWNER` when `useCaseId` is one they own.

```json
{ "useCaseId": "a1b2…", "ownerUserId": "7c9e…", "note": "Bob's GPU box for the affordability model", "createCrosswalk": true }
```

Behaviour: writes `matched_entity_*` on the inventory row, creates the resource rows through the same path as the backfill (origin `IMPORTED`), and when `createCrosswalk` is true inserts a verified `GCP_PROJECT` crosswalk row so siblings match next run. Response `200` with the created resource ids.

`POST /admin/reconcile/unmatched/{assetName}:ignore` — body `{ "reason": "…" }`. Sets `match_status = 'IGNORED'`. Ignored assets still appear in the orphan report under a separate heading.

### 7.2 Crosswalk

`GET /admin/crosswalk` — query `sourceSystem`, `targetEntityType`, `verified` (true | false), `limit`, `cursor`.

`PUT /admin/crosswalk` — Idempotency-Key required. Upsert on `(sourceSystem, sourceKey)`.

```json
{ "sourceSystem": "BACKSTAGE_GROUP", "sourceKey": "group:default/consumer-lending-ds", "targetEntityType": "BUSINESS_UNIT", "targetEntityId": "5e8a…", "confidence": 100 }
```

A `PUT` by a human sets `verified_by` and `verified_at`. Rows written by the reconciler arrive unverified.

`POST /admin/crosswalk/{crosswalkId}:verify` — marks a machine-generated row verified. `DELETE /admin/crosswalk/{crosswalkId}` — hard delete, allowed only when unverified; verified rows are retired by setting `confidence = 0`.

### 7.3 Reconcile runs

`POST /admin/reconcile/runs` — Idempotency-Key required.

```json
{ "mode": "DRY_RUN", "scope": { "projectIds": ["cl-affordability-dev"], "assetTypes": ["workstations.googleapis.com/Workstation"] } }
```

Response `202 Accepted` with `{ "runId": "…", "links": { "self": "/api/v1/admin/reconcile/runs/{runId}" } }`. The run itself is an `operation` of type `RECONCILE` executed by the worker, so its progress, retries, and events are visible through the operation routes. Add `RECONCILE` to `operation_type_enum`.

`GET /admin/reconcile/runs/{runId}` — returns the `reconcile_run` row with its summary counts once finished. `GET /admin/reconcile/runs` — pages through history.

### 7.4 Internal ingest

`POST /internal/terraform/applies` — Auth `SYSTEM` (workload identity of the CI service account, allow-listed per workspace). Defined in the Terraform hydration document, section 7. Responds `202` with a `runId` like 7.3.

---

## 8. Route index

| Method | Path | Auth | Key | Section |
|---|---|---|---|---|
| POST | `/sessions` | any | optional | 5.1 |
| GET | `/sessions/current` | SELF | — | 5.2 |
| GET | `/sessions/{sessionId}` | SELF, owner, admin | — | 5.3 |
| GET | `/sessions` | admin, owner scoped, self scoped | — | 5.4 |
| PATCH | `/sessions/{sessionId}` | SELF | required | 5.5 |
| POST | `/sessions/{sessionId}/heartbeat` | SELF | — | 5.6 |
| DELETE | `/sessions/{sessionId}` | SELF | required | 5.7 |
| POST | `/sessions/{sessionId}:forceEnd` | admin, owner | required | 5.8 |
| GET | `/sessions/{sessionId}/events` | SELF, owner, admin | — | 5.9 |
| GET | `/users/{userId}/sessions` | SELF, admin | — | 5.10 |
| GET | `/operations/{operationId}` | SELF, owner, admin | — | 6 |
| GET | `/operations` | as sessions list | — | 6 |
| POST | `/operations/{operationId}:cancel` | SELF, admin | required | 6 |
| POST | `/operations/{operationId}:approve` | approver, admin | required | 6 |
| GET | `/operations/{operationId}/events` | SELF, owner, admin | — | 6 |
| POST | `/useCases/{useCaseId}/mlWorkspaces` | member | required | spec 6.2 |
| POST | `/mlWorkspaces/{wsId}/workstations` | member | required | spec 6.2 |
| PATCH | `/workstations/{id}/configuration` | member | required | spec 6.2 |
| POST | `/workstations/{id}:start`, `:stop` | member | required | spec 6.2 |
| DELETE | `/workstations/{id}` | member | required | spec 6.2 |
| POST | `/useCases/{useCaseId}/experiments/{expId}/pipelineJobs` | member | required | spec 6.2 |
| POST | `/experiments/{expId}/modelEndpoints` | member | required | spec 6.2 |
| POST | `/modelEndpoints/{id}:promote` | owner | required | spec 6.2 |
| GET | `/admin/reconcile/unmatched` | admin | — | 7.1 |
| POST | `/admin/reconcile/unmatched/{assetName}:assign` | admin, owner | required | 7.1 |
| POST | `/admin/reconcile/unmatched/{assetName}:ignore` | admin | required | 7.1 |
| GET | `/admin/crosswalk` | admin | — | 7.2 |
| PUT | `/admin/crosswalk` | admin | required | 7.2 |
| POST | `/admin/crosswalk/{crosswalkId}:verify` | admin | required | 7.2 |
| DELETE | `/admin/crosswalk/{crosswalkId}` | admin | required | 7.2 |
| POST | `/admin/reconcile/runs` | admin | required | 7.3 |
| GET | `/admin/reconcile/runs`, `/admin/reconcile/runs/{runId}` | admin | — | 7.3 |
| POST | `/internal/terraform/applies` | SYSTEM | required | 7.4 |

"member" means the principal has access to the use case in scope, which depends on the membership model still open in the entity model.
