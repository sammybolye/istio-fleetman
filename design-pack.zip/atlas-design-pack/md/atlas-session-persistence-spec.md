# Atlas Experience Layer: Session and Operation Persistence

**Status:** Draft for review
**Scope:** Experience APIs on GKE, persisting to Cloud SQL for PostgreSQL (v16/v17, Enterprise Plus)
**Out of scope:** Authentication (SSO upstream), agent memory, orchestrator internals

---

## 1. Purpose

The Atlas experience APIs run as stateless pods on GKE. They orchestrate calls to implementation and orchestrator APIs that provision Vertex AI resources, ultimately through Terraform. Provisioning takes minutes, can wait on manual cloud approvals, and can fail midway.

For a mature operational platform, two things must survive pod restarts, rollouts, and client disconnects:

1. **The user's working context** (which use case and workspace they are in, what they were doing).
2. **Every provisioning action ever requested**, with its current state, retries, and outcome.

This document defines the tables, the worker pattern, and the API contract that provide both. It follows the conventions of the existing Atlas schema: UUID keys, `created_at` / `updated_at` / `deleted_at` soft-delete columns, enum types, `ON DELETE RESTRICT` foreign keys, and partial indexes filtered on active rows.

---

## 2. Design decisions

| Decision | Choice | Why |
|---|---|---|
| Orchestrator call style | Synchronous request/response, unchanged | No change required of the orchestrator team today |
| Experience API call style | Asynchronous: accept, persist, return `202`, process in a worker | A synchronous HTTP wait of minutes to hours is fragile behind load balancers and pod rollouts |
| Where identity comes from | SSO/AD claims verified at the edge | Atlas is not an auth system; no token hashes stored |
| What a session is | The user's operational context plus a handle for grouping their operations | Not a keep-alive for a workstation and not a bearer token |
| Session status | Set only by the server, never from a client payload | Prevents a client writing arbitrary enum values |
| Idempotency | Required `Idempotency-Key` header on every mutating request | Safe client retries; prevents duplicate provisioning |
| Queue | Postgres table with `FOR UPDATE SKIP LOCKED` | No extra infrastructure; scales to thousands of operations per hour, which is well beyond Atlas volume |
| Audit trail | Append-only `operation_event` table | Every state transition is recorded with an actor |

---

## 3. Entity model additions

```mermaid
erDiagram
    USER ||--o{ SESSION : "opens"
    USER ||--o{ OPERATION : "requests"
    SESSION ||--o{ OPERATION : "groups"
    OPERATION ||--|{ OPERATION_EVENT : "transitions"
    USE_CASE ||--o{ SESSION : "selected in"
    USE_CASE ||--o{ OPERATION : "scoped to"
    ML_WORKSPACE ||--o{ SESSION : "selected in"
    OPERATION }o--o| WORKSTATION : "targets"
    OPERATION }o--o| ML_WORKSPACE : "targets"
    OPERATION }o--o| PIPELINE_JOB : "targets"
    OPERATION }o--o| MODEL_ENDPOINT : "targets"

    SESSION {
        uuid session_id PK
        uuid user_id FK
        uuid use_case_id FK
        uuid ml_workspace_id FK
        enum status "ACTIVE IDLE ENDED EXPIRED"
        varchar client_type
        jsonb context
        timestamptz last_seen_at
        timestamptz expires_at
        timestamptz deleted_at
    }
    OPERATION {
        uuid operation_id PK
        uuid session_id FK "nullable"
        uuid user_id FK
        uuid use_case_id FK
        enum operation_type
        enum target_entity_type
        uuid target_entity_id
        varchar idempotency_key "unique per user"
        enum status "PENDING RUNNING AWAITING_APPROVAL SUCCEEDED FAILED CANCELLED"
        jsonb request_payload
        jsonb result_payload
        varchar orchestrator_correlation_id
        int attempt_count
        timestamptz next_attempt_at
        varchar locked_by
        timestamptz locked_at
        timestamptz completed_at
    }
    OPERATION_EVENT {
        uuid operation_event_id PK
        uuid operation_id FK
        enum from_status
        enum to_status
        varchar actor
        jsonb detail
        timestamptz created_at
    }
```

![Entity additions: session, operation, operation_event and their links to existing tables](atlas-design-pack/diagrams/entity-additions.png)

*Rendered: [PNG](atlas-design-pack/diagrams/entity-additions.png) · [SVG](atlas-design-pack/diagrams/entity-additions.svg) · [Mermaid source](atlas-design-pack/diagrams/entity-additions.mmd)*

- **session**: one row per client engagement (browser tab, VS Code extension). A user may hold several at once.
- **operation**: one row per requested provisioning or lifecycle action. Lives independently of its session so audit history outlasts the session.
- **operation_event**: one row per status transition on an operation.

---

## 4. PostgreSQL DDL

```sql
-- ============================================================================
-- ENUMS
-- ============================================================================

CREATE TYPE session_status_enum AS ENUM (
    'ACTIVE',       -- heartbeat seen within the idle window
    'IDLE',         -- no heartbeat within the idle window, but not yet expired
    'ENDED',        -- user signed out or client closed cleanly
    'EXPIRED'       -- reaper closed it after expires_at
);

CREATE TYPE operation_type_enum AS ENUM (
    'CREATE_ML_WORKSPACE',
    'DELETE_ML_WORKSPACE',
    'CREATE_WORKSTATION',
    'RESIZE_WORKSTATION',
    'START_WORKSTATION',
    'STOP_WORKSTATION',
    'DELETE_WORKSTATION',
    'RUN_PIPELINE_JOB',
    'DEPLOY_MODEL_ENDPOINT',
    'PROMOTE_MODEL_ENDPOINT'
);

CREATE TYPE operation_status_enum AS ENUM (
    'PENDING',            -- accepted, waiting for a worker
    'RUNNING',            -- a worker holds the lease and is calling the orchestrator
    'AWAITING_APPROVAL',  -- parked on a manual approval (GPU, cloud platform, ServiceNow later)
    'SUCCEEDED',
    'FAILED',
    'CANCELLED'
);

CREATE TYPE target_entity_type_enum AS ENUM (
    'ML_WORKSPACE',
    'WORKSTATION',
    'PIPELINE_JOB',
    'MODEL_ENDPOINT'
);

-- ============================================================================
-- SESSION
-- ============================================================================

CREATE TABLE session (
    session_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id           UUID NOT NULL REFERENCES "user"(user_id) ON DELETE RESTRICT,
    use_case_id       UUID REFERENCES use_case(use_case_id) ON DELETE RESTRICT,
    ml_workspace_id   UUID REFERENCES ml_workspace(ml_workspace_id) ON DELETE RESTRICT,
    status            session_status_enum NOT NULL DEFAULT 'ACTIVE',
    client_type       VARCHAR(50) NOT NULL,             -- 'WEB', 'VSCODE', 'SDK'
    client_ip         INET,
    user_agent        TEXT,
    context           JSONB NOT NULL DEFAULT '{}'::jsonb, -- UI state only; never secrets
    started_at        TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_seen_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at        TIMESTAMPTZ NOT NULL,
    ended_at          TIMESTAMPTZ,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at        TIMESTAMPTZ DEFAULT NULL,
    CONSTRAINT chk_session_ended CHECK (
        (status IN ('ENDED', 'EXPIRED')) = (ended_at IS NOT NULL)
    )
);

CREATE INDEX idx_session_user_live
    ON session(user_id, last_seen_at DESC)
    WHERE deleted_at IS NULL AND status IN ('ACTIVE', 'IDLE');

CREATE INDEX idx_session_use_case
    ON session(use_case_id)
    WHERE deleted_at IS NULL;

CREATE INDEX idx_session_reaper
    ON session(expires_at)
    WHERE deleted_at IS NULL AND status IN ('ACTIVE', 'IDLE');

-- ============================================================================
-- OPERATION
-- ============================================================================

CREATE TABLE operation (
    operation_id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id                  UUID REFERENCES session(session_id) ON DELETE RESTRICT, -- NULL for system-initiated
    user_id                     UUID NOT NULL REFERENCES "user"(user_id) ON DELETE RESTRICT,
    use_case_id                 UUID NOT NULL REFERENCES use_case(use_case_id) ON DELETE RESTRICT,
    operation_type              operation_type_enum NOT NULL,
    target_entity_type          target_entity_type_enum NOT NULL,
    target_entity_id            UUID,                     -- NULL until a CREATE_* succeeds
    idempotency_key             VARCHAR(128) NOT NULL,
    status                      operation_status_enum NOT NULL DEFAULT 'PENDING',
    request_payload             JSONB NOT NULL,
    result_payload              JSONB,
    error_code                  VARCHAR(100),
    error_message               TEXT,
    orchestrator_correlation_id VARCHAR(255),             -- downstream reference for reconciliation
    attempt_count               INT NOT NULL DEFAULT 0,
    max_attempts                INT NOT NULL DEFAULT 3,
    next_attempt_at             TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    locked_by                   VARCHAR(255),             -- worker pod name
    locked_at                   TIMESTAMPTZ,
    started_at                  TIMESTAMPTZ,
    completed_at                TIMESTAMPTZ,
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at                  TIMESTAMPTZ DEFAULT NULL,
    CONSTRAINT chk_operation_terminal CHECK (
        (status IN ('SUCCEEDED', 'FAILED', 'CANCELLED')) = (completed_at IS NOT NULL)
    ),
    CONSTRAINT chk_operation_lock CHECK (
        (status = 'RUNNING') = (locked_by IS NOT NULL AND locked_at IS NOT NULL)
    )
);

-- Same user may not submit the same idempotency key twice while the first is live
CREATE UNIQUE INDEX uq_operation_idempotency_active
    ON operation(user_id, idempotency_key)
    WHERE deleted_at IS NULL;

-- Worker queue scan: oldest ready PENDING first
CREATE INDEX idx_operation_queue
    ON operation(next_attempt_at, created_at)
    WHERE deleted_at IS NULL AND status = 'PENDING';

-- Stale-lease sweep
CREATE INDEX idx_operation_running
    ON operation(locked_at)
    WHERE deleted_at IS NULL AND status = 'RUNNING';

CREATE INDEX idx_operation_session
    ON operation(session_id, created_at DESC)
    WHERE deleted_at IS NULL;

CREATE INDEX idx_operation_user_recent
    ON operation(user_id, created_at DESC)
    WHERE deleted_at IS NULL;

CREATE INDEX idx_operation_use_case
    ON operation(use_case_id, created_at DESC)
    WHERE deleted_at IS NULL;

CREATE INDEX idx_operation_target
    ON operation(target_entity_type, target_entity_id)
    WHERE deleted_at IS NULL AND target_entity_id IS NOT NULL;

-- ============================================================================
-- OPERATION EVENT (append-only audit trail; no soft delete, no updates)
-- ============================================================================

CREATE TABLE operation_event (
    operation_event_id  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    operation_id        UUID NOT NULL REFERENCES operation(operation_id) ON DELETE RESTRICT,
    from_status         operation_status_enum,            -- NULL on creation
    to_status           operation_status_enum NOT NULL,
    actor               VARCHAR(255) NOT NULL,            -- principal email or worker pod name
    detail              JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_operation_event_operation
    ON operation_event(operation_id, created_at);
```

### 4.1 Recommended change to existing tables

The UI needs to show a workstation as "provisioning" before it exists downstream. Add a lifecycle column to the provisionable entities rather than inferring it from operations:

```sql
CREATE TYPE lifecycle_status_enum AS ENUM (
    'PROVISIONING', 'READY', 'STOPPED', 'FAILED', 'DELETING'
);

ALTER TABLE ml_workspace ADD COLUMN lifecycle_status lifecycle_status_enum NOT NULL DEFAULT 'PROVISIONING';
ALTER TABLE workstation  ADD COLUMN lifecycle_status lifecycle_status_enum NOT NULL DEFAULT 'PROVISIONING';
```

With this, a `CREATE_WORKSTATION` operation inserts the `workstation` row as `PROVISIONING` at accept time (so `target_entity_id` is known immediately and the UI can list it), and flips it to `READY` or `FAILED` on completion. The `url` and `launch_url` columns on `workstation` must then become nullable until `READY`.

---

## 5. Worker pattern

Workers run as a separate GKE Deployment (or as a background goroutine/thread in the API pods). Each loop iteration:

### 5.1 Claim one operation

```sql
WITH next_op AS (
    SELECT operation_id
    FROM operation
    WHERE status = 'PENDING'
      AND deleted_at IS NULL
      AND next_attempt_at <= CURRENT_TIMESTAMP
    ORDER BY next_attempt_at, created_at
    FOR UPDATE SKIP LOCKED
    LIMIT 1
)
UPDATE operation o
SET status        = 'RUNNING',
    locked_by     = $1,                              -- pod name
    locked_at     = CURRENT_TIMESTAMP,
    attempt_count = attempt_count + 1,
    started_at    = COALESCE(started_at, CURRENT_TIMESTAMP),
    updated_at    = CURRENT_TIMESTAMP
FROM next_op
WHERE o.operation_id = next_op.operation_id
RETURNING o.*;
```

Insert an `operation_event` (`PENDING` to `RUNNING`) in the same transaction.

### 5.2 Execute

Call the orchestrator synchronously with a generous timeout (for example 20 minutes) and pass the operation's `idempotency_key` as the downstream idempotency key. Store the returned correlation ID immediately, before waiting on the result, so a crashed worker can reconcile later.

### 5.3 Complete

| Outcome | Update |
|---|---|
| Orchestrator success | `status = 'SUCCEEDED'`, `result_payload`, `completed_at`, `target_entity_id`; update the target entity's `lifecycle_status` |
| Orchestrator says approval required | `status = 'AWAITING_APPROVAL'`, release lock; a later approve call or poll re-queues it |
| Transient error (5xx, timeout, connection reset) and `attempt_count < max_attempts` | `status = 'PENDING'`, `next_attempt_at = now + (2 ^ attempt_count) minutes`, release lock |
| Transient error and attempts exhausted, or non-retryable error (4xx validation) | `status = 'FAILED'`, `error_code`, `error_message`, `completed_at` |

Every transition writes an `operation_event`.

**Timeout ambiguity.** If the orchestrator call times out, the resource may or may not have been created. Before retrying, the worker must query the orchestrator by correlation ID or idempotency key. This is the one requirement Atlas places on the orchestrator: it must accept an idempotency key and be queryable by it.

### 5.4 Stale-lease sweep (every 5 minutes)

```sql
UPDATE operation
SET status          = 'PENDING',
    locked_by       = NULL,
    locked_at       = NULL,
    next_attempt_at = CURRENT_TIMESTAMP,
    updated_at      = CURRENT_TIMESTAMP
WHERE status = 'RUNNING'
  AND deleted_at IS NULL
  AND locked_at < CURRENT_TIMESTAMP - INTERVAL '30 minutes'
RETURNING operation_id;
```

Lease length must exceed the orchestrator timeout. Log an event for each reset.

### 5.5 Session reaper (every 5 minutes)

```sql
-- Mark idle
UPDATE session
SET status = 'IDLE', updated_at = CURRENT_TIMESTAMP
WHERE status = 'ACTIVE' AND deleted_at IS NULL
  AND last_seen_at < CURRENT_TIMESTAMP - INTERVAL '15 minutes';

-- Expire
UPDATE session
SET status = 'EXPIRED', ended_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
WHERE status IN ('ACTIVE', 'IDLE') AND deleted_at IS NULL
  AND expires_at < CURRENT_TIMESTAMP;
```

Expiring a session does not touch its operations. In-flight provisioning finishes regardless.

---

## 6. API contract (experience layer)

All routes require an SSO-verified principal. The API resolves the principal to `"user".user_id` and rejects any request where the path or body user does not match. Mutating routes require an `Idempotency-Key` header.

### 6.1 Sessions

| Action | Route | DB | Notes |
|---|---|---|---|
| Start session | `POST /api/v1/sessions` | `INSERT session` | Body: `clientType`, optional `useCaseId`. `expires_at = now + 12h`. Returns `201` with the session. |
| Get current session | `GET /api/v1/sessions/current` | `SELECT` | Header `X-Atlas-Session-Id`. Joins use_case and ml_workspace names; includes count of in-flight operations. `404` if not live or belongs to another user. |
| Switch context | `PATCH /api/v1/sessions/{id}` | `UPDATE` | Body: `useCaseId`, `mlWorkspaceId`, `context`. Verifies the user has access to the use case. Merges `context` with `\|\|` (top-level keys only). |
| Heartbeat | `POST /api/v1/sessions/{id}/heartbeat` | `UPDATE` | No body. Sets `last_seen_at`, `status = 'ACTIVE'`, slides `expires_at`. Server skips the write if `last_seen_at` is under 60 seconds old. |
| End session | `DELETE /api/v1/sessions/{id}` | `UPDATE` | `status = 'ENDED'`, `ended_at`, `deleted_at`. Returns `204`. |
| List a user's sessions | `GET /api/v1/users/{userId}/sessions?status=live` | `SELECT` | Self or admin role. Uses `idx_session_user_live`. |

#### Heartbeat SQL

```sql
UPDATE session
SET last_seen_at = CURRENT_TIMESTAMP,
    status       = 'ACTIVE',
    expires_at   = CURRENT_TIMESTAMP + INTERVAL '12 hours',
    updated_at   = CURRENT_TIMESTAMP
WHERE session_id = $1
  AND user_id    = $2
  AND deleted_at IS NULL
  AND status IN ('ACTIVE', 'IDLE')
  AND last_seen_at < CURRENT_TIMESTAMP - INTERVAL '60 seconds'
RETURNING expires_at;
```

Zero rows with a live session means "debounced"; return `200` with the existing `expires_at`.

### 6.2 Provisioning (resource routes that create operations)

These are the routes users actually call. Each one validates, inserts an `operation` (and, for creates, a `PROVISIONING` target row), writes the first `operation_event`, and returns `202 Accepted` with a `Location` header pointing at the operation.

| Action | Route | Operation type |
|---|---|---|
| Create ML workspace | `POST /api/v1/useCases/{useCaseId}/mlWorkspaces` | `CREATE_ML_WORKSPACE` |
| Create workstation | `POST /api/v1/mlWorkspaces/{wsId}/workstations` | `CREATE_WORKSTATION` |
| Resize workstation | `PATCH /api/v1/workstations/{id}/configuration` | `RESIZE_WORKSTATION` |
| Start / stop workstation | `POST /api/v1/workstations/{id}:start` / `:stop` | `START_WORKSTATION` / `STOP_WORKSTATION` |
| Delete workstation | `DELETE /api/v1/workstations/{id}` | `DELETE_WORKSTATION` |
| Run pipeline job | `POST /api/v1/useCases/{useCaseId}/experiments/{expId}/pipelineJobs` | `RUN_PIPELINE_JOB` |
| Deploy model endpoint | `POST /api/v1/experiments/{expId}/modelEndpoints` | `DEPLOY_MODEL_ENDPOINT` |
| Promote endpoint to next RTL stage | `POST /api/v1/modelEndpoints/{id}:promote` | `PROMOTE_MODEL_ENDPOINT` |

#### Example: create workstation

Request:

```http
POST /api/v1/mlWorkspaces/9b1e.../workstations
Idempotency-Key: 7c9e6679-7425-40de-944b-e07fc1f90ae7
X-Atlas-Session-Id: d290f1ee-...
Content-Type: application/json

{
  "implementation": "VSCODE",
  "configuration": { "cpuCount": 8, "memory": "32Gi", "container": "atlas/vscode:1.4", "gpuCount": 1 }
}
```

Transaction:

```sql
BEGIN;

-- 1. Reject duplicates early (also enforced by uq_operation_idempotency_active)
SELECT operation_id, status FROM operation
WHERE user_id = $user AND idempotency_key = $key AND deleted_at IS NULL;
-- if found: ROLLBACK and return 200 with the existing operation

-- 2. Create the target in PROVISIONING state
INSERT INTO workstation_configuration (cpu_count, memory, container, gpu_count)
VALUES (8, '32Gi', 'atlas/vscode:1.4', 1)
RETURNING workstation_config_id;

INSERT INTO workstation (ml_workspace_id, workstation_config_id, implementation, lifecycle_status)
VALUES ($ws, $cfg, 'VSCODE', 'PROVISIONING')
RETURNING workstation_id;

-- 3. Enqueue
INSERT INTO operation (
    session_id, user_id, use_case_id, operation_type,
    target_entity_type, target_entity_id, idempotency_key, request_payload
) VALUES (
    $session, $user, $use_case, 'CREATE_WORKSTATION',
    'WORKSTATION', $workstation_id, $key, $body::jsonb
)
RETURNING operation_id;

INSERT INTO operation_event (operation_id, from_status, to_status, actor, detail)
VALUES ($op, NULL, 'PENDING', $principal_email, '{"source":"api"}');

COMMIT;
```

Response:

```http
HTTP/1.1 202 Accepted
Location: /api/v1/operations/3fa85f64-...

{
  "operationId": "3fa85f64-...",
  "status": "PENDING",
  "targetEntityType": "WORKSTATION",
  "targetEntityId": "f47ac10b-...",
  "createdAt": "2026-09-03T11:30:00Z"
}
```

The same request with the same `Idempotency-Key` returns `200` with the original operation, never a second workstation.

### 6.3 Operations

| Action | Route | DB | Notes |
|---|---|---|---|
| Poll an operation | `GET /api/v1/operations/{id}` | `SELECT` | Returns status, `resultPayload` when succeeded, `errorCode` / `errorMessage` when failed. Owner or admin only. |
| List operations | `GET /api/v1/operations?sessionId=&useCaseId=&status=&limit=` | `SELECT` | Backed by the session, use case, and user indexes. Default sort `created_at DESC`. |
| Cancel | `POST /api/v1/operations/{id}:cancel` | `UPDATE` | Only from `PENDING` or `AWAITING_APPROVAL`. A `RUNNING` operation cannot be cancelled; the response is `409`. |
| Approve (future) | `POST /api/v1/operations/{id}:approve` | `UPDATE` | Approver role only. Moves `AWAITING_APPROVAL` to `PENDING`. This is where a ServiceNow webhook lands later. |
| Audit trail | `GET /api/v1/operations/{id}/events` | `SELECT` | Ordered transitions with actor and detail. |

#### Cancel SQL

```sql
UPDATE operation
SET status       = 'CANCELLED',
    completed_at = CURRENT_TIMESTAMP,
    updated_at   = CURRENT_TIMESTAMP
WHERE operation_id = $1
  AND user_id      = $2
  AND deleted_at IS NULL
  AND status IN ('PENDING', 'AWAITING_APPROVAL')
RETURNING operation_id;
```

Zero rows means the operation is already running or finished; return `409`.

### 6.4 Operation status lifecycle

```mermaid
stateDiagram-v2
    direction LR
    [*] --> PENDING : API commits intent

    PENDING --> RUNNING : worker claims (SKIP LOCKED)
    PENDING --> CANCELLED : user cancels

    RUNNING --> SUCCEEDED : orchestrator ok
    RUNNING --> FAILED : non-retryable, or attempts exhausted
    RUNNING --> PENDING : transient error, retry with backoff
    RUNNING --> PENDING : stale lease swept
    RUNNING --> AWAITING_APPROVAL : approval required

    AWAITING_APPROVAL --> PENDING : approved
    AWAITING_APPROVAL --> CANCELLED : user cancels

    SUCCEEDED --> [*]
    FAILED --> [*]
    CANCELLED --> [*]

    note right of RUNNING
        Cannot be cancelled:
        Terraform may already be applying
    end note
```

![Operation status lifecycle](atlas-design-pack/diagrams/operation-lifecycle.png)

*Rendered: [PNG](atlas-design-pack/diagrams/operation-lifecycle.png) · [SVG](atlas-design-pack/diagrams/operation-lifecycle.svg) · [Mermaid source](atlas-design-pack/diagrams/operation-lifecycle.mmd)*

Text fallback:

```
              ┌──────────────────────────────┐
              │                              ▼
PENDING ──▶ RUNNING ──▶ SUCCEEDED         CANCELLED
   ▲   │       │  │
   │   │       │  └──▶ FAILED
   │   │       │
   │   │       └──▶ AWAITING_APPROVAL ──▶ PENDING (on approve)
   │   │                    │
   │   │                    └──▶ CANCELLED
   │   └──▶ CANCELLED
   │
   └──── RUNNING (transient error, retry with backoff)
```

Terminal states: `SUCCEEDED`, `FAILED`, `CANCELLED`.

---

## 7. Cloud SQL and GKE operational notes

1. **Connections.** Use Workload Identity plus IAM database authentication through the Cloud SQL Auth Proxy sidecar or the language connector. Put PgBouncer or Cloud SQL Managed Connection Pooling in transaction mode in front. Every statement in this document is a single statement or an explicit `BEGIN ... COMMIT`, so transaction-mode pooling is safe.
2. **Worker concurrency.** Run 2 to 4 worker replicas. `SKIP LOCKED` prevents two workers claiming the same row. Tune `max_attempts` and lease length per operation type if Terraform runs for some types take much longer.
3. **Retention.** `operation` and `operation_event` are the audit trail. Never hard-delete them. When volume warrants it, partition `operation_event` by month on `created_at`. Sessions can be hard-deleted after 90 days.
4. **Sensitive data.** `session.context` and `operation.request_payload` are JSONB. Enforce at the API layer that they never hold credentials, tokens, or dataset contents. The workshop raised log scanning for sensitive content; the same applies here.
5. **Read replicas.** Not needed at Atlas volumes. Polling `GET /operations/{id}` is a primary-key lookup on the primary.
6. **Observability.** Emit a metric per `operation_event` transition (type, from, to) and alert on `FAILED` rate and on operations sitting in `PENDING` beyond a threshold.

---

## 8. Open items for the platform team

- Confirm the orchestrator accepts an idempotency key and can be queried by it. Without this, timeout recovery is a manual reconciliation.
- Confirm whether GPU approval surfaces as a synchronous error from the orchestrator or as a pending state. This determines how `AWAITING_APPROVAL` is entered.
- Decide whether the worker lives in the API deployment or a separate one. Separate is cleaner for scaling and for rolling out orchestrator client changes.
- The existing schema still has no use-case membership or multiple-owner support. Access checks in `PATCH /sessions` and every provisioning route depend on that being resolved.

---

# Part 2: Backfill and Reconciliation

**Problem.** Hundreds to thousands of ML resources already exist, provisioned through Backstage and the implementation API. On day one the Atlas database must reflect them, and from then on it must stay in sync with what actually exists in GCP.

**Principle.** For existing resources, GCP is the truth about *what exists* and Backstage, Terraform, and labels are the truth about *who owns it*. Atlas starts as a projection of those sources and becomes authoritative only for resources it provisions itself. The backfill is the first run of a reconciler that keeps running.

---

## 9. Schema additions for imported resources

### 9.1 Columns on every provisionable table

Apply to `ml_workspace`, `workstation`, `notebook`, `experiment`, `pipeline_template`, `pipeline_job`, `model`, `model_endpoint`.

```sql
CREATE TYPE origin_enum AS ENUM ('ATLAS', 'IMPORTED', 'SYNTHESIZED');
CREATE TYPE reconcile_status_enum AS ENUM ('IN_SYNC', 'DRIFTED', 'ORPHANED', 'MISSING');
-- IN_SYNC   Atlas row and cloud resource agree
-- DRIFTED   cloud resource changed outside Atlas (config, state, labels)
-- ORPHANED  cloud resource exists, Atlas row could not be matched to an owner
-- MISSING   Atlas row exists, cloud resource is gone

ALTER TABLE workstation
    ADD COLUMN external_resource_name TEXT,          -- full GCP name, e.g. projects/p/locations/l/workstationClusters/c/workstationConfigs/cfg/workstations/w
    ADD COLUMN origin                 origin_enum NOT NULL DEFAULT 'ATLAS',
    ADD COLUMN reconcile_status       reconcile_status_enum,
    ADD COLUMN last_reconciled_at     TIMESTAMPTZ,
    ADD COLUMN source_labels          JSONB NOT NULL DEFAULT '{}'::jsonb;

CREATE UNIQUE INDEX uq_workstation_external_name_active
    ON workstation(external_resource_name)
    WHERE deleted_at IS NULL AND external_resource_name IS NOT NULL;

-- Repeat for the other tables listed above.
```

Atlas-originated operations write `external_resource_name` on success, so the reconciler recognises its own children.

### 9.2 Staging and mapping tables

```sql
-- One row per backfill or reconcile execution
CREATE TABLE reconcile_run (
    run_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    mode            VARCHAR(20) NOT NULL,             -- 'DRY_RUN' | 'APPLY'
    trigger         VARCHAR(50) NOT NULL,             -- 'BACKFILL' | 'SCHEDULED' | 'ASSET_FEED' | 'MANUAL'
    snapshot_ref    TEXT,                             -- BigQuery table or GCS path of the inventory export
    started_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    finished_at     TIMESTAMPTZ,
    summary         JSONB NOT NULL DEFAULT '{}'::jsonb, -- counts by asset type and match tier
    created_by      VARCHAR(255) NOT NULL
);

-- Raw inventory, kept so matching can be re-run without re-querying the cloud
CREATE TABLE inventory_asset (
    asset_name          TEXT PRIMARY KEY,             -- full resource name from Cloud Asset Inventory
    asset_type          VARCHAR(120) NOT NULL,        -- e.g. workstations.googleapis.com/Workstation
    project_id          VARCHAR(63) NOT NULL,
    location            VARCHAR(63),
    labels              JSONB NOT NULL DEFAULT '{}'::jsonb,
    resource            JSONB NOT NULL,               -- full resource body from CAI
    resource_state      VARCHAR(50),                  -- RUNNING, STOPPED, DEPLOYED, ...
    create_time         TIMESTAMPTZ,
    update_time         TIMESTAMPTZ,
    creator_email       VARCHAR(255),                 -- from Admin Activity audit logs, may be NULL
    first_seen_run_id   UUID NOT NULL REFERENCES reconcile_run(run_id),
    last_seen_run_id    UUID NOT NULL REFERENCES reconcile_run(run_id),
    last_seen_at        TIMESTAMPTZ NOT NULL,
    match_status        VARCHAR(20) NOT NULL DEFAULT 'UNMATCHED', -- MATCHED | UNMATCHED | IGNORED
    match_tier          SMALLINT,                     -- 1..5, see 11.3
    match_rule          VARCHAR(100),
    matched_entity_type VARCHAR(30),              -- WORKSTATION, NOTEBOOK, EXPERIMENT, PIPELINE_JOB, MODEL, MODEL_ENDPOINT
    matched_entity_id   UUID,
    review_note         TEXT
);

CREATE INDEX idx_inventory_asset_unmatched ON inventory_asset(asset_type) WHERE match_status = 'UNMATCHED';
CREATE INDEX idx_inventory_asset_project   ON inventory_asset(project_id);

-- Durable, human-editable mapping from external identifiers to Atlas entities
CREATE TABLE entity_crosswalk (
    crosswalk_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_system       VARCHAR(50) NOT NULL,         -- 'BACKSTAGE_GROUP' | 'BACKSTAGE_SYSTEM' | 'GCP_PROJECT' | 'LABEL' | 'AD_GROUP' | 'TF_MODULE'
    source_key          TEXT NOT NULL,                -- e.g. group:default/consumer-lending-ds, or project id
    target_entity_type  VARCHAR(30) NOT NULL,         -- 'BUSINESS_UNIT' | 'USE_CASE' | 'USER'
    target_entity_id    UUID NOT NULL,
    confidence          SMALLINT NOT NULL CHECK (confidence BETWEEN 0 AND 100),
    verified_by         VARCHAR(255),                 -- NULL until a human confirms
    verified_at         TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (source_system, source_key)
);
```

Add `'BACKFILL_IMPORT'` to `operation_type_enum` so every imported row gets one `SUCCEEDED` operation with actor `backfill`, giving imported and Atlas-created resources the same audit shape.

---

## 10. What to capture, and from where

### 10.1 Sources

| Source | Gives you | How to pull it |
|---|---|---|
| **Cloud Asset Inventory (CAI)** | Every resource of the listed types across the org or folder, with labels, state, config, timestamps | `gcloud asset export` to BigQuery once for the baseline; CAI feed to Pub/Sub afterwards |
| **Admin Activity audit logs** | Who created each resource (`principalEmail`), when | BigQuery log sink or Logs Explorer query on `Create*` method names. Retained 400 days; older resources will lack a creator |
| **Backstage catalog** | Groups (business units, teams), Systems (use cases), Resources registered against them, owner relations | `GET /api/catalog/entities/by-query?filter=kind=group`, `kind=system`, `kind=resource` |
| **Terraform state** | Module inputs: which use case, config, owner a resource was provisioned for | Read `.tfstate` from the GCS backend; index by resource `id` |
| **Compute machine types** | vCPU and memory for a `machineType` string | `compute.machineTypes.get(zone, type)`, cached |
| **Active Directory / Entra** | `name`, `staffId`, group membership for every principal found above | Graph API by UPN |
| **Billing / project labels** | `cost_centre`, `al_number`, environment | Project labels in CAI export |

### 10.2 CAI asset types to export

```bash
gcloud asset export \
  --organization="$ORG_ID" \
  --content-type=resource \
  --asset-types="cloudresourcemanager.googleapis.com/Project,\
workstations.googleapis.com/WorkstationCluster,\
workstations.googleapis.com/WorkstationConfig,\
workstations.googleapis.com/Workstation,\
notebooks.googleapis.com/Instance,\
aiplatform.googleapis.com/NotebookRuntime,\
aiplatform.googleapis.com/MetadataStore,\
aiplatform.googleapis.com/PipelineJob,\
aiplatform.googleapis.com/Model,\
aiplatform.googleapis.com/Endpoint" \
  --bigquery-table="projects/$ATLAS_PROJECT/datasets/atlas_inventory/tables/baseline_$(date +%Y%m%d)" \
  --output-bigquery-force
```

Verify the list against the CAI supported-types page before running. Anything CAI does not cover, such as Vertex Experiments contexts inside a metadata store, is listed per project with the service API instead.

### 10.3 Field mapping per entity

**business_unit** from Backstage Groups (type `business-unit` or `department`)

| Atlas column | Source |
|---|---|
| `name` | `metadata.title` or `metadata.name` |
| `owner_id` | `spec.profile.email` of the group lead, resolved to `"user"` |
| crosswalk | `BACKSTAGE_GROUP` → `group:default/<name>` |

**use_case** from Backstage Systems, enriched by project labels

| Atlas column | Source |
|---|---|
| `name` | System `metadata.title` |
| `business_unit_id` | System `spec.owner` → crosswalk to business unit |
| `cost_centre` | Project label `cost_centre` / `cost-centre`; else System annotation |
| crosswalk | `BACKSTAGE_SYSTEM` → `system:default/<name>`; `GCP_PROJECT` → `<project_id>` |

**"user"** from AD, scoped to principals that appear anywhere in the inventory

| Atlas column | Source |
|---|---|
| `principal_email` | UPN |
| `name`, `staff_id` | AD displayName, employeeId |
| `role_id` | Backstage group membership → role; default `DATA_SCIENTIST` |

Scope = union of: audit-log creators, IAM members with Vertex or Workstations roles on ML projects, Backstage group members.

**ml_workspace** is synthesized. One per distinct (`use_case_id`, `owner_id`, `hosting_env = 'GCP'`) that has at least one matched workstation or notebook. Mark `origin = 'SYNTHESIZED'`.

**workstation** + **workstation_configuration** from `workstations.googleapis.com/Workstation` and its `WorkstationConfig`

| Atlas column | Source |
|---|---|
| `external_resource_name` | `name` |
| `implementation` | `VSCODE` if config image is Code-OSS based; `JUPYTER` if JupyterLab image; else `CUSTOM` |
| `url` | `host` |
| `launch_url` | `https://80-<host>` (or configured port) |
| `lifecycle_status` | `state`: `STATE_RUNNING`→`READY`, `STATE_STOPPED`→`STOPPED`, `STATE_STARTING`→`PROVISIONING` |
| `workstation_configuration.cpu_count`, `memory` | `host.gceInstance.machineType` → machineTypes lookup |
| `workstation_configuration.container` | `container.image` |
| `workstation_configuration.gpu_count` | sum of `host.gceInstance.accelerators[].count` |
| `ml_workspace_id` | via owner (creator email or `labels.owner`) + use case (project crosswalk) |
| `source_labels` | `labels` |

**notebook** + **notebook_spec** from `notebooks.googleapis.com/Instance` and `aiplatform.googleapis.com/NotebookRuntime`, same mapping shape. `implementation = 'JUPYTER'`, `url = proxyUri`. If the entity model drops Notebook, map these to `workstation` with `implementation = 'JUPYTER'` instead. Decide before the run, not after.

**experiment** from Vertex AI Experiments (metadata store contexts with schema `system.Experiment`), listed per project

| Atlas column | Source |
|---|---|
| `name` | context `displayName` |
| `use_case_id` | project crosswalk |
| `external_resource_name` | context `name` |

**pipeline_template** from Artifact Registry KFP repositories

| Atlas column | Source |
|---|---|
| `name` | package name |
| `template_url` | `https://<region>-kfp.pkg.dev/<project>/<repo>/<package>/<tag>` |
| `description` | package description or compiled YAML `pipelineInfo.description` |

**pipeline_job** from `aiplatform.googleapis.com/PipelineJob`

| Atlas column | Source |
|---|---|
| `job_identifier` | `name` (also `external_resource_name`) |
| `template_id` | `templateUri` → match to `pipeline_template.template_url`; NULL if ad hoc |
| `experiment_id` | `labels.vertex-ai-experiment` or pipeline-to-experiment association |
| `timestamp` | `createTime` |

**model** from `aiplatform.googleapis.com/Model`

| Atlas column | Source |
|---|---|
| `registration_info_json` | `{name, displayName, versionId, versionAliases, artifactUri, containerSpec}` |
| `version` | `versionId` |
| `online_or_batch` | `ONLINE` if any `deployedModels`; else `BATCH` |
| `pipeline_job_id` | `pipelineJob` field, or lineage from metadata store |
| `model_endpoint_id` | `deployedModels[0].endpoint` |

**model_endpoint** from `aiplatform.googleapis.com/Endpoint`

| Atlas column | Source |
|---|---|
| `inference_url` | `dedicatedEndpointDns` or `https://<region>-aiplatform.googleapis.com/v1/<name>:predict` |
| `experiment_id` | via model → pipeline job → experiment; else NULL |
| `rtl_stage_id` | project environment label (`env=dev|test|prod`) → stage; else `DEVELOPMENT` |
| `application_id` | project label `al_number` → `application`; else NULL |
| `container_spec`, `compute_spec` | `deployedModels[].dedicatedResources`, model `containerSpec` |

**role**, **rtl_stage**: static seed scripts, applied first.

**application**: from project label `al_number` where present. Expect gaps; this is a known TBD in the entity model.

---

## 11. How the backfill runs

```mermaid
flowchart LR
    subgraph sources[Sources]
        CAI[Cloud Asset Inventory<br/>export to BigQuery]
        AUD[Admin Activity<br/>audit logs]
        BS[Backstage catalog<br/>groups, systems, resources]
        TF[Terraform state<br/>GCS backend]
        AD[Active Directory]
        MT[Compute machine types]
    end

    subgraph staging[Staging in Cloud SQL]
        RUN[(reconcile_run)]
        INV[(inventory_asset)]
        XW[(entity_crosswalk)]
    end

    subgraph match[Matching]
        T1{Tier 1<br/>Atlas labels}
        T2{Tier 2<br/>Backstage resource}
        T3{Tier 3<br/>Terraform state}
        T4{Tier 4<br/>project + creator}
        T5{Tier 5<br/>project only}
        UN[Unmatched<br/>review queue]
    end

    subgraph atlas[Atlas tables]
        BU[(business_unit)]
        UC[(use_case)]
        US[("user")]
        WS[(ml_workspace<br/>synthesized)]
        RES[(workstation, notebook,<br/>experiment, pipeline_job,<br/>model, model_endpoint)]
        OPS[(operation<br/>BACKFILL_IMPORT)]
    end

    CAI --> INV
    AUD -->|creator_email| INV
    BS --> XW
    BS --> BU
    BS --> UC
    AD --> US
    MT -->|cpu, memory| RES
    TF --> T3

    INV --> T1 --> T2 --> T3 --> T4 --> T5 --> UN
    XW -.-> T2
    XW -.-> T4
    XW -.-> T5
    UN -->|owner assigns via CSV or screen| XW

    T1 & T2 & T3 & T4 & T5 --> WS --> RES --> OPS
    BU --> UC --> WS
    US --> WS
    RUN -.->|summary, counts| INV

    RES -->|nightly reconcile<br/>CAI feed| INV
```

![Inventory hydration data flow: sources, staging, matching tiers, Atlas tables](atlas-design-pack/diagrams/hydration-data-flow.png)

*Rendered: [PNG](atlas-design-pack/diagrams/hydration-data-flow.png) · [SVG](atlas-design-pack/diagrams/hydration-data-flow.svg) · [Mermaid source](atlas-design-pack/diagrams/hydration-data-flow.mmd)*

### 11.1 Order of operations

Dimensions before facts, parents before children. Each step is idempotent and upserts on the natural key shown.

| Step | Target | Natural key | Depends on |
|---|---|---|---|
| 1 | `role`, `rtl_stage` seeds | `role_id`, `stage_id` | none |
| 2 | Discover: CAI export → `inventory_asset`; audit logs → `creator_email`; Backstage dump; TF state index | `asset_name` | none |
| 3 | `business_unit` | crosswalk `BACKSTAGE_GROUP` | 1, 2 |
| 4 | `use_case` | crosswalk `BACKSTAGE_SYSTEM`, `GCP_PROJECT` | 3 |
| 5 | `"user"` | `principal_email` | 1, 2 |
| 6 | Match every `inventory_asset` to owner and use case | see 11.3 | 3, 4, 5 |
| 7 | `ml_workspace` (synthesized) | (`use_case_id`, `owner_id`, `hosting_env`) | 6 |
| 8 | `workstation_configuration`, `workstation`, `notebook_spec`, `notebook` | `external_resource_name` | 7 |
| 9 | `experiment` | `external_resource_name` | 4 |
| 10 | `pipeline_template`, `pipeline_job` | `template_url`, `job_identifier` | 9 |
| 11 | `model_endpoint`, `model` | `external_resource_name` | 9, 10 |
| 12 | One `BACKFILL_IMPORT` operation per imported row, status `SUCCEEDED` | `idempotency_key = 'backfill:' || external_resource_name` | 8–11 |
| 13 | Write `reconcile_run.summary`; publish the unmatched report | | all |

### 11.2 Run modes

- **DRY_RUN** writes only `reconcile_run`, `inventory_asset`, and `entity_crosswalk`. It produces the match report. Run this repeatedly while tuning rules.
- **APPLY** additionally upserts Atlas tables. First APPLY is the baseline. Every APPLY after that is a reconcile.

A rerun of APPLY against an unchanged inventory must produce zero row changes. That is the idempotency test.

### 11.3 Matching tiers

Each asset is tried against tiers in order; the first hit wins and is recorded as `match_tier` and `match_rule`.

| Tier | Rule | Resolves | Confidence |
|---|---|---|---|
| 1 | Labels `atlas-use-case-id` / `atlas-owner` already present | use case, owner | 100 |
| 2 | Backstage Resource entity whose `metadata.annotations['google.com/resource-name']` equals the asset name → `partOf` System → `ownedBy` Group | use case, business unit, owner | 90 |
| 3 | Terraform state entry with matching `id`; module inputs give use case and owner | use case, owner | 85 |
| 4 | Project crosswalk (`GCP_PROJECT` → use case) plus `creator_email` from audit logs | use case, owner | 70 |
| 5 | Project crosswalk only | use case, no owner | 50 |
| — | Nothing above hits | `UNMATCHED`, goes to review | 0 |

Tier 5 hits create the resource under a use case but leave `ml_workspace` owner as the use case's business-unit owner, flagged `ORPHANED` until a human assigns it. Nothing below tier 4 is accepted silently in APPLY mode without a verified crosswalk row.

### 11.4 Upsert shape

```sql
-- Example: workstation from a matched inventory row
INSERT INTO workstation (
    ml_workspace_id, workstation_config_id, implementation, url, launch_url,
    lifecycle_status, external_resource_name, origin, reconcile_status,
    last_reconciled_at, source_labels
) VALUES (
    $ws, $cfg, $impl, $url, $launch_url,
    $lifecycle, $asset_name, 'IMPORTED', 'IN_SYNC',
    CURRENT_TIMESTAMP, $labels::jsonb
)
ON CONFLICT (external_resource_name) WHERE deleted_at IS NULL
DO UPDATE SET
    lifecycle_status   = EXCLUDED.lifecycle_status,
    url                = EXCLUDED.url,
    launch_url         = EXCLUDED.launch_url,
    source_labels      = EXCLUDED.source_labels,
    reconcile_status   = CASE
                           WHEN workstation.workstation_config_id <> EXCLUDED.workstation_config_id
                             OR workstation.lifecycle_status      <> EXCLUDED.lifecycle_status
                           THEN 'DRIFTED' ELSE 'IN_SYNC' END,
    last_reconciled_at = CURRENT_TIMESTAMP,
    updated_at         = CURRENT_TIMESTAMP;
```

Rows present in Atlas but absent from the latest inventory get `reconcile_status = 'MISSING'`. They are not soft-deleted automatically; a human confirms, because a CAI export lag or a permission gap looks identical to a real deletion.

### 11.5 Unmatched review loop

The unmatched report is a table of `asset_name`, `asset_type`, `project_id`, `labels`, `creator_email`, `create_time`, grouped by project. Use case owners fill in use case and owner through an admin screen or a CSV that writes `entity_crosswalk` rows with `verified_by` set. The next DRY_RUN picks those up. Repeat until the unmatched count per type is acceptable, then APPLY.

---

## 12. Acceptance checks before declaring the baseline done

| Check | Pass condition |
|---|---|
| Inventory completeness | `count(inventory_asset)` per type equals the CAI export count per type |
| Conservation | matched + unmatched + ignored = inventory, per type |
| Match rate | ≥ 95% of workstations and endpoints matched at tier ≤ 4; report the rest by project |
| Referential integrity | Every imported row has a non-null parent chain up to business unit (enforced by FKs) |
| Idempotency | Second APPLY on the same snapshot changes zero rows |
| Spot check | 20 resources per type confirmed correct by their owners |
| Operation audit | One `BACKFILL_IMPORT` operation per imported row; `count` matches |
| No secrets | `source_labels` and `resource` JSON scanned for token-shaped strings |

---

## 13. After the baseline: staying in sync

1. **Scheduled reconcile.** Run the same job in APPLY mode nightly against a fresh CAI export. Emit metrics: drifted, missing, orphaned, unmatched, by type.
2. **Near-real-time.** Create a CAI feed on the same asset types publishing to Pub/Sub. A subscriber in the experience layer upserts single assets as they change, with `trigger = 'ASSET_FEED'`.
3. **Out-of-band creation is a finding.** A new asset that arrives via feed or nightly run with no matching `operation` was created outside Atlas. Alert on it. This is the measurable version of the workshop's console-permissions risk, and its trend to zero is how you know the API-led model has landed.
4. **Ownership changes.** Backstage group and system changes update `entity_crosswalk`; re-run matching for affected projects.
5. **Cutover.** Phase 1 shadow (DRY_RUN nightly, no gating). Phase 2 baseline APPLY, Atlas provisions new resources. Phase 3 tighten console permissions; drift becomes an alert rather than expected background.

---

# Part 3: API Reference

The full route-by-route reference, with request and response bodies, the error table, the session context contract, the concurrency rule, the `session_event` audit table, and the admin routes for reconciliation, lives in [atlas-api-reference.md](atlas-api-reference.md). The machine-readable contract is [openapi/atlas-experience-api.yaml](../openapi/atlas-experience-api.yaml).

Part 3 adds `RECONCILE` to `operation_type_enum`, `session_end_reason_enum`, and the tables `session_event` and `idempotency_key`.
