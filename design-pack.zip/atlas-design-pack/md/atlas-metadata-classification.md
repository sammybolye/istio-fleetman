# Atlas Session Database: Metadata Classification

**Scope:** Every table and enumerated value in the Atlas Cloud SQL database, classified by what kind of metadata it is, who writes it, when, and how it is hydrated for resources that already exist.
**Companions:** [atlas-session-persistence-spec.md](atlas-session-persistence-spec.md), [atlas-terraform-hydration.md](atlas-terraform-hydration.md), [atlas-source-material.md](atlas-source-material.md)

---

## 1. Why classify

The database mixes four very different kinds of data: values that never change except by a code release, dimensions that change when the organisation changes, rows that the platform writes every second, and scaffolding used only during reconciliation. Treating them the same causes predictable problems: seed data drifts between environments, someone edits a lookup value through the API, runtime tables get truncated in a test refresh that should have reset only staging, or a backfill overwrites a value a human curated.

Each class below has its own writer, source of truth, hydration path, change control, and retention rule.

```mermaid
flowchart LR
    subgraph static[Tier 1: Static, ships with code]
        C1[C1 Enumerations<br/>Postgres ENUM types]
        C2[C2 Reference lookups<br/>role, rtl_stage, system users]
    end
    subgraph managed[Tier 2: Managed, changes with the organisation]
        C3[C3 Master data<br/>business_unit, use_case, user, application]
        C4[C4 Catalogue<br/>pipeline_template, pipeline_component,<br/>workstation_configuration presets]
    end
    subgraph runtime[Tier 3: Runtime, written by the platform]
        C5[C5 Resource state<br/>ml_workspace, workstation, notebook,<br/>experiment, pipeline_job, model, model_endpoint]
        C6[C6 Activity ledger<br/>session, operation, operation_event]
    end
    subgraph support[Tier 4: Support, exists to hydrate and reconcile]
        C7[C7 Staging and crosswalk<br/>reconcile_run, inventory_asset, entity_crosswalk,<br/>tf_state_snapshot, tf_resource_instance, tf_run]
    end

    MIG[Migrations and seed DML] --> C1
    MIG --> C2
    ONB[Onboarding API, admin screens] --> C3
    SYNC[AD, Backstage, CMDB sync] --> C3
    PUB[Platform team publish, CI] --> C4
    API[Experience API] --> C6
    API --> C5
    WRK[Worker] --> C6
    WRK --> C5
    REAP[Reaper] --> C6
    REC[Reconciler, Terraform ingest] --> C7
    C7 -->|hydrate| C3
    C7 -->|hydrate| C5
    C7 -->|hydrate history| C6
    HUM[Use case owners] -->|verify crosswalk| C7
```

![Metadata classes and their writers](atlas-design-pack/diagrams/metadata-classes.png)

*Rendered: [PNG](atlas-design-pack/diagrams/metadata-classes.png) · [SVG](atlas-design-pack/diagrams/metadata-classes.svg) · [Mermaid source](atlas-design-pack/diagrams/metadata-classes.mmd)*

---

## 2. The seven classes at a glance

| Class | Contents | Written by | When | Source of truth | Hydration for existing estate | Change rate |
|---|---|---|---|---|---|---|
| **C1 Enumerations** | Postgres `ENUM` types | Schema migration | Deploy | Code repository | None. Values are definitional. | Rare, by release |
| **C2 Reference lookups** | `role`, `rtl_stage`, system users in `"user"` | Seed DML in migration | Deploy | Code repository | None. Same seed in every environment. | Rare, by release |
| **C3 Master data** | `business_unit`, `use_case`, `"user"` (people), `application` | Onboarding API, admin screens, scheduled sync | Onboarding, then nightly sync | AD for people, Backstage for org units and systems, CMDB for AL numbers, Atlas for use case attributes it owns | Spec Part 2 steps 3 to 5 via `entity_crosswalk` | Slow, weekly |
| **C4 Catalogue** | `pipeline_template`, `pipeline_component`, `pipeline_template_component`, `workstation_configuration` rows that are presets | Platform team through publish API or CI | Release of a template or preset | Artifact Registry for templates, git for presets | Spec Part 2 step 10 from Artifact Registry | Occasional |
| **C5 Resource state** | `ml_workspace`, `workstation`, `notebook`, `experiment`, `pipeline_job`, `model`, `model_endpoint`, and bespoke `workstation_configuration` rows | Experience API at accept time, worker at completion, reconciler on drift | Runtime | GCP for existence and current state, Atlas for intent | Spec Part 2 steps 6 to 11, Terraform hydration section 4.5 | Continuous |
| **C6 Activity ledger** | `session`, `operation`, `operation_event` | Experience API, worker, reaper | Runtime | Atlas only. Nothing else records this. | Terraform hydration section 4.3 reconstructs history; `BACKFILL_IMPORT` operations mark inventory imports | High, per request |
| **C7 Staging and crosswalk** | `reconcile_run`, `inventory_asset`, `entity_crosswalk`, `tf_state_snapshot`, `tf_resource_instance`, `tf_run` | Reconciler jobs, Terraform ingest endpoint, humans verifying crosswalk rows | Scheduled and on ingest | External systems, except `entity_crosswalk` which humans own once verified | It is the hydration mechanism | Batch |

Three tables need a second look because they straddle classes:

- **`"user"`** holds people (C3, synced from AD) and system principals such as `terraform-ci`, `atlas-reconciler`, `atlas-reaper` (C2, seeded). Add an `is_system` boolean so syncs never soft-delete a system principal and so screens can hide them.
- **`workstation_configuration`** holds curated presets that many workstations share (C4) and bespoke rows created when a user asks for a custom size (C5). Add `preset_name VARCHAR(100)` that is non-null only for presets, and a partial unique index on it.
- **`entity_crosswalk`** starts as machine-generated staging but becomes curated master data once `verified_by` is set. Treat unverified rows as C7 and verified rows as C3 for change control and backup.

---

## 3. C1 Enumerations

### 3.1 Registry

| Type | Values | Class of table it appears in | Introduced by |
|---|---|---|---|
| `hosting_environment_enum` | `GCP`, `AZURE`, `ON_PREMISES` | C5 `ml_workspace` | Existing schema |
| `implementation_type_enum` | `JUPYTER`, `VSCODE`, `CUSTOM` | C5 `notebook`, `workstation` | Existing schema |
| `model_execution_mode_enum` | `ONLINE`, `BATCH` | C5 `model` | Existing schema |
| `session_status_enum` | `ACTIVE`, `IDLE`, `ENDED`, `EXPIRED` | C6 `session` | Spec section 4 |
| `operation_type_enum` | `CREATE_ML_WORKSPACE`, `DELETE_ML_WORKSPACE`, `CREATE_WORKSTATION`, `RESIZE_WORKSTATION`, `START_WORKSTATION`, `STOP_WORKSTATION`, `DELETE_WORKSTATION`, `RUN_PIPELINE_JOB`, `DEPLOY_MODEL_ENDPOINT`, `PROMOTE_MODEL_ENDPOINT`, `BACKFILL_IMPORT`, `TF_IMPORT_CREATE`, `TF_IMPORT_UPDATE`, `TF_IMPORT_DELETE` | C6 `operation` | Spec section 4, Part 2, Terraform hydration |
| `operation_status_enum` | `PENDING`, `RUNNING`, `AWAITING_APPROVAL`, `SUCCEEDED`, `FAILED`, `CANCELLED` | C6 `operation`, `operation_event` | Spec section 4 |
| `target_entity_type_enum` | `ML_WORKSPACE`, `WORKSTATION`, `PIPELINE_JOB`, `MODEL_ENDPOINT` | C6 `operation` | Spec section 4 |
| `lifecycle_status_enum` | `PROVISIONING`, `READY`, `STOPPED`, `FAILED`, `DELETING` | C5 `ml_workspace`, `workstation` | Spec section 4.1 |
| `origin_enum` | `ATLAS`, `IMPORTED`, `SYNTHESIZED` | C5 all resource tables | Spec Part 2 section 9 |
| `reconcile_status_enum` | `IN_SYNC`, `DRIFTED`, `ORPHANED`, `MISSING` | C5 all resource tables | Spec Part 2 section 9 |
| `tf_change_kind_enum` | `CREATE`, `UPDATE`, `DELETE`, `NO_OP`, `REPLACE` | C7 `tf_resource_instance` | Terraform hydration section 3 |

### 3.2 Values currently coded as VARCHAR that should be constrained

These are lists of values in everything but declaration. Either promote them to enums or add `CHECK` constraints so a typo cannot create a new category. `CHECK` is the lighter choice for values a job writes; enum is better for values the API exposes.

```sql
ALTER TABLE session
    ADD CONSTRAINT chk_session_client_type
    CHECK (client_type IN ('WEB', 'VSCODE', 'SDK', 'CLI'));

ALTER TABLE reconcile_run
    ADD CONSTRAINT chk_reconcile_run_mode    CHECK (mode IN ('DRY_RUN', 'APPLY')),
    ADD CONSTRAINT chk_reconcile_run_trigger CHECK (trigger IN ('BACKFILL', 'SCHEDULED', 'ASSET_FEED', 'MANUAL', 'TF_INGEST'));

ALTER TABLE inventory_asset
    ADD CONSTRAINT chk_inventory_match_status CHECK (match_status IN ('MATCHED', 'UNMATCHED', 'IGNORED')),
    ADD CONSTRAINT chk_inventory_match_tier   CHECK (match_tier BETWEEN 1 AND 5);

ALTER TABLE entity_crosswalk
    ADD CONSTRAINT chk_crosswalk_source CHECK (source_system IN
        ('BACKSTAGE_GROUP', 'BACKSTAGE_SYSTEM', 'GCP_PROJECT', 'LABEL', 'AD_GROUP', 'TF_MODULE', 'TF_WORKSPACE')),
    ADD CONSTRAINT chk_crosswalk_target CHECK (target_entity_type IN ('BUSINESS_UNIT', 'USE_CASE', 'USER'));

ALTER TABLE tf_run
    ADD CONSTRAINT chk_tf_run_source CHECK (source_system IN
        ('TFC', 'ATLANTIS', 'CLOUD_BUILD', 'GITHUB_ACTIONS', 'GITLAB_CI', 'GCS_GENERATION')),
    ADD CONSTRAINT chk_tf_run_status CHECK (status IN ('APPLIED', 'ERRORED', 'DISCARDED'));
```

### 3.3 Rules for enumerations

- **Enum when** the value is a pure tag the API exposes and the set changes only by release: statuses, types, kinds.
- **Lookup table (C2) when** each value needs attributes, ordering, or relationships: roles have descriptions, stages have next and previous.
- **Add values only**, never rename or remove. `ALTER TYPE ... ADD VALUE` is safe. Removing a value requires a rewrite of every row that uses it and is a data migration, not a schema change.
- Every enum lives in the migration repository with a comment stating which class of table uses it. The registry above is the human-readable index.

---

## 4. C2 Reference lookups and seed DML

Seeds are idempotent, run on every deploy, and are identical in every environment. They use `ON CONFLICT` so a re-run is a no-op and a changed description propagates.

### 4.1 Roles

The existing schema has a `role` table with no values shown. The workshop names these personas: data scientists, use case owners who manage access, business approvers who approve business unit membership and GPU spend, platform administrators, and a more restricted Risk persona still to be defined. Seed those five and treat the list as proposed until the product team confirms.

```sql
INSERT INTO role (role_id, name, description) VALUES
    ('DATA_SCIENTIST',    'Data Scientist',    'Works within use cases they have been granted access to. Creates workbenches, runs pipelines, registers models.'),
    ('USE_CASE_OWNER',    'Use Case Owner',    'Accountable for a use case. Grants and recertifies access, approves resources within the use case.'),
    ('BUSINESS_APPROVER', 'Business Approver', 'Approves business unit membership and cost-bearing requests such as GPU workbenches.'),
    ('PLATFORM_ADMIN',    'Platform Admin',    'Operates Atlas. Manages catalogue, presets, crosswalk, and reconciliation.'),
    ('RISK_USER',         'Risk User',         'Restricted persona for Risk teams. Capabilities to be defined in a follow-up workshop.')
ON CONFLICT (role_id) DO UPDATE
    SET name = EXCLUDED.name,
        description = EXCLUDED.description,
        updated_at = CURRENT_TIMESTAMP,
        deleted_at = NULL;
```

### 4.2 Route-to-live stages

The page's relationship notes describe promotion from development to Data Test and then to Data Run. Seed the chain accordingly. Because `next_stage_id` and `prev_stage_id` reference the same table, insert the rows first and link them second.

```sql
INSERT INTO rtl_stage (stage_id, name) VALUES
    ('DEVELOPMENT', 'Development'),
    ('DATA_TEST',   'Data Test'),
    ('DATA_RUN',    'Data Run')
ON CONFLICT (stage_id) DO UPDATE
    SET name = EXCLUDED.name, updated_at = CURRENT_TIMESTAMP, deleted_at = NULL;

UPDATE rtl_stage SET next_stage_id = 'DATA_TEST', prev_stage_id = NULL          WHERE stage_id = 'DEVELOPMENT';
UPDATE rtl_stage SET next_stage_id = 'DATA_RUN',  prev_stage_id = 'DEVELOPMENT' WHERE stage_id = 'DATA_TEST';
UPDATE rtl_stage SET next_stage_id = NULL,        prev_stage_id = 'DATA_TEST'   WHERE stage_id = 'DATA_RUN';
```

If the bank's route-to-live has more stages, add them to this seed. Do not let the API create stages.

### 4.3 System principals

Operations require a `user_id`. The reaper, the reconciler, the Terraform ingest, and backfilled Terraform history all need a principal to attribute to. Seed them as users with fixed UUIDs so every environment agrees on the IDs and so foreign keys in imported history resolve.

```sql
ALTER TABLE "user" ADD COLUMN IF NOT EXISTS is_system BOOLEAN NOT NULL DEFAULT FALSE;

INSERT INTO "user" (user_id, principal_email, name, staff_id, role_id, is_system) VALUES
    ('00000000-0000-0000-0000-000000000001', 'atlas-reaper@atlas.system',     'Atlas Session Reaper',   NULL, 'PLATFORM_ADMIN', TRUE),
    ('00000000-0000-0000-0000-000000000002', 'atlas-reconciler@atlas.system', 'Atlas Reconciler',       NULL, 'PLATFORM_ADMIN', TRUE),
    ('00000000-0000-0000-0000-000000000003', 'terraform-ci@atlas.system',     'Terraform CI (legacy)',  NULL, 'PLATFORM_ADMIN', TRUE),
    ('00000000-0000-0000-0000-000000000004', 'atlas-backfill@atlas.system',   'Atlas Backfill',         NULL, 'PLATFORM_ADMIN', TRUE)
ON CONFLICT (user_id) DO UPDATE
    SET name = EXCLUDED.name, role_id = EXCLUDED.role_id, is_system = TRUE,
        updated_at = CURRENT_TIMESTAMP, deleted_at = NULL;
```

The AD sync must skip rows where `is_system` is true, otherwise it will soft-delete them as unknown people.

### 4.4 Seed versioning

Record which seed set is applied so an environment can be checked without diffing rows.

```sql
CREATE TABLE IF NOT EXISTS seed_version (
    seed_name   VARCHAR(100) PRIMARY KEY,   -- 'role', 'rtl_stage', 'system_users'
    version     INT NOT NULL,
    applied_at  TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    applied_by  VARCHAR(255) NOT NULL       -- migration tool identity
);

INSERT INTO seed_version (seed_name, version, applied_by) VALUES
    ('role', 1, 'migration'), ('rtl_stage', 1, 'migration'), ('system_users', 1, 'migration')
ON CONFLICT (seed_name) DO UPDATE SET version = EXCLUDED.version, applied_at = CURRENT_TIMESTAMP;
```

### 4.5 What is deliberately not seeded

`application` rows (AL numbers) come from the CMDB and are master data, not reference data. `business_unit` and `use_case` are onboarded, not seeded, even in non-production, because seeding them hides the onboarding path from testing. Test environments get a small onboarding script that exercises the real API instead.

---

## 5. C3 Master data

| Table | External source | How it arrives on day one | How it stays current | What Atlas owns locally |
|---|---|---|---|---|
| `business_unit` | Backstage Groups of type business unit or department | Spec Part 2 step 3 through `entity_crosswalk` | Nightly Backstage sync; a group rename updates `name`, a group removal soft-deletes after a grace period | `owner_id` if not derivable from the group lead |
| `use_case` | Backstage Systems, project labels for cost centre | Spec Part 2 step 4 | Nightly sync for name and cost centre; new use cases arrive through the onboarding API and are pushed back to Backstage | Labels for grouping, once added; owner list, once modelled |
| `"user"` (people) | AD or Entra by user principal name | Spec Part 2 step 5, scoped to principals seen in the inventory or IAM | Nightly sync for `name`, `staff_id`; leavers soft-deleted after the leaver process confirms | `role_id` when not derivable from group membership |
| `application` | CMDB AL numbers | From project labels during Part 2 step 11 where present | Lookup on demand against the CMDB when a promotion to Data Run needs one | Nothing |

Rules:

- **Soft delete only, with a grace period.** A sync that suddenly sees zero groups must not delete every business unit. Cap deletions per run and alert above the cap.
- **Sync writes the external key.** Each master table gains an `external_ref TEXT` column (Backstage entity ref, AD object id, CMDB CI id) with a partial unique index, so re-syncs match on identity rather than name.
- **Two open items from the workshop live here.** Use case membership and multiple owners are not in the schema yet. When they are added, they are C3, they arrive through the onboarding API, and the Backstage sync is their catch-up path.

---

## 6. C4 Catalogue

| Table | What a row is | Published by | Source of truth | Hydration |
|---|---|---|---|---|
| `pipeline_template` | A versioned Kubeflow pipeline template | Platform team CI on tag | Artifact Registry KFP repository | Spec Part 2 step 10 lists the repository |
| `pipeline_component` | A reusable component referenced by templates | Same | Compiled template YAML | Parsed from templates |
| `pipeline_template_component` | The DAG membership of a component in a template | Same | Same | Same |
| `workstation_configuration` where `preset_name IS NOT NULL` | A curated size such as `small-cpu`, `standard-cpu`, `gpu-t4` | Platform team through a presets API or a seed-like publish step | git | None needed; presets are new with Atlas |

```sql
ALTER TABLE workstation_configuration ADD COLUMN preset_name VARCHAR(100);
CREATE UNIQUE INDEX uq_workstation_config_preset_active
    ON workstation_configuration(preset_name)
    WHERE deleted_at IS NULL AND preset_name IS NOT NULL;
```

Presets are catalogue. A bespoke configuration created because a user asked for 12 vCPU is resource state (C5) and is owned by the workstation that uses it. The API should offer presets first and create bespoke rows only when policy allows.

Catalogue rows are never edited in place once referenced. A new template version is a new row; the old row is soft-deleted when nothing references it. That keeps `pipeline_job.template_id` pointing at what actually ran.

---

## 7. C5 Resource state

These rows describe things that exist, or are coming to exist, in GCP. Every one carries the four provenance columns from Part 2: `external_resource_name`, `origin`, `reconcile_status`, `last_reconciled_at`, plus `source_labels`.

| Table | Created by | Moved to READY or equivalent by | Changed later by | Hydration path |
|---|---|---|---|---|
| `ml_workspace` | API on `CREATE_ML_WORKSPACE` accept, or synthesized by backfill | Worker on success | API on `DELETE_ML_WORKSPACE` | Part 2 step 7, `origin = SYNTHESIZED` |
| `workstation`, bespoke `workstation_configuration` | API on `CREATE_WORKSTATION` accept, status `PROVISIONING` | Worker on success, with `url`, `launch_url`, `external_resource_name` | Worker on resize, start, stop, delete; reconciler on drift | Part 2 step 8, Terraform hydration 4.5 |
| `notebook`, `notebook_spec` | Same pattern if Notebook stays in the model | Same | Same | Part 2 step 8 |
| `experiment` | API when a user creates one, or worker when a pipeline run implies one | Immediate | Rarely | Part 2 step 9 |
| `pipeline_job` | API on `RUN_PIPELINE_JOB` accept | Worker with `job_identifier` from Vertex | Worker on completion status if modelled | Part 2 step 10 |
| `model` | Worker after a pipeline job registers a model | Immediate | Worker on deploy | Part 2 step 11 |
| `model_endpoint` | API on `DEPLOY_MODEL_ENDPOINT` accept | Worker on success with `inference_url` | Worker on `PROMOTE_MODEL_ENDPOINT` | Part 2 step 11, Terraform hydration for endpoints |

Rules:

- **The API writes intent, the worker writes outcome.** A row can exist with `lifecycle_status = PROVISIONING` and no external name. That is a legitimate state, not an error.
- **The reconciler never changes intent columns.** It updates `reconcile_status`, `last_reconciled_at`, `source_labels`, and lifecycle where the cloud says the resource stopped or disappeared. It does not change `workstation_config_id` or `ml_workspace_id`. Those change only through an operation.
- **Imported rows are first-class.** A workstation with `origin = IMPORTED` is resized through the same operation as one Atlas created. The Terraform address stored on it is how the orchestrator finds it.

---

## 8. C6 Activity ledger

The only class where Atlas is the sole source of truth. Nothing outside the database records that a user opened a session or asked for a workbench.

| Table | Inserted by | Updated by | Never |
|---|---|---|---|
| `session` | API on start or attach | API on heartbeat, context change, end; reaper on idle and expiry | Hard-deleted before 90 days; written by the worker or reconciler |
| `operation` | API on every provisioning request; reconciler for `BACKFILL_IMPORT`; Terraform ingest for imported history | Worker on claim, retry, completion; API on cancel; approver on approve; stale-lease sweep | Hard-deleted; edited after a terminal status |
| `operation_event` | Whoever performs a transition, in the same transaction | Nobody | Updated or deleted, ever |

Columns that are themselves classifiable:

- `operation.request_payload` and `session.context` are **user-supplied JSON**. Validate shape at the API. Never store credentials, tokens, or data samples.
- `operation.result_payload` is **system-supplied JSON** from the orchestrator. Store it verbatim for audit; expose a projected view to clients.
- `operation_event.actor` is a **principal or a system identity** string, not a foreign key, so history survives a user being soft-deleted.

Hydration for this class means reconstructing history, and reconstructed rows are labelled as such: `origin` is not on these tables, so the label lives in `operation_event.detail` (`imported_from`) and in the operation type (`BACKFILL_IMPORT`, `TF_IMPORT_*`) or the idempotency key prefix (`tf:`, `backfill:`).

---

## 9. C7 Staging and crosswalk

| Table | Lifetime | Truncate in a test refresh? | Backup priority |
|---|---|---|---|
| `reconcile_run` | Keep 13 months for audit of what was reconciled when | No | Medium |
| `inventory_asset` | Rolling. Rows not seen for 90 days are deleted. | Yes | Low. Rebuildable from a fresh export. |
| `tf_state_snapshot`, `tf_resource_instance`, `tf_run` | Keep. They are the only copy of history if the bucket's versioning is later trimmed. | No | High |
| `entity_crosswalk` unverified | Rolling with the run that produced it | Yes | Low |
| `entity_crosswalk` verified | Permanent. This is curated knowledge. | **No** | **High**, same as master data |

The split on `entity_crosswalk` is the one most likely to be got wrong. A test refresh script that truncates staging must use `DELETE ... WHERE verified_by IS NULL`, never `TRUNCATE`.

---

## 10. Writers matrix

Which component may write which class. Anything not ticked is denied at the database role level, not just by convention.

| Writer | Database role | C1 | C2 | C3 | C4 | C5 | C6 | C7 |
|---|---|---|---|---|---|---|---|---|
| Schema migration | `atlas_migrator` | DDL | seed | | | DDL | DDL | DDL |
| Experience API | `atlas_api` | | | onboarding routes | publish routes | insert, cancel | insert, update | verify crosswalk |
| Worker | `atlas_worker` | | | | | update outcome | update, insert events | |
| Reaper | `atlas_reaper` | | | | | | update session, insert events | |
| Reconciler and Terraform ingest | `atlas_reconciler` | | | insert via crosswalk, sync updates | insert templates | insert imported, update reconcile columns | insert `BACKFILL_IMPORT` and `TF_IMPORT_*` | full |
| Humans | none direct | | | through API | through API | never | never | through API |

Grant the roles table by table. The worker cannot insert a session. The API cannot update `reconcile_status`. Nobody but the migrator can insert a role.

---

## 11. Governance summary per class

| Class | Change control | Environments | PII | Retention | Test data |
|---|---|---|---|---|---|
| C1 Enumerations | Pull request, schema migration | Identical everywhere | None | Forever | Same as production |
| C2 Reference | Pull request, seed DML, `seed_version` bump | Identical everywhere | None | Forever | Same as production |
| C3 Master | Onboarding API with approval; sync jobs; changes audited via `operation` where they are provisioning-relevant | Differs. Non-production has a small onboarded set. | **Yes**: `principal_email`, `name`, `staff_id` | While active plus leaver retention policy | Synthetic people, real business unit names allowed |
| C4 Catalogue | Publish pipeline with review | Non-production may lead production by a version | None | Until unreferenced, then soft delete | Same templates, smaller presets |
| C5 Resource state | Only through operations; reconciler for provenance columns | Differs entirely | Indirect: owner links to a person | Life of the resource plus 13 months soft-deleted | Provisioned against a sandbox project |
| C6 Activity ledger | Append-only by design; no manual edits | Differs entirely | **Yes**: `client_ip`, `user_agent`, actor emails | Sessions 90 days; operations and events 7 years or per audit policy | Generated by exercising the API |
| C7 Staging | Job-owned; crosswalk verification through admin API | Differs | Creator emails in `inventory_asset` | Per section 9 | Point at a sandbox inventory |

---

## 12. Checklist for adding a new table or column

1. Which class is it? If the answer is "two", split the table or add a discriminator column as done for `"user"` and `workstation_configuration`.
2. Who writes it, and does that writer's database role already have the grant?
3. What is its source of truth outside Atlas, if any, and what is the catch-up path for resources that already exist?
4. Is any value in it a list of values? Then it is an enum, a `CHECK`, or a C2 lookup, never free text.
5. Is it PII? Then it is in the retention table above and in the export filter.
6. Does a test refresh truncate it, reseed it, or leave it alone?
