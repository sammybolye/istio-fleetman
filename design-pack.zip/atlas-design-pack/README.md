# Atlas Session Persistence Design Pack

Design documents for durable session and operation persistence in the Atlas ML Platform experience layer (GKE + Cloud SQL for PostgreSQL), produced 3–7 September 2026 from the workshop notes, entity model, and DDL screenshots in `matlas-session/`.

Everything is plain text first. Every diagram is embedded in the Markdown as a Mermaid code block, and also provided as PNG, SVG, and `.mmd` source in `diagrams/`. The HTML pages are standalone (open in a browser, no server) and are also published as private Claude artifacts.

## Documents

| # | Document | Markdown | HTML | Artifact |
|---|---|---|---|---|
| 0 | **Source material (transcription)** — workshop notes, open questions, ERD, full existing DDL, storage comparison, and the Gemini session, all as text | [md/atlas-source-material.md](md/atlas-source-material.md) | — | — |
| 1 | **Session and Operation Persistence Spec** — tables, worker pattern, API contract. Part 2: inventory backfill and reconciliation. | [md/atlas-session-persistence-spec.md](md/atlas-session-persistence-spec.md) | [html/atlas-session-persistence-spec.html](html/atlas-session-persistence-spec.html) | https://claude.ai/code/artifact/bdb55ae2-6d94-492e-a851-35e523090053 |
| 2 | **Provisioning Chain of Events** — one workbench request from click to ready; state after each commit; five failure windows and recovery. | [md/atlas-provisioning-chain-of-events.md](md/atlas-provisioning-chain-of-events.md) | [html/atlas-provisioning-chain-of-events.html](html/atlas-provisioning-chain-of-events.html) | https://claude.ai/code/artifact/a42a87ca-45e1-4a1e-a628-02467c8d2bba |
| 3 | **Terraform Hydration** — populating operation history and resource intent from Terraform state generations and run records. | [md/atlas-terraform-hydration.md](md/atlas-terraform-hydration.md) | [html/atlas-terraform-hydration.html](html/atlas-terraform-hydration.html) | https://claude.ai/code/artifact/627bb82d-2ef0-4a45-8761-82dbf7433251 |
| 5 | **API Reference (Part 3)** — every session, operation, provisioning, and admin route with bodies, error table, context contract, concurrency rule, session audit trail. | [md/atlas-api-reference.md](md/atlas-api-reference.md) | [html/atlas-api-reference.html](html/atlas-api-reference.html) | https://claude.ai/code/artifact/54e567f4-ef0f-4a37-89ef-ac50eddb20e4 |
| 4 | **Metadata Classification** — seven classes of data (enumerations, reference lookups with seed DML, master, catalogue, resource state, activity ledger, staging), writers matrix, governance. | [md/atlas-metadata-classification.md](md/atlas-metadata-classification.md) | [html/atlas-metadata-classification.html](html/atlas-metadata-classification.html) | https://claude.ai/code/artifact/55ac3075-4b8e-4540-afff-d9840f65e47a |

## OpenAPI (`openapi/`)

`atlas-experience-api.yaml` is the OpenAPI 3.1 contract for everything in document 5. It lints clean with Redocly (`npx @redocly/cli lint openapi/atlas-experience-api.yaml`); the remaining warnings are missing 4xx responses on provisioning routes and are intentional.

## Diagrams (`diagrams/`)

| File stem | What it shows | Used in |
|---|---|---|
| `atlas-entity-model` | The existing Atlas entity model as an ERD, transcribed from the Confluence page | Source material A.3 |
| `entity-additions` | New tables: session, operation, operation_event, and their links | Spec §3 |
| `operation-lifecycle` | Operation status state machine (`.mermaid.svg` is the hand-drawn version from the HTML page) | Spec §6.4 |
| `provisioning-sequence` | Sequence diagram of one workbench request across client, edge, API, Cloud SQL, worker, orchestrator, GCP | Chain of Events §2 |
| `hydration-data-flow` | Inventory backfill: sources, staging, matching tiers, Atlas tables | Spec §11 |
| `terraform-hydration-flow` | Terraform hydration: collect, stage, transform, write, reconcile | Terraform Hydration §4 |
| `metadata-classes` | The seven metadata classes and who writes each | Metadata Classification §1 |

Each stem has `.mmd` (Mermaid source), `.svg`, and `.png` (2x).

## Reading order

1. Source material, if you were not in the workshop.
2. Spec sections 1–8: what a session is, the operation table, the worker, the API.
3. Chain of Events: why persist-first, and how at-least-once plus an idempotent orchestrator gives exactly-once effect.
4. Metadata Classification: which tables are seeded, onboarded, written at runtime, or staging.
5. API Reference: the full route contract, then the OpenAPI file for client generation.
6. Spec Part 2 (sections 9–13): hydrating what exists from Cloud Asset Inventory.
7. Terraform Hydration: hydrating how it got there from state history.

## Notes on the HTML

- Fonts (IBM Plex) load from Google Fonts. Mermaid diagrams in documents 2 and 4 load Mermaid from jsDelivr. Those need internet access; everything else is self-contained.
- Pages follow the viewer's light or dark preference.

## Open decisions carried across the documents

- Does the orchestrator accept an idempotency key and allow lookup by it?
- Does Notebook stay in the entity model, or do Workbench instances map to Workstation with a Jupyter implementation?
- Who owns the Backstage-to-Atlas crosswalk for business units and use cases?
- Is Terraform state bucket object versioning enabled? If not, enable it now so history starts accruing.
- Confirm the five seeded roles and the three route-to-live stages with the product team.
