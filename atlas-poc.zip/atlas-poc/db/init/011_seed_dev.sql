-- dev-only seed. do not ship. fixed uuids so the readme examples work.

-- people (would come from AD)
INSERT INTO "user" (user_id, principal_email, name, staff_id, role_id) VALUES
    ('10000000-0000-0000-0000-000000000001', 'alice@example.com', 'Alice Okafor',   'S100001', 'DATA_SCIENTIST'),
    ('10000000-0000-0000-0000-000000000002', 'bob@example.com',   'Bob Lindqvist',  'S100002', 'USE_CASE_OWNER'),
    ('10000000-0000-0000-0000-000000000003', 'carol@example.com', 'Carol Mensah',   'S100003', 'BUSINESS_APPROVER'),
    ('10000000-0000-0000-0000-000000000004', 'dan@example.com',   'Dan Whitfield',  'S100004', 'PLATFORM_ADMIN')
ON CONFLICT (user_id) DO NOTHING;

-- bu + use case (would come from backstage)
INSERT INTO business_unit (business_unit_id, name, owner_id, external_ref) VALUES
    ('20000000-0000-0000-0000-000000000001', 'Consumer Lending', '10000000-0000-0000-0000-000000000003', 'group:default/consumer-lending')
ON CONFLICT (business_unit_id) DO NOTHING;

INSERT INTO use_case (use_case_id, business_unit_id, name, cost_centre, external_ref) VALUES
    ('30000000-0000-0000-0000-000000000001', '20000000-0000-0000-0000-000000000001', 'Affordability Model', 'CC-4471', 'system:default/affordability-model')
ON CONFLICT (use_case_id) DO NOTHING;

INSERT INTO use_case_member (use_case_id, user_id, is_owner, granted_by) VALUES
    ('30000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000002', TRUE,  NULL),
    ('30000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', FALSE, '10000000-0000-0000-0000-000000000002')
ON CONFLICT DO NOTHING;

INSERT INTO entity_crosswalk (source_system, source_key, target_entity_type, target_entity_id, confidence, verified_by, verified_at) VALUES
    ('BACKSTAGE_GROUP',  'group:default/consumer-lending',     'BUSINESS_UNIT', '20000000-0000-0000-0000-000000000001', 100, 'dan@example.com', CURRENT_TIMESTAMP),
    ('BACKSTAGE_SYSTEM', 'system:default/affordability-model', 'USE_CASE',      '30000000-0000-0000-0000-000000000001', 100, 'dan@example.com', CURRENT_TIMESTAMP),
    ('GCP_PROJECT',      'cl-affordability-dev',               'USE_CASE',      '30000000-0000-0000-0000-000000000001', 100, 'dan@example.com', CURRENT_TIMESTAMP)
ON CONFLICT (source_system, source_key) DO NOTHING;

-- workstation presets
INSERT INTO workstation_configuration (workstation_config_id, preset_name, cpu_count, memory, container, gpu_count) VALUES
    ('40000000-0000-0000-0000-000000000001', 'small-cpu',    4,  '16Gi', 'atlas/vscode:1.4', 0),
    ('40000000-0000-0000-0000-000000000002', 'standard-cpu', 8,  '32Gi', 'atlas/vscode:1.4', 0),
    ('40000000-0000-0000-0000-000000000003', 'gpu-t4',       8,  '32Gi', 'atlas/vscode-cuda:1.4', 1)
ON CONFLICT (workstation_config_id) DO NOTHING;

-- alice's workspace, already provisioned
INSERT INTO ml_workspace (ml_workspace_id, use_case_id, owner_id, hosting_env, lifecycle_status, origin) VALUES
    ('50000000-0000-0000-0000-000000000001', '30000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', 'GCP', 'READY', 'ATLAS')
ON CONFLICT (ml_workspace_id) DO NOTHING;

-- one workstation that was imported from the existing estate rather than created here
INSERT INTO workstation (workstation_id, ml_workspace_id, workstation_config_id, implementation, url, launch_url,
                         lifecycle_status, external_resource_name, origin, reconcile_status, last_reconciled_at,
                         source_labels, tf_address, tf_workspace) VALUES
    ('60000000-0000-0000-0000-000000000001', '50000000-0000-0000-0000-000000000001', '40000000-0000-0000-0000-000000000001', 'VSCODE',
     'alice-small.cl-affordability-dev.workstations.example', 'https://80-alice-small.cl-affordability-dev.workstations.example',
     'READY', '//workstations.googleapis.com/projects/cl-affordability-dev/locations/europe-west2/workstationClusters/cl/workstationConfigs/small-cpu/workstations/alice-small',
     'IMPORTED', 'IN_SYNC', CURRENT_TIMESTAMP,
     '{"env":"dev","team":"cl-ds","owner":"alice"}'::jsonb,
     'module.ds_workbench["alice"].google_workstations_workstation.this', 'ds-workbenches-dev')
ON CONFLICT (workstation_id) DO NOTHING;

-- and the import operation that brought it in
INSERT INTO operation (operation_id, session_id, user_id, use_case_id, operation_type, target_entity_type, target_entity_id,
                       idempotency_key, status, request_payload, result_payload, attempt_count, started_at, completed_at, created_at)
VALUES ('70000000-0000-0000-0000-000000000001', NULL, '00000000-0000-0000-0000-000000000004', '30000000-0000-0000-0000-000000000001',
        'BACKFILL_IMPORT', 'WORKSTATION', '60000000-0000-0000-0000-000000000001',
        'backfill:' || md5('//workstations.googleapis.com/projects/cl-affordability-dev/locations/europe-west2/workstationClusters/cl/workstationConfigs/small-cpu/workstations/alice-small'),
        'SUCCEEDED', '{"source":"cloud-asset-inventory","matchTier":2}'::jsonb, '{"imported":true}'::jsonb, 1,
        CURRENT_TIMESTAMP - INTERVAL '2 days', CURRENT_TIMESTAMP - INTERVAL '2 days', CURRENT_TIMESTAMP - INTERVAL '2 days')
ON CONFLICT (operation_id) DO NOTHING;

INSERT INTO operation_event (operation_id, from_status, to_status, actor, detail, created_at) VALUES
    ('70000000-0000-0000-0000-000000000001', NULL, 'PENDING', 'atlas-backfill@atlas.system', '{"imported_from":"inventory"}', CURRENT_TIMESTAMP - INTERVAL '2 days'),
    ('70000000-0000-0000-0000-000000000001', 'PENDING', 'RUNNING', 'atlas-backfill@atlas.system', '{}', CURRENT_TIMESTAMP - INTERVAL '2 days'),
    ('70000000-0000-0000-0000-000000000001', 'RUNNING', 'SUCCEEDED', 'atlas-backfill@atlas.system', '{}', CURRENT_TIMESTAMP - INTERVAL '2 days');

INSERT INTO seed_version (seed_name, version, applied_by) VALUES ('dev_estate', 1, 'init')
ON CONFLICT (seed_name) DO UPDATE SET version = EXCLUDED.version, applied_at = CURRENT_TIMESTAMP;
