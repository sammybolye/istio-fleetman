-- reference data. same in every env, safe to re-run.

INSERT INTO role (role_id, name, description) VALUES
    ('DATA_SCIENTIST',    'Data Scientist',    'Works within use cases they have been granted access to.'),
    ('USE_CASE_OWNER',    'Use Case Owner',    'Accountable for a use case. Grants and recertifies access.'),
    ('BUSINESS_APPROVER', 'Business Approver', 'Approves business unit membership and cost-bearing requests.'),
    ('PLATFORM_ADMIN',    'Platform Admin',    'Operates Atlas. Manages catalogue, presets, crosswalk, reconciliation.'),
    ('RISK_USER',         'Risk User',         'Restricted persona for Risk teams. Capabilities TBD.')
ON CONFLICT (role_id) DO UPDATE
    SET name = EXCLUDED.name, description = EXCLUDED.description, updated_at = CURRENT_TIMESTAMP, deleted_at = NULL;

INSERT INTO rtl_stage (stage_id, name) VALUES
    ('DEVELOPMENT', 'Development'),
    ('DATA_TEST',   'Data Test'),
    ('DATA_RUN',    'Data Run')
ON CONFLICT (stage_id) DO UPDATE SET name = EXCLUDED.name, updated_at = CURRENT_TIMESTAMP, deleted_at = NULL;
UPDATE rtl_stage SET next_stage_id = 'DATA_TEST', prev_stage_id = NULL          WHERE stage_id = 'DEVELOPMENT';
UPDATE rtl_stage SET next_stage_id = 'DATA_RUN',  prev_stage_id = 'DEVELOPMENT' WHERE stage_id = 'DATA_TEST';
UPDATE rtl_stage SET next_stage_id = NULL,        prev_stage_id = 'DATA_TEST'   WHERE stage_id = 'DATA_RUN';

INSERT INTO "user" (user_id, principal_email, name, staff_id, role_id, is_system) VALUES
    ('00000000-0000-0000-0000-000000000001', 'atlas-reaper@atlas.system',     'Atlas Session Reaper',  NULL, 'PLATFORM_ADMIN', TRUE),
    ('00000000-0000-0000-0000-000000000002', 'atlas-reconciler@atlas.system', 'Atlas Reconciler',      NULL, 'PLATFORM_ADMIN', TRUE),
    ('00000000-0000-0000-0000-000000000003', 'terraform-ci@atlas.system',     'Terraform CI (legacy)', NULL, 'PLATFORM_ADMIN', TRUE),
    ('00000000-0000-0000-0000-000000000004', 'atlas-backfill@atlas.system',   'Atlas Backfill',        NULL, 'PLATFORM_ADMIN', TRUE)
ON CONFLICT (user_id) DO UPDATE
    SET name = EXCLUDED.name, role_id = EXCLUDED.role_id, is_system = TRUE, updated_at = CURRENT_TIMESTAMP, deleted_at = NULL;

INSERT INTO seed_version (seed_name, version, applied_by) VALUES
    ('role', 1, 'init'), ('rtl_stage', 1, 'init'), ('system_users', 1, 'init')
ON CONFLICT (seed_name) DO UPDATE SET version = EXCLUDED.version, applied_at = CURRENT_TIMESTAMP;
