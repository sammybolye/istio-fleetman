-- reconciliation staging + crosswalk. schema only for now, no api over these yet.

CREATE TABLE reconcile_run (
    run_id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    mode         VARCHAR(20) NOT NULL CHECK (mode IN ('DRY_RUN', 'APPLY')),
    trigger      VARCHAR(50) NOT NULL CHECK (trigger IN ('BACKFILL', 'SCHEDULED', 'ASSET_FEED', 'MANUAL', 'TF_INGEST')),
    operation_id UUID REFERENCES operation(operation_id),
    snapshot_ref TEXT,
    started_at   TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    finished_at  TIMESTAMPTZ,
    summary      JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_by   VARCHAR(255) NOT NULL
);

CREATE TABLE inventory_asset (
    asset_name          TEXT PRIMARY KEY,
    asset_type          VARCHAR(120) NOT NULL,
    project_id          VARCHAR(63) NOT NULL,
    location            VARCHAR(63),
    labels              JSONB NOT NULL DEFAULT '{}'::jsonb,
    resource            JSONB NOT NULL,
    resource_state      VARCHAR(50),
    create_time         TIMESTAMPTZ,
    update_time         TIMESTAMPTZ,
    creator_email       VARCHAR(255),
    first_seen_run_id   UUID NOT NULL REFERENCES reconcile_run(run_id),
    last_seen_run_id    UUID NOT NULL REFERENCES reconcile_run(run_id),
    last_seen_at        TIMESTAMPTZ NOT NULL,
    match_status        VARCHAR(20) NOT NULL DEFAULT 'UNMATCHED' CHECK (match_status IN ('MATCHED', 'UNMATCHED', 'IGNORED')),
    match_tier          SMALLINT CHECK (match_tier BETWEEN 1 AND 5),
    match_rule          VARCHAR(100),
    matched_entity_type VARCHAR(30) CHECK (matched_entity_type IN ('WORKSTATION', 'NOTEBOOK', 'EXPERIMENT', 'PIPELINE_JOB', 'MODEL', 'MODEL_ENDPOINT')),
    matched_entity_id   UUID,
    review_note         TEXT
);
CREATE INDEX idx_inventory_asset_unmatched ON inventory_asset(asset_type) WHERE match_status = 'UNMATCHED';
CREATE INDEX idx_inventory_asset_project ON inventory_asset(project_id);

CREATE TABLE entity_crosswalk (
    crosswalk_id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_system      VARCHAR(50) NOT NULL CHECK (source_system IN ('BACKSTAGE_GROUP', 'BACKSTAGE_SYSTEM', 'GCP_PROJECT', 'LABEL', 'AD_GROUP', 'TF_MODULE', 'TF_WORKSPACE')),
    source_key         TEXT NOT NULL,
    target_entity_type VARCHAR(30) NOT NULL CHECK (target_entity_type IN ('BUSINESS_UNIT', 'USE_CASE', 'USER')),
    target_entity_id   UUID NOT NULL,
    confidence         SMALLINT NOT NULL CHECK (confidence BETWEEN 0 AND 100),
    verified_by        VARCHAR(255),
    verified_at        TIMESTAMPTZ,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (source_system, source_key)
);

CREATE TABLE seed_version (
    seed_name  VARCHAR(100) PRIMARY KEY,
    version    INT NOT NULL,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    applied_by VARCHAR(255) NOT NULL
);
