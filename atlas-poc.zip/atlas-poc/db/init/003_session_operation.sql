-- session + operation ledger

CREATE TABLE session (
    session_id      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES "user"(user_id) ON DELETE RESTRICT,
    use_case_id     UUID REFERENCES use_case(use_case_id) ON DELETE RESTRICT,
    ml_workspace_id UUID REFERENCES ml_workspace(ml_workspace_id) ON DELETE RESTRICT,
    status          session_status_enum NOT NULL DEFAULT 'ACTIVE',
    end_reason      session_end_reason_enum,
    client_type     VARCHAR(50) NOT NULL,
    client_ip       INET,
    user_agent      TEXT,
    context         JSONB NOT NULL DEFAULT '{}'::jsonb,
    started_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_seen_at    TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at      TIMESTAMPTZ NOT NULL,
    ended_at        TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at      TIMESTAMPTZ DEFAULT NULL,
    CONSTRAINT chk_session_client_type CHECK (client_type IN ('WEB', 'VSCODE', 'SDK', 'CLI')),
    CONSTRAINT chk_session_ended CHECK ((status IN ('ENDED', 'EXPIRED')) = (ended_at IS NOT NULL))
);
CREATE INDEX idx_session_user_live ON session(user_id, client_type, last_seen_at DESC)
    WHERE deleted_at IS NULL AND status IN ('ACTIVE', 'IDLE');
CREATE INDEX idx_session_use_case ON session(use_case_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_session_reaper ON session(expires_at) WHERE deleted_at IS NULL AND status IN ('ACTIVE', 'IDLE');
CREATE INDEX idx_session_list ON session(last_seen_at DESC, session_id DESC) WHERE deleted_at IS NULL;

CREATE TABLE session_event (
    session_event_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id       UUID NOT NULL REFERENCES session(session_id) ON DELETE RESTRICT,
    event_type       VARCHAR(30) NOT NULL,
    from_status      session_status_enum,
    to_status        session_status_enum,
    actor            VARCHAR(255) NOT NULL,
    detail           JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_session_event_type CHECK (event_type IN ('STARTED', 'CONTEXT_CHANGED', 'IDLE', 'RESUMED', 'ENDED', 'EXPIRED'))
);
CREATE INDEX idx_session_event_session ON session_event(session_id, created_at);

CREATE TABLE operation (
    operation_id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id                  UUID REFERENCES session(session_id) ON DELETE RESTRICT,
    user_id                     UUID NOT NULL REFERENCES "user"(user_id) ON DELETE RESTRICT,
    use_case_id                 UUID REFERENCES use_case(use_case_id) ON DELETE RESTRICT,
    operation_type              operation_type_enum NOT NULL,
    target_entity_type          target_entity_type_enum NOT NULL,
    target_entity_id            UUID,
    idempotency_key             VARCHAR(128) NOT NULL,
    status                      operation_status_enum NOT NULL DEFAULT 'PENDING',
    request_payload             JSONB NOT NULL,
    result_payload              JSONB,
    error_code                  VARCHAR(100),
    error_message               TEXT,
    orchestrator_correlation_id VARCHAR(255),
    attempt_count               INT NOT NULL DEFAULT 0,
    max_attempts                INT NOT NULL DEFAULT 3,
    next_attempt_at             TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    locked_by                   VARCHAR(255),
    locked_at                   TIMESTAMPTZ,
    started_at                  TIMESTAMPTZ,
    completed_at                TIMESTAMPTZ,
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at                  TIMESTAMPTZ DEFAULT NULL,
    CONSTRAINT chk_operation_terminal CHECK ((status IN ('SUCCEEDED', 'FAILED', 'CANCELLED')) = (completed_at IS NOT NULL)),
    CONSTRAINT chk_operation_lock CHECK ((status = 'RUNNING') = (locked_by IS NOT NULL AND locked_at IS NOT NULL))
);
CREATE UNIQUE INDEX uq_operation_idempotency_active ON operation(user_id, idempotency_key) WHERE deleted_at IS NULL;
CREATE INDEX idx_operation_queue ON operation(next_attempt_at, created_at) WHERE deleted_at IS NULL AND status = 'PENDING';
CREATE INDEX idx_operation_running ON operation(locked_at) WHERE deleted_at IS NULL AND status = 'RUNNING';
CREATE INDEX idx_operation_session ON operation(session_id, created_at DESC) WHERE deleted_at IS NULL;
CREATE INDEX idx_operation_user_recent ON operation(user_id, created_at DESC) WHERE deleted_at IS NULL;
CREATE INDEX idx_operation_use_case ON operation(use_case_id, created_at DESC) WHERE deleted_at IS NULL;
CREATE INDEX idx_operation_target ON operation(target_entity_type, target_entity_id) WHERE deleted_at IS NULL AND target_entity_id IS NOT NULL;

CREATE TABLE operation_event (
    operation_event_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    operation_id       UUID NOT NULL REFERENCES operation(operation_id) ON DELETE RESTRICT,
    from_status        operation_status_enum,
    to_status          operation_status_enum NOT NULL,
    actor              VARCHAR(255) NOT NULL,
    detail             JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_operation_event_operation ON operation_event(operation_id, created_at);

CREATE TABLE idempotency_key (
    user_id         UUID NOT NULL REFERENCES "user"(user_id) ON DELETE RESTRICT,
    idempotency_key VARCHAR(128) NOT NULL,
    route           VARCHAR(100) NOT NULL,
    request_hash    CHAR(64) NOT NULL,
    response_status SMALLINT NOT NULL,
    response_body   JSONB NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at      TIMESTAMPTZ NOT NULL,
    PRIMARY KEY (user_id, idempotency_key)
);
CREATE INDEX idx_idempotency_expiry ON idempotency_key(expires_at);

-- wake workers on new work; the poller still runs as a fallback
CREATE OR REPLACE FUNCTION notify_operation_pending() RETURNS trigger AS $$
BEGIN
    IF NEW.status = 'PENDING' THEN
        PERFORM pg_notify('operations', NEW.operation_id::text);
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_operation_notify
    AFTER INSERT OR UPDATE OF status ON operation
    FOR EACH ROW EXECUTE FUNCTION notify_operation_pending();
