-- core entity model + lifecycle/provenance columns on the provisionable tables

-- ============================================================================
-- CORE / IDENTITY
-- ============================================================================
CREATE TABLE role (
    role_id     VARCHAR(50) PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    description TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at  TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE "user" (
    user_id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    principal_email VARCHAR(255) NOT NULL,
    name            VARCHAR(255) NOT NULL,
    staff_id        VARCHAR(50),
    role_id         VARCHAR(50) NOT NULL REFERENCES role(role_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    is_system       BOOLEAN NOT NULL DEFAULT FALSE,
    external_ref    TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at      TIMESTAMPTZ DEFAULT NULL
);
CREATE UNIQUE INDEX uq_user_principal_email_active ON "user"(principal_email) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX uq_user_staff_id_active ON "user"(staff_id) WHERE deleted_at IS NULL AND staff_id IS NOT NULL;

CREATE TABLE business_unit (
    business_unit_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name             VARCHAR(255) NOT NULL,
    owner_id         UUID NOT NULL REFERENCES "user"(user_id) ON DELETE RESTRICT,
    external_ref     TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at       TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE use_case (
    use_case_id      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_unit_id UUID NOT NULL REFERENCES business_unit(business_unit_id) ON DELETE RESTRICT,
    name             VARCHAR(255) NOT NULL,
    cost_centre      VARCHAR(100) NOT NULL,
    external_ref     TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at       TIMESTAMPTZ DEFAULT NULL
);

-- use case membership (owner-managed access, multiple owners)
CREATE TABLE use_case_member (
    use_case_id UUID NOT NULL REFERENCES use_case(use_case_id) ON DELETE RESTRICT,
    user_id     UUID NOT NULL REFERENCES "user"(user_id) ON DELETE RESTRICT,
    is_owner    BOOLEAN NOT NULL DEFAULT FALSE,
    granted_by  UUID REFERENCES "user"(user_id),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at  TIMESTAMPTZ DEFAULT NULL,
    PRIMARY KEY (use_case_id, user_id)
);

CREATE TABLE application (
    application_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    al_number      VARCHAR(100) NOT NULL,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at     TIMESTAMPTZ DEFAULT NULL
);
CREATE UNIQUE INDEX uq_application_al_number_active ON application(al_number) WHERE deleted_at IS NULL;

CREATE TABLE rtl_stage (
    stage_id      VARCHAR(50) PRIMARY KEY,
    name          VARCHAR(100) NOT NULL,
    next_stage_id VARCHAR(50) REFERENCES rtl_stage(stage_id) ON DELETE RESTRICT,
    prev_stage_id VARCHAR(50) REFERENCES rtl_stage(stage_id) ON DELETE RESTRICT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at    TIMESTAMPTZ DEFAULT NULL
);

-- ============================================================================
-- WORKSPACE & COMPUTE
-- ============================================================================
CREATE TABLE ml_workspace (
    ml_workspace_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    use_case_id            UUID NOT NULL REFERENCES use_case(use_case_id) ON DELETE RESTRICT,
    owner_id               UUID NOT NULL REFERENCES "user"(user_id) ON DELETE RESTRICT,
    hosting_env            hosting_environment_enum NOT NULL,
    lifecycle_status       lifecycle_status_enum NOT NULL DEFAULT 'PROVISIONING',
    external_resource_name TEXT,
    origin                 origin_enum NOT NULL DEFAULT 'ATLAS',
    reconcile_status       reconcile_status_enum,
    last_reconciled_at     TIMESTAMPTZ,
    source_labels          JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at             TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at             TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE workstation_configuration (
    workstation_config_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    preset_name           VARCHAR(100),                     -- set for shared presets only
    cpu_count             INT NOT NULL CHECK (cpu_count > 0),
    memory                VARCHAR(50) NOT NULL,
    container             VARCHAR(255) NOT NULL,
    gpu_count             INT NOT NULL DEFAULT 0 CHECK (gpu_count >= 0),
    created_at            TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at            TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at            TIMESTAMPTZ DEFAULT NULL
);
CREATE UNIQUE INDEX uq_workstation_config_preset_active
    ON workstation_configuration(preset_name) WHERE deleted_at IS NULL AND preset_name IS NOT NULL;

CREATE TABLE workstation (
    workstation_id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ml_workspace_id        UUID NOT NULL REFERENCES ml_workspace(ml_workspace_id) ON DELETE RESTRICT,
    workstation_config_id  UUID NOT NULL REFERENCES workstation_configuration(workstation_config_id) ON DELETE RESTRICT,
    implementation         implementation_type_enum NOT NULL,
    url                    TEXT,                               -- nullable until READY
    launch_url             TEXT,
    lifecycle_status       lifecycle_status_enum NOT NULL DEFAULT 'PROVISIONING',
    external_resource_name TEXT,
    origin                 origin_enum NOT NULL DEFAULT 'ATLAS',
    reconcile_status       reconcile_status_enum,
    last_reconciled_at     TIMESTAMPTZ,
    source_labels          JSONB NOT NULL DEFAULT '{}'::jsonb,
    provisioning_spec      JSONB,
    tf_address             TEXT,
    tf_workspace           VARCHAR(255),
    created_at             TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at             TIMESTAMPTZ DEFAULT NULL
);
CREATE UNIQUE INDEX uq_workstation_external_name_active
    ON workstation(external_resource_name) WHERE deleted_at IS NULL AND external_resource_name IS NOT NULL;

-- ============================================================================
-- PIPELINES, EXPERIMENTS, MODELS (not used by the api yet)
-- ============================================================================
CREATE TABLE pipeline_template (
    pipeline_template_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name         VARCHAR(255) NOT NULL,
    template_url TEXT NOT NULL,
    description  TEXT,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at   TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE pipeline_component (
    pipeline_component_id  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name                   VARCHAR(255) NOT NULL,
    component_type         VARCHAR(100) NOT NULL,
    pipeline_component_url TEXT NOT NULL,
    description            TEXT,
    created_at             TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at             TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE pipeline_template_component (
    pipeline_template_id  UUID NOT NULL REFERENCES pipeline_template(pipeline_template_id) ON DELETE RESTRICT,
    pipeline_component_id UUID NOT NULL REFERENCES pipeline_component(pipeline_component_id) ON DELETE RESTRICT,
    execution_order       INT,
    created_at            TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at            TIMESTAMPTZ DEFAULT NULL,
    PRIMARY KEY (pipeline_template_id, pipeline_component_id)
);

CREATE TABLE experiment (
    experiment_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    use_case_id            UUID NOT NULL REFERENCES use_case(use_case_id) ON DELETE RESTRICT,
    name                   VARCHAR(255) NOT NULL,
    external_resource_name TEXT,
    origin                 origin_enum NOT NULL DEFAULT 'ATLAS',
    created_at             TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at             TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE pipeline_job (
    pipeline_job_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    template_id     UUID REFERENCES pipeline_template(pipeline_template_id) ON DELETE RESTRICT,
    experiment_id   UUID NOT NULL REFERENCES experiment(experiment_id) ON DELETE RESTRICT,
    "timestamp"     TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    job_identifier  VARCHAR(255) NOT NULL,
    origin          origin_enum NOT NULL DEFAULT 'ATLAS',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at      TIMESTAMPTZ DEFAULT NULL
);
CREATE UNIQUE INDEX uq_pipeline_job_identifier_active ON pipeline_job(job_identifier) WHERE deleted_at IS NULL;

CREATE TABLE model_endpoint (
    model_endpoint_id      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    experiment_id          UUID NOT NULL REFERENCES experiment(experiment_id) ON DELETE RESTRICT,
    rtl_stage_id           VARCHAR(50) NOT NULL REFERENCES rtl_stage(stage_id) ON DELETE RESTRICT,
    application_id         UUID REFERENCES application(application_id) ON DELETE RESTRICT,
    inference_url          TEXT,
    container_spec         JSONB,
    compute_spec           JSONB,
    lifecycle_status       lifecycle_status_enum NOT NULL DEFAULT 'PROVISIONING',
    external_resource_name TEXT,
    origin                 origin_enum NOT NULL DEFAULT 'ATLAS',
    created_at             TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at             TIMESTAMPTZ DEFAULT NULL
);

CREATE TABLE model (
    model_id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    model_endpoint_id      UUID REFERENCES model_endpoint(model_endpoint_id) ON DELETE RESTRICT,
    pipeline_job_id        UUID REFERENCES pipeline_job(pipeline_job_id) ON DELETE RESTRICT,
    version                VARCHAR(50) NOT NULL,
    online_or_batch        model_execution_mode_enum NOT NULL,
    registration_info_json JSONB,
    origin                 origin_enum NOT NULL DEFAULT 'ATLAS',
    created_at             TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at             TIMESTAMPTZ DEFAULT NULL
);

-- Performance indexes (filtered on active rows)
CREATE INDEX idx_user_role ON "user"(role_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_business_unit_owner ON business_unit(owner_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_use_case_business_unit ON use_case(business_unit_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_use_case_member_user ON use_case_member(user_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_ml_workspace_use_case ON ml_workspace(use_case_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_ml_workspace_owner ON ml_workspace(owner_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_workstation_workspace ON workstation(ml_workspace_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_workstation_config ON workstation(workstation_config_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_experiment_use_case ON experiment(use_case_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_pipeline_job_experiment ON pipeline_job(experiment_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_model_endpoint_experiment ON model_endpoint(experiment_id) WHERE deleted_at IS NULL;
