# atlas-poc

Local prototype for session + provisioning state in the Atlas experience layer. Postgres, a small FastAPI service,
a couple of worker processes and a fake orchestrator, all under docker compose. Built to try the persist-first /
async-provisioning idea before we commit to it in the real service.

## Run

    make up       # docker compose up -d --build
    make smoke    # ./scripts/smoke.sh
    make logs
    make psql
    make reset    # drops the volume; schema + seeds run again on next up

API on http://localhost:8080 (swagger at /docs), orchestrator stub on :9090, postgres on :5433 (atlas/atlas/atlas).

## Layout

    db/init/          schema + seeds, run by the postgres image on first start
      001 enums
      002 core tables (the existing entity model + lifecycle/provenance cols)
      003 session, operation, events, idempotency store
      004 reconcile staging (schema only)
      010 reference data (roles, rtl stages, system users)
      011 dev seed (people, one bu/use case, presets, one workspace, one imported workstation) -- DO NOT SHIP
    api/app/
      main.py           app wiring, error handlers
      auth.py           X-Atlas-Principal -> user row
      sessions.py       session routes
      operations.py     create/delete workstation (202 + operation), operation get/list/cancel/events
      context.py        rules for session.context
      idempotency.py    Idempotency-Key replay store
      worker.py         claims ops, calls orchestrator, writes outcome
      reaper.py         idle/expire sweep
      orchestrator_stub.py
    scripts/smoke.sh    14 step end-to-end check

## How it works

- Every write route takes `Idempotency-Key`. Same key + same body replays the original response.
- Provisioning routes don't call the orchestrator. They insert the target row as PROVISIONING, an `operation`
  row as PENDING and return 202. Client polls `/operations/{id}`.
- Workers claim with `FOR UPDATE SKIP LOCKED` (plus `LISTEN operations` so they wake up quickly), call the
  orchestrator with the operation id as the idempotency key, and mark SUCCEEDED / FAILED. Transient errors go
  back to PENDING with backoff. On a retry the worker asks the orchestrator what happened to that key first.
- Stale leases (worker died mid-call) get reset by a sweep in the worker loop.
- Session status is only ever set server side. Reaper moves ACTIVE -> IDLE -> EXPIRED. Heartbeat is debounced.
- Ending a session doesn't touch its operations.

## Auth

No login. Set `X-Atlas-Principal` yourself:

    alice@example.com   data scientist, member of the seeded use case
    bob@example.com     use case owner (can list by use case, forceEnd alice's sessions)
    carol@example.com   business approver (nothing wired up for approvals yet)
    dan@example.com     platform admin

## Example

    API=http://localhost:8080
    A='X-Atlas-Principal: alice@example.com'
    WS=50000000-0000-0000-0000-000000000001

    curl -s -X POST $API/api/v1/sessions -H "$A" -H 'Content-Type: application/json' \
      -d '{"clientType":"WEB","useCaseId":"30000000-0000-0000-0000-000000000001"}'

    curl -s -i -X POST $API/api/v1/mlWorkspaces/$WS/workstations -H "$A" -H "X-Atlas-Session-Id: <sid>" \
      -H 'Content-Type: application/json' -H "Idempotency-Key: $(uuidgen)" \
      -d '{"implementation":"VSCODE","configuration":{"presetName":"standard-cpu"}}'

    curl -s $API/api/v1/operations/<opid> -H "$A"          # PENDING -> RUNNING -> SUCCEEDED (~5s)
    curl -s $API/api/v1/workstations/<wsid> -H "$A"        # READY + launchUrl

zsh: use `${OP}:cancel` not `$OP:cancel`, zsh eats the colon.

## Knobs

See `.env.example` / `docker-compose.yml`. Useful ones while poking at it:

- `FAIL_FIRST_ATTEMPT=true` on the orchestrator -> first call 503s, watch the retry. Backoff is in minutes.
- `WORKER_LEASE_MINUTES=1` then `docker compose kill worker-1` while an op is RUNNING -> stale lease recovery.
- bespoke config with `gpuCount: 2` -> stub returns 409 -> op parks in AWAITING_APPROVAL. 3 GPUs -> 422 at accept.
- `SESSION_LIMIT_PER_CLIENT=2` -> third session of the same client type gets 409 SESSION_LIMIT (or evicts an idle one).
- `SESSION_IDLE_MINUTES=1`, `REAPER_INTERVAL_SECONDS=10` -> watch IDLE / RESUMED events.

## TODO

- approve route (BUSINESS_APPROVER) to move AWAITING_APPROVAL -> PENDING
- other provisioning routes (workspace, resize/start/stop, pipeline job, endpoint)
- admin routes over the reconcile staging tables
- cursor pagination on /operations (sessions has it, operations doesn't)
- pgbouncer in front of the pool before this goes anywhere near cloud sql
- real orchestrator client; the stub's contract (409 = needs approval) is made up
