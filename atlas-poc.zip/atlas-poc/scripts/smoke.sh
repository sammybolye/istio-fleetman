#!/usr/bin/env bash
# end to end check against a running stack. needs curl + python3.
set -euo pipefail
API=${API:-http://localhost:8080}
ALICE="X-Atlas-Principal: alice@example.com"
DAN="X-Atlas-Principal: dan@example.com"
WS=50000000-0000-0000-0000-000000000001
j() { python3 -c 'import sys,json; d=json.load(sys.stdin); print(d'"$1"')'; }

echo "== 1. Alice starts a WEB session"
SESSION=$(curl -s -X POST "$API/api/v1/sessions" -H "$ALICE" -H 'Content-Type: application/json' \
  -d '{"clientType":"WEB","useCaseId":"30000000-0000-0000-0000-000000000001","context":{"theme":"dark"}}')
SID=$(echo "$SESSION" | j '["sessionId"]')
echo "   sessionId=$SID status=$(echo "$SESSION" | j '["status"]')"

echo "== 2. Current session via header"
curl -s "$API/api/v1/sessions/current" -H "$ALICE" -H "X-Atlas-Session-Id: $SID" | j '["useCaseName"]'

echo "== 3. Patch context (top-level merge; null removes)"
curl -s -X PATCH "$API/api/v1/sessions/$SID" -H "$ALICE" -H 'Content-Type: application/json' -H "Idempotency-Key: patch-$SID" \
  -d '{"mlWorkspaceId":"'$WS'","context":{"lastViewed":"experiments","theme":null}}' | j '["context"]'

echo "== 4. credential-looking context value is rejected"
curl -s -X PATCH "$API/api/v1/sessions/$SID" -H "$ALICE" -H 'Content-Type: application/json' -H "Idempotency-Key: bad-$SID" \
  -d '{"context":{"token":"ya29.abc"}}' | j '["error"]["code"]'

echo "== 5. Heartbeat (first call debounced because the patch just touched last_seen_at)"
curl -s -X POST "$API/api/v1/sessions/$SID/heartbeat" -H "$ALICE" | j '["debounced"]'

echo "== 6. Ask for a GPU workstation (202, operation PENDING)"
KEY=$(python3 -c 'import uuid; print(uuid.uuid4())')
ACC=$(curl -s -X POST "$API/api/v1/mlWorkspaces/$WS/workstations" -H "$ALICE" -H "X-Atlas-Session-Id: $SID" \
  -H 'Content-Type: application/json' -H "Idempotency-Key: $KEY" \
  -d '{"implementation":"VSCODE","configuration":{"presetName":"gpu-t4"}}')
OP=$(echo "$ACC" | j '["operationId"]'); TARGET=$(echo "$ACC" | j '["targetEntityId"]')
echo "   operationId=$OP workstationId=$TARGET status=$(echo "$ACC" | j '["status"]')"

echo "== 7. Same request, same key: replayed, no second workstation"
curl -s -D - -o /dev/null -X POST "$API/api/v1/mlWorkspaces/$WS/workstations" -H "$ALICE" -H 'Content-Type: application/json' \
  -H "Idempotency-Key: $KEY" -d '{"implementation":"VSCODE","configuration":{"presetName":"gpu-t4"}}' | grep -i -E 'HTTP/|Idempotent-Replayed'

echo "== 8. Workstation is PROVISIONING while the worker calls the orchestrator"
curl -s "$API/api/v1/workstations/$TARGET" -H "$ALICE" | j '["lifecycleStatus"]'

echo "== 9. Poll the operation until terminal"
for i in $(seq 1 30); do
  ST=$(curl -s "$API/api/v1/operations/$OP" -H "$ALICE" | j '["status"]')
  echo "   t+${i}s $ST"
  case "$ST" in SUCCEEDED|FAILED|CANCELLED) break;; esac
  sleep 1
done

echo "== 10. Workstation now READY with a launch URL"
curl -s "$API/api/v1/workstations/$TARGET" -H "$ALICE" | j '["lifecycleStatus"], d["launchUrl"]'

echo "== 11. Operation audit trail"
curl -s "$API/api/v1/operations/$OP/events" -H "$ALICE" | python3 -c 'import sys,json; [print("  ", e["fromStatus"], "->", e["toStatus"], e["actor"]) for e in json.load(sys.stdin)["items"]]'

echo "== 12. Session audit trail"
curl -s "$API/api/v1/sessions/$SID/events" -H "$ALICE" | python3 -c 'import sys,json; [print("  ", e["eventType"], e["detail"]) for e in json.load(sys.stdin)["items"]]'

echo "== 13. Admin lists live sessions"
curl -s "$API/api/v1/sessions?status=live" -H "$DAN" | j '["total"]'

echo "== 14. alice ends her session, workstation stays"
curl -s -o /dev/null -w '   HTTP %{http_code}\n' -X DELETE "$API/api/v1/sessions/$SID?reason=done" -H "$ALICE" -H "Idempotency-Key: end-$SID"
curl -s "$API/api/v1/sessions/$SID" -H "$ALICE" | j '["error"]["code"]'
curl -s "$API/api/v1/workstations/$TARGET" -H "$ALICE" | j '["lifecycleStatus"]'
echo "== done"
