"""principal comes in on X-Atlas-Principal (set by the sso edge in real life, by hand here)"""
from dataclasses import dataclass
from fastapi import Header, Request
from .db import pool
from .errors import ApiError


@dataclass
class Principal:
    user_id: str
    email: str
    role_id: str
    is_system: bool

    @property
    def is_admin(self) -> bool:
        return self.role_id == "PLATFORM_ADMIN"


def current_principal(request: Request, x_atlas_principal: str | None = Header(default=None)) -> Principal:
    if not x_atlas_principal:
        raise ApiError(401, "UNAUTHENTICATED", "Missing X-Atlas-Principal header.")
    with pool.connection() as conn:
        row = conn.execute(
            'SELECT user_id, principal_email, role_id, is_system FROM "user" WHERE principal_email = %s AND deleted_at IS NULL',
            (x_atlas_principal.lower(),),
        ).fetchone()
    if not row:
        raise ApiError(403, "FORBIDDEN", f"Principal {x_atlas_principal} is not an Atlas user.")
    p = Principal(str(row["user_id"]), row["principal_email"], row["role_id"], row["is_system"])
    request.state.principal = p
    return p


def owns_use_case(conn, user_id: str, use_case_id: str) -> bool:
    row = conn.execute(
        "SELECT 1 FROM use_case_member WHERE use_case_id = %s AND user_id = %s AND is_owner AND deleted_at IS NULL",
        (use_case_id, user_id),
    ).fetchone()
    return row is not None


def member_of_use_case(conn, user_id: str, use_case_id: str) -> bool:
    row = conn.execute(
        "SELECT 1 FROM use_case_member WHERE use_case_id = %s AND user_id = %s AND deleted_at IS NULL",
        (use_case_id, user_id),
    ).fetchone()
    return row is not None
