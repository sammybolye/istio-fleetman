"""operation routes + the provisioning routes that create them. only workstation create/delete so far."""
from typing import Optional
from fastapi import APIRouter, Depends, Header, Query, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from .auth import Principal, current_principal, member_of_use_case, owns_use_case
from .db import jb, row_to_json, tx
from .errors import ApiError

router = APIRouter(prefix="/api/v1", tags=["Operations"])


class WorkstationConfiguration(BaseModel):
    presetName: Optional[str] = None
    cpuCount: Optional[int] = Field(default=None, ge=1)
    memory: Optional[str] = Field(default=None, pattern=r"^[0-9]+(Mi|Gi)$")
    container: Optional[str] = None
    gpuCount: int = Field(default=0, ge=0)


class WorkstationCreate(BaseModel):
    implementation: str = Field(pattern="^(JUPYTER|VSCODE|CUSTOM)$")
    configuration: WorkstationConfiguration


class ReasonBody(BaseModel):
    reason: Optional[str] = Field(default=None, max_length=500)


def op_resource(row) -> dict:
    r = row_to_json(row)
    oid = r["operation_id"]
    out = {
        "operationId": oid, "sessionId": r["session_id"], "userId": r["user_id"], "useCaseId": r["use_case_id"],
        "operationType": r["operation_type"], "targetEntityType": r["target_entity_type"], "targetEntityId": r["target_entity_id"],
        "status": r["status"], "attemptCount": r["attempt_count"], "requestPayload": r["request_payload"],
        "resultPayload": r["result_payload"],
        "error": {"code": r["error_code"], "message": r["error_message"]} if r["status"] == "FAILED" else None,
        "orchestratorCorrelationId": r["orchestrator_correlation_id"],
        "createdAt": r["created_at"], "startedAt": r["started_at"], "completedAt": r["completed_at"], "nextAttemptAt": r["next_attempt_at"],
        "links": {"self": f"/api/v1/operations/{oid}", "events": f"/api/v1/operations/{oid}/events"},
    }
    if r["target_entity_type"] == "WORKSTATION" and r["target_entity_id"]:
        out["links"]["target"] = f"/api/v1/workstations/{r['target_entity_id']}"
    return out


def op_event(conn, operation_id, from_status, to_status, actor, detail=None):
    conn.execute("INSERT INTO operation_event (operation_id, from_status, to_status, actor, detail) VALUES (%s,%s,%s,%s,%s)",
                 (operation_id, from_status, to_status, actor, jb(detail or {})))


def resolve_session(conn, p: Principal, header_value: str | None, use_case_id: str):
    """use the session from the header if it's valid and ours, otherwise start one. a bad header is not an error."""
    if header_value:
        row = conn.execute("SELECT session_id FROM session WHERE session_id = %s AND user_id = %s AND deleted_at IS NULL "
                           "AND status IN ('ACTIVE','IDLE')", (header_value, p.user_id)).fetchone()
        if row:
            conn.execute("UPDATE session SET last_seen_at = CURRENT_TIMESTAMP, status = 'ACTIVE' WHERE session_id = %s", (header_value,))
            return str(row["session_id"])
    row = conn.execute("INSERT INTO session (user_id, use_case_id, client_type, expires_at) VALUES (%s,%s,'SDK', CURRENT_TIMESTAMP + INTERVAL '12 hours') "
                       "RETURNING session_id", (p.user_id, use_case_id)).fetchone()
    conn.execute("INSERT INTO session_event (session_id, event_type, to_status, actor, detail) VALUES (%s,'STARTED','ACTIVE',%s,%s)",
                 (row["session_id"], p.email, jb({"implicit": True})))
    return str(row["session_id"])


def replay_or_none(conn, p: Principal, key: str, payload: dict):
    row = conn.execute("SELECT * FROM operation WHERE user_id = %s AND idempotency_key = %s AND deleted_at IS NULL", (p.user_id, key)).fetchone()
    if not row:
        return None
    if row["request_payload"] != payload:
        raise ApiError(409, "IDEMPOTENCY_KEY_REUSED", "Idempotency-Key was already used with a different request.")
    return JSONResponse(status_code=202, content=accepted_body(row),
                        headers={"Location": f"/api/v1/operations/{row['operation_id']}", "Idempotent-Replayed": "true"})


def accepted_body(row):
    r = row_to_json(row)
    return {"operationId": r["operation_id"], "status": r["status"], "targetEntityType": r["target_entity_type"],
            "targetEntityId": r["target_entity_id"], "createdAt": r["created_at"]}


# create workstation
@router.post("/mlWorkspaces/{ml_workspace_id}/workstations", status_code=202, tags=["Provisioning"])
def create_workstation(ml_workspace_id: str, body: WorkstationCreate, request: Request, p: Principal = Depends(current_principal),
                       idempotency_key: str = Header(alias="Idempotency-Key"),
                       x_atlas_session_id: str | None = Header(default=None, alias="X-Atlas-Session-Id")):
    payload = body.model_dump(exclude_none=True)
    with tx() as conn:
        replay = replay_or_none(conn, p, idempotency_key, payload)
        if replay:
            return replay
        ws = conn.execute("SELECT ml_workspace_id, use_case_id, owner_id FROM ml_workspace WHERE ml_workspace_id = %s AND deleted_at IS NULL",
                          (ml_workspace_id,)).fetchone()
        if not ws:
            raise ApiError(404, "NOT_FOUND", f"ML workspace {ml_workspace_id} not found.")
        use_case_id = str(ws["use_case_id"])
        if not (p.is_admin or member_of_use_case(conn, p.user_id, use_case_id)):
            raise ApiError(403, "FORBIDDEN", "You are not a member of this workspace's use case.")
        cfg = body.configuration
        if cfg.presetName:
            preset = conn.execute("SELECT workstation_config_id, gpu_count FROM workstation_configuration WHERE preset_name = %s AND deleted_at IS NULL",
                                  (cfg.presetName,)).fetchone()
            if not preset:
                raise ApiError(404, "NOT_FOUND", f"Preset {cfg.presetName} not found.")
            config_id, gpu = preset["workstation_config_id"], preset["gpu_count"]
        else:
            if not (cfg.cpuCount and cfg.memory and cfg.container):
                raise ApiError(400, "VALIDATION_FAILED", "cpuCount, memory and container are required without presetName.",
                               {"fields": ["configuration"]})
            if cfg.gpuCount > 2:
                raise ApiError(422, "POLICY_DENIED", "GPU count above the use case cap of 2.", {"cap": 2})
            config_id = conn.execute("INSERT INTO workstation_configuration (cpu_count, memory, container, gpu_count) VALUES (%s,%s,%s,%s) "
                                     "RETURNING workstation_config_id", (cfg.cpuCount, cfg.memory, cfg.container, cfg.gpuCount)).fetchone()["workstation_config_id"]
            gpu = cfg.gpuCount
        session_id = resolve_session(conn, p, x_atlas_session_id, use_case_id)
        # target row (PROVISIONING) + operation (PENDING) + first event, all in this tx
        wid = conn.execute("INSERT INTO workstation (ml_workspace_id, workstation_config_id, implementation, lifecycle_status, provisioning_spec) "
                           "VALUES (%s,%s,%s,'PROVISIONING',%s) RETURNING workstation_id",
                           (ml_workspace_id, config_id, body.implementation, jb(payload))).fetchone()["workstation_id"]
        op = conn.execute(
            "INSERT INTO operation (session_id, user_id, use_case_id, operation_type, target_entity_type, target_entity_id, idempotency_key, request_payload) "
            "VALUES (%s,%s,%s,'CREATE_WORKSTATION','WORKSTATION',%s,%s,%s) RETURNING *",
            (session_id, p.user_id, use_case_id, wid, idempotency_key, jb(payload))).fetchone()
        op_event(conn, op["operation_id"], None, "PENDING", p.email, {"source": "api", "gpuCount": gpu})
    return JSONResponse(status_code=202, content=accepted_body(op), headers={"Location": f"/api/v1/operations/{op['operation_id']}"})


# delete workstation
@router.delete("/workstations/{workstation_id}", status_code=202, tags=["Provisioning"])
def delete_workstation(workstation_id: str, p: Principal = Depends(current_principal),
                       idempotency_key: str = Header(alias="Idempotency-Key"),
                       x_atlas_session_id: str | None = Header(default=None, alias="X-Atlas-Session-Id")):
    payload = {"workstationId": workstation_id}
    with tx() as conn:
        replay = replay_or_none(conn, p, idempotency_key, payload)
        if replay:
            return replay
        w = conn.execute("SELECT w.workstation_id, w.lifecycle_status, ws.use_case_id FROM workstation w JOIN ml_workspace ws USING (ml_workspace_id) "
                         "WHERE w.workstation_id = %s AND w.deleted_at IS NULL FOR UPDATE OF w", (workstation_id,)).fetchone()
        if not w:
            raise ApiError(404, "NOT_FOUND", f"Workstation {workstation_id} not found.")
        use_case_id = str(w["use_case_id"])
        if not (p.is_admin or member_of_use_case(conn, p.user_id, use_case_id)):
            raise ApiError(403, "FORBIDDEN", "You are not a member of this workstation's use case.")
        if w["lifecycle_status"] in ("PROVISIONING", "DELETING"):
            raise ApiError(409, "INVALID_STATE", f"Workstation is {w['lifecycle_status']}.", {"currentStatus": w["lifecycle_status"]})
        session_id = resolve_session(conn, p, x_atlas_session_id, use_case_id)
        conn.execute("UPDATE workstation SET lifecycle_status='DELETING', updated_at=CURRENT_TIMESTAMP WHERE workstation_id=%s", (workstation_id,))
        op = conn.execute(
            "INSERT INTO operation (session_id, user_id, use_case_id, operation_type, target_entity_type, target_entity_id, idempotency_key, request_payload) "
            "VALUES (%s,%s,%s,'DELETE_WORKSTATION','WORKSTATION',%s,%s,%s) RETURNING *",
            (session_id, p.user_id, use_case_id, workstation_id, idempotency_key, jb(payload))).fetchone()
        op_event(conn, op["operation_id"], None, "PENDING", p.email, {"source": "api"})
    return JSONResponse(status_code=202, content=accepted_body(op), headers={"Location": f"/api/v1/operations/{op['operation_id']}"})


# get workstation
@router.get("/workstations/{workstation_id}", tags=["Provisioning"])
def get_workstation(workstation_id: str, p: Principal = Depends(current_principal)):
    with tx() as conn:
        w = conn.execute("SELECT w.*, c.preset_name, c.cpu_count, c.memory, c.container, c.gpu_count, ws.use_case_id FROM workstation w "
                         "JOIN workstation_configuration c USING (workstation_config_id) JOIN ml_workspace ws USING (ml_workspace_id) "
                         "WHERE w.workstation_id = %s AND w.deleted_at IS NULL", (workstation_id,)).fetchone()
        if not w:
            raise ApiError(404, "NOT_FOUND", f"Workstation {workstation_id} not found.")
        if not (p.is_admin or member_of_use_case(conn, p.user_id, str(w["use_case_id"]))):
            raise ApiError(403, "FORBIDDEN", "Not a member of this use case.")
    r = row_to_json(w)
    return {"workstationId": r["workstation_id"], "mlWorkspaceId": r["ml_workspace_id"], "implementation": r["implementation"],
            "lifecycleStatus": r["lifecycle_status"], "url": r["url"], "launchUrl": r["launch_url"],
            "origin": r["origin"], "reconcileStatus": r["reconcile_status"], "externalResourceName": r["external_resource_name"],
            "tfAddress": r["tf_address"],
            "configuration": {"presetName": r["preset_name"], "cpuCount": r["cpu_count"], "memory": r["memory"], "container": r["container"], "gpuCount": r["gpu_count"]},
            "createdAt": r["created_at"], "updatedAt": r["updated_at"]}


# operations
def can_read_op(conn, p: Principal, row) -> bool:
    return p.is_admin or str(row["user_id"]) == p.user_id or (row["use_case_id"] and owns_use_case(conn, p.user_id, str(row["use_case_id"])))


@router.get("/operations")
def list_operations(p: Principal = Depends(current_principal), sessionId: str | None = None, useCaseId: str | None = None,
                    userId: str | None = None, status: str | None = None, operationType: str | None = None,
                    limit: int = Query(50, ge=1, le=200)):
    with tx() as conn:
        where = ["o.deleted_at IS NULL"]; args = []
        if not p.is_admin:
            if useCaseId and owns_use_case(conn, p.user_id, useCaseId):
                pass
            else:
                where.append("o.user_id = %s"); args.append(p.user_id)
        for col, val in (("o.session_id", sessionId), ("o.use_case_id", useCaseId), ("o.user_id", userId), ("o.status", status), ("o.operation_type", operationType)):
            if val:
                where.append(f"{col} = %s"); args.append(val)
        rows = conn.execute("SELECT o.* FROM operation o WHERE " + " AND ".join(where) + " ORDER BY o.created_at DESC LIMIT %s", args + [limit]).fetchall()
    return {"items": [op_resource(r) for r in rows], "nextCursor": None}


@router.get("/operations/{operation_id}")
def get_operation(operation_id: str, p: Principal = Depends(current_principal)):
    with tx() as conn:
        row = conn.execute("SELECT * FROM operation WHERE operation_id = %s AND deleted_at IS NULL", (operation_id,)).fetchone()
        if not row:
            raise ApiError(404, "NOT_FOUND", f"Operation {operation_id} not found.")
        if not can_read_op(conn, p, row):
            raise ApiError(403, "FORBIDDEN", "Not permitted to read this operation.")
    return op_resource(row)


@router.post("/operations/{operation_id}:cancel")
def cancel_operation(operation_id: str, body: ReasonBody | None = None, p: Principal = Depends(current_principal),
                     idempotency_key: str = Header(alias="Idempotency-Key")):
    with tx() as conn:
        row = conn.execute("SELECT * FROM operation WHERE operation_id = %s AND deleted_at IS NULL FOR UPDATE", (operation_id,)).fetchone()
        if not row:
            raise ApiError(404, "NOT_FOUND", f"Operation {operation_id} not found.")
        if not (p.is_admin or str(row["user_id"]) == p.user_id):
            raise ApiError(403, "FORBIDDEN", "Only the requester or an admin may cancel.")
        if row["status"] == "CANCELLED":
            return op_resource(row)
        if row["status"] not in ("PENDING", "AWAITING_APPROVAL"):
            raise ApiError(409, "INVALID_STATE", f"Cannot cancel an operation in status {row['status']}.", {"currentStatus": row["status"]})
        upd = conn.execute("UPDATE operation SET status='CANCELLED', completed_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE operation_id=%s RETURNING *",
                           (operation_id,)).fetchone()
        op_event(conn, operation_id, row["status"], "CANCELLED", p.email, {"reason": (body.reason if body else None)})
        if row["operation_type"] == "CREATE_WORKSTATION" and row["target_entity_id"]:
            conn.execute("UPDATE workstation SET lifecycle_status='FAILED', deleted_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE workstation_id=%s",
                         (row["target_entity_id"],))
    return op_resource(upd)


@router.get("/operations/{operation_id}/events")
def operation_events(operation_id: str, p: Principal = Depends(current_principal)):
    with tx() as conn:
        row = conn.execute("SELECT user_id, use_case_id FROM operation WHERE operation_id = %s AND deleted_at IS NULL", (operation_id,)).fetchone()
        if not row:
            raise ApiError(404, "NOT_FOUND", f"Operation {operation_id} not found.")
        if not can_read_op(conn, p, row):
            raise ApiError(403, "FORBIDDEN", "Not permitted to read this operation.")
        rows = conn.execute("SELECT from_status, to_status, actor, detail, created_at FROM operation_event WHERE operation_id = %s ORDER BY created_at",
                            (operation_id,)).fetchall()
    return {"items": [{"fromStatus": r["from_status"], "toStatus": r["to_status"], "actor": r["actor"], "detail": r["detail"],
                       "createdAt": r["created_at"].isoformat()} for r in rows], "nextCursor": None}
