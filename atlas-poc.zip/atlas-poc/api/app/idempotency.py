"""replay store for Idempotency-Key on session routes. operations keep their key on the row instead."""
import hashlib
import json
from datetime import datetime, timedelta, timezone
from fastapi.responses import JSONResponse
from .db import jb
from .errors import ApiError

TTL_HOURS = 24


def canonical_hash(body) -> str:
    return hashlib.sha256(json.dumps(body, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


def lookup(conn, user_id: str, key: str, route: str, body) -> JSONResponse | None:
    """Return a replay response if this key was seen with the same body; raise on a different body."""
    row = conn.execute(
        "SELECT route, request_hash, response_status, response_body FROM idempotency_key "
        "WHERE user_id = %s AND idempotency_key = %s AND expires_at > CURRENT_TIMESTAMP",
        (user_id, key),
    ).fetchone()
    if not row:
        return None
    if row["route"] != route or row["request_hash"] != canonical_hash(body):
        raise ApiError(409, "IDEMPOTENCY_KEY_REUSED", "Idempotency-Key was already used with a different request.")
    return JSONResponse(status_code=row["response_status"], content=row["response_body"], headers={"Idempotent-Replayed": "true"})


def store(conn, user_id: str, key: str, route: str, body, status: int, response_body) -> None:
    conn.execute(
        "INSERT INTO idempotency_key (user_id, idempotency_key, route, request_hash, response_status, response_body, expires_at) "
        "VALUES (%s, %s, %s, %s, %s, %s, %s) ON CONFLICT (user_id, idempotency_key) DO NOTHING",
        (user_id, key, route, canonical_hash(body), status, jb(response_body),
         datetime.now(timezone.utc) + timedelta(hours=TTL_HOURS)),
    )
