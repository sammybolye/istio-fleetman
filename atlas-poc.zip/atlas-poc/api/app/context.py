"""validation for session.context: size, depth, key names, no credential-looking strings"""
import json
import re
from .errors import ApiError

MAX_BYTES = 16 * 1024
MAX_DEPTH = 3
MAX_TOP_KEYS = 64
MAX_STRING = 2 * 1024
MAX_ARRAY = 100
KEY_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9_]{0,63}$")
CREDENTIAL_RES = [
    re.compile(r"^eyJ[A-Za-z0-9_-]+\."),      # JWT
    re.compile(r"AIza[0-9A-Za-z_-]{35}"),      # Google API key
    re.compile(r"ya29\."),                     # OAuth access token
    re.compile(r"-----BEGIN"),                 # private key
    re.compile(r"AKIA[0-9A-Z]{16}"),           # AWS key
    re.compile(r"xox[baprs]-"),                # Slack
    re.compile(r"gh[pousr]_[A-Za-z0-9]{20,}"), # GitHub
]


def _reject(reason: str):
    raise ApiError(400, "CONTEXT_REJECTED", f"Session context rejected: {reason}", {"reason": reason})


def _walk(value, depth: int):
    if depth > MAX_DEPTH:
        _reject(f"nesting deeper than {MAX_DEPTH}")
    if isinstance(value, dict):
        for k, v in value.items():
            if not KEY_RE.match(k):
                _reject(f"key '{k}' does not match ^[a-zA-Z][a-zA-Z0-9_]{{0,63}}$")
            _walk(v, depth + 1)
    elif isinstance(value, list):
        if len(value) > MAX_ARRAY:
            _reject(f"array longer than {MAX_ARRAY}")
        for v in value:
            if isinstance(v, (dict, list)):
                _reject("arrays may hold scalars only")
            _walk(v, depth + 1)
    elif isinstance(value, str):
        if len(value.encode()) > MAX_STRING:
            _reject(f"string longer than {MAX_STRING} bytes")
        for r in CREDENTIAL_RES:
            if r.search(value):
                _reject("value looks like a credential")
    elif value is None or isinstance(value, (bool, int, float)):
        return
    else:
        _reject(f"unsupported value type {type(value).__name__}")


def validate_patch(patch: dict) -> None:
    """Validate a context object or patch on its own (before merge)."""
    if not isinstance(patch, dict):
        _reject("context must be an object")
    for k in patch:
        if k.startswith("atlas_"):
            _reject("keys beginning with atlas_ are server-owned")
    _walk(patch, 1)


def merge(existing: dict, patch: dict) -> dict:
    """Top-level replace; a top-level null removes the key; nested nulls are kept."""
    merged = dict(existing)
    for k, v in patch.items():
        if v is None:
            merged.pop(k, None)
        else:
            merged[k] = v
    if len(merged) > MAX_TOP_KEYS:
        _reject(f"more than {MAX_TOP_KEYS} top-level keys after merge")
    if len(json.dumps(merged, separators=(",", ":")).encode()) > MAX_BYTES:
        _reject(f"context larger than {MAX_BYTES} bytes after merge")
    return merged
