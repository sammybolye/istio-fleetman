"""worker: claim a PENDING op (skip locked), call the orchestrator with the op id as idempotency key, write the result back."""
import logging
import os
import select
import socket
import time
import httpx
import psycopg
from psycopg.rows import dict_row
from .db import DATABASE_URL, jb

log = logging.getLogger("atlas.worker")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")

ORCHESTRATOR_URL = os.environ.get("ORCHESTRATOR_URL", "http://orchestrator:9090")
ORCHESTRATOR_TIMEOUT = float(os.environ.get("ORCHESTRATOR_TIMEOUT_SECONDS", "1200"))
LEASE_MINUTES = int(os.environ.get("WORKER_LEASE_MINUTES", "30"))
POLL_SECONDS = float(os.environ.get("WORKER_POLL_SECONDS", "2"))
WORKER_ID = os.environ.get("HOSTNAME", socket.gethostname())
ACTOR = f"worker:{WORKER_ID}"

CLAIM_SQL = """
WITH next_op AS (
    SELECT operation_id FROM operation
    WHERE status = 'PENDING' AND deleted_at IS NULL AND next_attempt_at <= CURRENT_TIMESTAMP
    ORDER BY next_attempt_at, created_at
    FOR UPDATE SKIP LOCKED
    LIMIT 1
)
UPDATE operation o
SET status = 'RUNNING', locked_by = %s, locked_at = CURRENT_TIMESTAMP,
    attempt_count = attempt_count + 1, started_at = COALESCE(started_at, CURRENT_TIMESTAMP), updated_at = CURRENT_TIMESTAMP
FROM next_op WHERE o.operation_id = next_op.operation_id
RETURNING o.*
"""

STALE_SQL = """
UPDATE operation SET status='PENDING', locked_by=NULL, locked_at=NULL, next_attempt_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP
WHERE status='RUNNING' AND deleted_at IS NULL AND locked_at < CURRENT_TIMESTAMP - make_interval(mins => %s)
RETURNING operation_id, locked_by
"""


def connect():
    return psycopg.connect(DATABASE_URL, row_factory=dict_row, autocommit=False)


def op_event(conn, operation_id, from_status, to_status, detail=None):
    conn.execute("INSERT INTO operation_event (operation_id, from_status, to_status, actor, detail) VALUES (%s,%s,%s,%s,%s)",
                 (operation_id, from_status, to_status, ACTOR, jb(detail or {})))


def claim(conn):
    row = conn.execute(CLAIM_SQL, (WORKER_ID,)).fetchone()
    if row:
        op_event(conn, row["operation_id"], "PENDING", "RUNNING", {"attempt": row["attempt_count"]})
    conn.commit()
    return row


def build_request(conn, op) -> dict:
    """payload for the orchestrator. TODO: align with the real implementation api contract"""
    req = {"operationId": str(op["operation_id"]), "operationType": op["operation_type"], "useCaseId": str(op["use_case_id"]) if op["use_case_id"] else None}
    if op["target_entity_type"] == "WORKSTATION":
        w = conn.execute("SELECT w.workstation_id, w.implementation, w.external_resource_name, w.tf_address, c.cpu_count, c.memory, c.container, c.gpu_count "
                         "FROM workstation w JOIN workstation_configuration c USING (workstation_config_id) WHERE w.workstation_id = %s",
                         (op["target_entity_id"],)).fetchone()
        req["workstation"] = {k: (str(v) if k == "workstation_id" else v) for k, v in (w or {}).items()}
    return req


def reconcile_before_retry(client: httpx.Client, op) -> dict | None:
    """on a retry, check whether the previous attempt actually went through before calling again"""
    r = client.get(f"{ORCHESTRATOR_URL}/provision/{op['operation_id']}")
    if r.status_code == 200:
        return r.json()
    return None


def execute(conn, client: httpx.Client, op):
    oid = op["operation_id"]
    result = None
    if op["attempt_count"] > 1:
        result = reconcile_before_retry(client, op)
        if result:
            log.info("op %s: orchestrator already completed on an earlier attempt, recording", oid)
    if result is None:
        req = build_request(conn, op)
        conn.commit()
        try:
            r = client.post(f"{ORCHESTRATOR_URL}/provision", json=req,
                            headers={"Idempotency-Key": str(oid)}, timeout=ORCHESTRATOR_TIMEOUT)
        except httpx.HTTPError as e:
            return fail_or_retry(conn, op, "ORCHESTRATOR_UNREACHABLE", str(e), retryable=True)
        corr = r.headers.get("X-Correlation-Id")
        if corr:
            conn.execute("UPDATE operation SET orchestrator_correlation_id=%s WHERE operation_id=%s", (corr, oid)); conn.commit()
        if r.status_code >= 500:
            return fail_or_retry(conn, op, f"ORCHESTRATOR_{r.status_code}", r.text[:500], retryable=True)
        if r.status_code == 409:  # approval required in the stub's contract
            conn.execute("UPDATE operation SET status='AWAITING_APPROVAL', locked_by=NULL, locked_at=NULL, updated_at=CURRENT_TIMESTAMP WHERE operation_id=%s", (oid,))
            op_event(conn, oid, "RUNNING", "AWAITING_APPROVAL", {"reason": r.json().get("reason")}); conn.commit()
            return
        if r.status_code >= 400:
            return fail_or_retry(conn, op, f"ORCHESTRATOR_{r.status_code}", r.text[:500], retryable=False)
        result = r.json()
    succeed(conn, op, result)


def succeed(conn, op, result: dict):
    oid = op["operation_id"]
    conn.execute("UPDATE operation SET status='SUCCEEDED', result_payload=%s, orchestrator_correlation_id=COALESCE(%s, orchestrator_correlation_id), "
                 "completed_at=CURRENT_TIMESTAMP, locked_by=NULL, locked_at=NULL, updated_at=CURRENT_TIMESTAMP WHERE operation_id=%s",
                 (jb(result), result.get("correlationId"), oid))
    if op["operation_type"] == "CREATE_WORKSTATION":
        conn.execute("UPDATE workstation SET lifecycle_status='READY', url=%s, launch_url=%s, external_resource_name=%s, updated_at=CURRENT_TIMESTAMP "
                     "WHERE workstation_id=%s", (result.get("host"), result.get("launchUrl"), result.get("resourceName"), op["target_entity_id"]))
    elif op["operation_type"] == "DELETE_WORKSTATION":
        conn.execute("UPDATE workstation SET lifecycle_status='DELETING', deleted_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE workstation_id=%s",
                     (op["target_entity_id"],))
    op_event(conn, oid, "RUNNING", "SUCCEEDED", {"correlationId": result.get("correlationId")})
    conn.commit()
    log.info("op %s SUCCEEDED", oid)


def fail_or_retry(conn, op, code: str, message: str, retryable: bool):
    oid = op["operation_id"]
    if retryable and op["attempt_count"] < op["max_attempts"]:
        backoff_min = 2 ** op["attempt_count"]
        conn.execute("UPDATE operation SET status='PENDING', locked_by=NULL, locked_at=NULL, error_code=%s, error_message=%s, "
                     "next_attempt_at=CURRENT_TIMESTAMP + make_interval(mins => %s), updated_at=CURRENT_TIMESTAMP WHERE operation_id=%s",
                     (code, message, backoff_min, oid))
        op_event(conn, oid, "RUNNING", "PENDING", {"error": code, "retryInMinutes": backoff_min, "attempt": op["attempt_count"]})
        log.warning("op %s transient %s, retry in %s min", oid, code, backoff_min)
    else:
        conn.execute("UPDATE operation SET status='FAILED', locked_by=NULL, locked_at=NULL, error_code=%s, error_message=%s, "
                     "completed_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE operation_id=%s", (code, message, oid))
        if op["operation_type"] == "CREATE_WORKSTATION":
            conn.execute("UPDATE workstation SET lifecycle_status='FAILED', updated_at=CURRENT_TIMESTAMP WHERE workstation_id=%s", (op["target_entity_id"],))
        op_event(conn, oid, "RUNNING", "FAILED", {"error": code, "message": message[:200]})
        log.error("op %s FAILED %s", oid, code)
    conn.commit()


def sweep_stale(conn):
    rows = conn.execute(STALE_SQL, (LEASE_MINUTES,)).fetchall()
    for r in rows:
        op_event(conn, r["operation_id"], "RUNNING", "PENDING", {"reason": "stale lease", "was_locked_by": r["locked_by"]})
        log.warning("op %s: stale lease from %s reset to PENDING", r["operation_id"], r["locked_by"])
    conn.commit()


def main():
    log.info("worker %s starting, orchestrator=%s", WORKER_ID, ORCHESTRATOR_URL)
    client = httpx.Client()
    while True:
        try:
            with connect() as conn:
                listen = psycopg.connect(DATABASE_URL, autocommit=True)
                listen.execute("LISTEN operations")
                last_sweep = 0
                while True:
                    if time.time() - last_sweep > 60:
                        sweep_stale(conn); last_sweep = time.time()
                    op = claim(conn)
                    if op:
                        log.info("op %s claimed (%s, attempt %s)", op["operation_id"], op["operation_type"], op["attempt_count"])
                        try:
                            execute(conn, client, op)
                        except Exception as e:  # one bad op shouldn't take the loop down
                            conn.rollback()
                            log.exception("op %s crashed in worker: %s", op["operation_id"], e)
                        continue
                    # nothing to do: block on NOTIFY or the poll interval, whichever comes first
                    if select.select([listen], [], [], POLL_SECONDS)[0]:
                        for _ in listen.notifies(timeout=0):
                            pass
        except Exception as e:
            log.exception("worker loop error, reconnecting in 3s: %s", e)
            time.sleep(3)


if __name__ == "__main__":
    main()
