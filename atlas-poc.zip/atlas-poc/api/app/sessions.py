"""session routes"""
import os
from datetime import datetime, timedelta, timezone
from typing import Optional
from fastapi import APIRouter, Depends, Header, Query, Request, Response
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from . import context as ctx
from . import idempotency as idem
from .auth import Principal, current_principal, member_of_use_case, owns_use_case
from .db import jb, row_to_json, tx
from .errors import ApiError

router = APIRouter(prefix="/api/v1", tags=["Sessions"])

SESSION_TTL_HOURS = int(os.environ.get("SESSION_TTL_HOURS", "12"))
SESSION_LIMIT_PER_CLIENT = int(os.environ.get("SESSION_LIMIT_PER_CLIENT", "5"))
HEARTBEAT_DEBOUNCE_SECONDS = int(os.environ.get("HEARTBEAT_DEBOUNCE_SECONDS", "60"))
CLIENT_TYPES = ("WEB", "VSCODE", "SDK", "CLI")


class SessionCreate(BaseModel):
    clientType: str = Field(pattern="^(WEB|VSCODE|SDK|CLI)$")
    useCaseId: Optional[str] = None
    mlWorkspaceId: Optional[str] = None
    context: dict = Field(default_factory=dict)


class SessionPatch(BaseModel):
    useCaseId: Optional[str] = None
    mlWorkspaceId: Optional[str] = None
    context: Optional[dict] = None


class ForceEnd(BaseModel):
    reason: str = Field(min_length=1, max_length=500)
    endInFlightOperations: bool = False


SESSION_SELECT = """
SELECT s.*, u.principal_email, uc.name AS use_case_name,
       (SELECT count(*) FROM operation o WHERE o.session_id = s.session_id AND o.deleted_at IS NULL
          AND o.status IN ('PENDING','RUNNING','AWAITING_APPROVAL')) AS in_flight_operations
FROM session s
JOIN "user" u ON u.user_id = s.user_id
LEFT JOIN use_case uc ON uc.use_case_id = s.use_case_id
"""


def to_resource(row, admin: bool = False) -> dict:
    r = row_to_json(row)
    sid = r["session_id"]
    out = {
        "sessionId": sid, "userId": r["user_id"], "principalEmail": r["principal_email"],
        "useCaseId": r["use_case_id"], "useCaseName": r.get("use_case_name"), "mlWorkspaceId": r["ml_workspace_id"],
        "status": r["status"], "clientType": r["client_type"], "context": r["context"],
        "startedAt": r["started_at"], "lastSeenAt": r["last_seen_at"], "expiresAt": r["expires_at"],
        "endedAt": r["ended_at"], "endReason": r["end_reason"], "inFlightOperations": r.get("in_flight_operations", 0),
        "links": {"self": f"/api/v1/sessions/{sid}", "operations": f"/api/v1/operations?sessionId={sid}",
                  "events": f"/api/v1/sessions/{sid}/events"},
    }
    if admin:
        out["clientIp"] = r["client_ip"]
        out["userAgent"] = r["user_agent"]
    return out


def event(conn, session_id, event_type, actor, from_status=None, to_status=None, detail=None):
    conn.execute(
        "INSERT INTO session_event (session_id, event_type, from_status, to_status, actor, detail) VALUES (%s,%s,%s,%s,%s,%s)",
        (session_id, event_type, from_status, to_status, actor, jb(detail or {})),
    )


def load_session(conn, session_id: str, p: Principal, allow_owner: bool = True, for_update: bool = False):
    """load + authz. 404 / 403 / 410."""
    row = conn.execute(SESSION_SELECT + " WHERE s.session_id = %s AND s.deleted_at IS NULL" + (" FOR UPDATE OF s" if for_update else ""),
                       (session_id,)).fetchone()
    if not row:
        raise ApiError(404, "NOT_FOUND", f"Session {session_id} not found.")
    is_self = str(row["user_id"]) == p.user_id
    is_owner = allow_owner and row["use_case_id"] is not None and owns_use_case(conn, p.user_id, str(row["use_case_id"]))
    if not (is_self or is_owner or p.is_admin):
        raise ApiError(403, "FORBIDDEN", "Session belongs to another user.")
    if row["status"] in ("ENDED", "EXPIRED") and not p.is_admin:
        raise ApiError(410, "SESSION_GONE", f"Session {session_id} is {row['status']}.", {"status": row["status"]})
    return row


def check_use_case_access(conn, p: Principal, use_case_id: str):
    exists = conn.execute("SELECT 1 FROM use_case WHERE use_case_id = %s AND deleted_at IS NULL", (use_case_id,)).fetchone()
    if not exists:
        raise ApiError(404, "NOT_FOUND", f"Use case {use_case_id} not found.")
    if not (p.is_admin or member_of_use_case(conn, p.user_id, use_case_id)):
        raise ApiError(403, "FORBIDDEN", "You are not a member of that use case.")


def check_workspace(conn, ml_workspace_id: str, use_case_id: str | None):
    row = conn.execute("SELECT use_case_id FROM ml_workspace WHERE ml_workspace_id = %s AND deleted_at IS NULL", (ml_workspace_id,)).fetchone()
    if not row:
        raise ApiError(404, "NOT_FOUND", f"ML workspace {ml_workspace_id} not found.")
    if use_case_id and str(row["use_case_id"]) != use_case_id:
        raise ApiError(400, "VALIDATION_FAILED", "mlWorkspaceId does not belong to useCaseId.", {"fields": ["mlWorkspaceId"]})


# start
@router.post("/sessions", status_code=201)
def start_session(body: SessionCreate, request: Request, p: Principal = Depends(current_principal),
                  idempotency_key: str | None = Header(default=None, alias="Idempotency-Key")):
    ctx.validate_patch(body.context)
    with tx() as conn:
        if idempotency_key:
            replay = idem.lookup(conn, p.user_id, idempotency_key, "POST /sessions", body.model_dump())
            if replay:
                return replay
        if body.useCaseId:
            check_use_case_access(conn, p, body.useCaseId)
        if body.mlWorkspaceId:
            check_workspace(conn, body.mlWorkspaceId, body.useCaseId)

        # cap live sessions per client type; evict oldest idle one if we're at the limit
        live = conn.execute(
            "SELECT session_id, status, last_seen_at FROM session WHERE user_id = %s AND client_type = %s "
            "AND deleted_at IS NULL AND status IN ('ACTIVE','IDLE') ORDER BY (status = 'IDLE') DESC, last_seen_at ASC FOR UPDATE",
            (p.user_id, body.clientType)).fetchall()
        evicted = None
        if len(live) >= SESSION_LIMIT_PER_CLIENT:
            idle = [s for s in live if s["status"] == "IDLE"]
            if not idle:
                raise ApiError(409, "SESSION_LIMIT", f"You already hold {len(live)} active {body.clientType} sessions.",
                               {"liveSessions": [str(s["session_id"]) for s in live]})
            victim = idle[0]
            conn.execute("UPDATE session SET status='ENDED', end_reason='CONCURRENCY_LIMIT', ended_at=CURRENT_TIMESTAMP, "
                         "updated_at=CURRENT_TIMESTAMP WHERE session_id = %s", (victim["session_id"],))
            event(conn, victim["session_id"], "ENDED", p.email, "IDLE", "ENDED", {"reason": "CONCURRENCY_LIMIT"})
            evicted = str(victim["session_id"])

        client_ip = request.client.host if request.client else None
        row = conn.execute(
            "INSERT INTO session (user_id, use_case_id, ml_workspace_id, client_type, client_ip, user_agent, context, expires_at) "
            "VALUES (%s,%s,%s,%s,%s,%s,%s,%s) RETURNING session_id",
            (p.user_id, body.useCaseId, body.mlWorkspaceId, body.clientType, client_ip, request.headers.get("user-agent"),
             jb(body.context), datetime.now(timezone.utc) + timedelta(hours=SESSION_TTL_HOURS))).fetchone()
        sid = str(row["session_id"])
        event(conn, sid, "STARTED", p.email, None, "ACTIVE", {"clientType": body.clientType})
        full = conn.execute(SESSION_SELECT + " WHERE s.session_id = %s", (sid,)).fetchone()
        resource = to_resource(full)
        resource["evictedSessionId"] = evicted
        if idempotency_key:
            idem.store(conn, p.user_id, idempotency_key, "POST /sessions", body.model_dump(), 201, resource)
    return JSONResponse(status_code=201, content=resource, headers={"Location": f"/api/v1/sessions/{sid}"})


# list
@router.get("/sessions")
def list_sessions(p: Principal = Depends(current_principal), status: str = "live", userId: str | None = None,
                  useCaseId: str | None = None, clientType: str | None = None, since: datetime | None = None,
                  limit: int = Query(50, ge=1, le=200), cursor: str | None = None):
    return _list(p, status, userId, useCaseId, clientType, since, limit, cursor)


@router.get("/users/{user_id}/sessions")
def list_user_sessions(user_id: str, p: Principal = Depends(current_principal), status: str = "live",
                       limit: int = Query(50, ge=1, le=200), cursor: str | None = None):
    return _list(p, status, user_id, None, None, None, limit, cursor)


def _list(p, status, user_id, use_case_id, client_type, since, limit, cursor):
    with tx() as conn:
        if not p.is_admin:
            if user_id == p.user_id:
                pass
            elif use_case_id and owns_use_case(conn, p.user_id, use_case_id):
                pass
            else:
                raise ApiError(403, "FORBIDDEN", "List requires admin, your own userId, or a useCaseId you own.")
        where = ["s.deleted_at IS NULL"]; args = []
        if status == "live":
            where.append("s.status IN ('ACTIVE','IDLE')")
        elif status in ("ACTIVE", "IDLE", "ENDED", "EXPIRED"):
            where.append("s.status = %s"); args.append(status)
        else:
            raise ApiError(400, "VALIDATION_FAILED", "status must be live|ACTIVE|IDLE|ENDED|EXPIRED", {"fields": ["status"]})
        if user_id: where.append("s.user_id = %s"); args.append(user_id)
        if use_case_id: where.append("s.use_case_id = %s"); args.append(use_case_id)
        if client_type: where.append("s.client_type = %s"); args.append(client_type)
        if since: where.append("s.last_seen_at >= %s"); args.append(since)
        if cursor:
            try:
                c_ts, c_id = cursor.split("|", 1)
            except ValueError:
                raise ApiError(400, "VALIDATION_FAILED", "bad cursor", {"fields": ["cursor"]})
            where.append("(s.last_seen_at, s.session_id) < (%s::timestamptz, %s::uuid)"); args += [c_ts, c_id]
        rows = conn.execute(SESSION_SELECT + " WHERE " + " AND ".join(where) +
                            " ORDER BY s.last_seen_at DESC, s.session_id DESC LIMIT %s", args + [limit + 1]).fetchall()
        total = None
        if status == "live":
            total = conn.execute("SELECT count(*) AS n FROM session s WHERE " + " AND ".join(w for w in where if "<" not in w),
                                 [a for a in args if a not in (cursor,)][: len(args) - (2 if cursor else 0)]).fetchone()["n"]
    items = [to_resource(r, p.is_admin) for r in rows[:limit]]
    next_cursor = None
    if len(rows) > limit:
        last = rows[limit - 1]
        next_cursor = f"{last['last_seen_at'].isoformat()}|{last['session_id']}"
    out = {"items": items, "nextCursor": next_cursor}
    if total is not None:
        out["total"] = total
    return out


# current (by header)
@router.get("/sessions/current")
def get_current(p: Principal = Depends(current_principal),
                x_atlas_session_id: str | None = Header(default=None, alias="X-Atlas-Session-Id")):
    if not x_atlas_session_id:
        raise ApiError(400, "VALIDATION_FAILED", "X-Atlas-Session-Id header is required.", {"fields": ["X-Atlas-Session-Id"]})
    with tx() as conn:
        row = load_session(conn, x_atlas_session_id, p, allow_owner=False)
    return to_resource(row, p.is_admin)


# forceEnd -- keep this above /{session_id} so the literal suffix wins
@router.post("/sessions/{session_id}:forceEnd")
def force_end(session_id: str, body: ForceEnd, p: Principal = Depends(current_principal),
              idempotency_key: str = Header(alias="Idempotency-Key")):
    with tx() as conn:
        replay = idem.lookup(conn, p.user_id, idempotency_key, "POST /sessions/:forceEnd", {"id": session_id, **body.model_dump()})
        if replay:
            return replay
        row = conn.execute("SELECT * FROM session WHERE session_id = %s AND deleted_at IS NULL FOR UPDATE", (session_id,)).fetchone()
        if not row:
            raise ApiError(404, "NOT_FOUND", f"Session {session_id} not found.")
        if not (p.is_admin or (row["use_case_id"] and owns_use_case(conn, p.user_id, str(row["use_case_id"])))):
            raise ApiError(403, "FORBIDDEN", "forceEnd requires PLATFORM_ADMIN or ownership of the session's use case.")
        cancelled = []
        if row["status"] in ("ACTIVE", "IDLE"):
            conn.execute("UPDATE session SET status='ENDED', end_reason='ADMIN', ended_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP "
                         "WHERE session_id = %s", (session_id,))
            event(conn, session_id, "ENDED", p.email, row["status"], "ENDED", {"reason": body.reason, "by": "ADMIN"})
        if body.endInFlightOperations:
            ops = conn.execute("UPDATE operation SET status='CANCELLED', completed_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP "
                               "WHERE session_id = %s AND deleted_at IS NULL AND status IN ('PENDING','AWAITING_APPROVAL') "
                               "RETURNING operation_id, status", (session_id,)).fetchall()
            for o in ops:
                conn.execute("INSERT INTO operation_event (operation_id, from_status, to_status, actor, detail) VALUES (%s,'PENDING','CANCELLED',%s,%s)",
                             (o["operation_id"], p.email, jb({"reason": body.reason, "via": "forceEnd"})))
                cancelled.append(str(o["operation_id"]))
        resp = {"sessionId": session_id, "status": "ENDED", "cancelledOperations": cancelled}
        idem.store(conn, p.user_id, idempotency_key, "POST /sessions/:forceEnd", {"id": session_id, **body.model_dump()}, 200, resp)
    return resp


# get
@router.get("/sessions/{session_id}")
def get_session(session_id: str, p: Principal = Depends(current_principal)):
    with tx() as conn:
        row = load_session(conn, session_id, p)
    return to_resource(row, p.is_admin)


# patch
@router.patch("/sessions/{session_id}")
def patch_session(session_id: str, body: SessionPatch, p: Principal = Depends(current_principal),
                  idempotency_key: str = Header(alias="Idempotency-Key")):
    if body.useCaseId is None and body.mlWorkspaceId is None and body.context is None:
        raise ApiError(400, "VALIDATION_FAILED", "At least one of useCaseId, mlWorkspaceId, context is required.")
    if body.context is not None:
        ctx.validate_patch(body.context)
    with tx() as conn:
        replay = idem.lookup(conn, p.user_id, idempotency_key, "PATCH /sessions", {"id": session_id, **body.model_dump()})
        if replay:
            return replay
        row = load_session(conn, session_id, p, allow_owner=False, for_update=True)
        if str(row["user_id"]) != p.user_id:
            raise ApiError(403, "FORBIDDEN", "Only the session owner may change its context.")
        new_uc = body.useCaseId if body.useCaseId is not None else (str(row["use_case_id"]) if row["use_case_id"] else None)
        if body.useCaseId is not None:
            check_use_case_access(conn, p, body.useCaseId)
        new_ws = body.mlWorkspaceId
        if new_ws is None and body.useCaseId is not None and body.useCaseId != (str(row["use_case_id"]) if row["use_case_id"] else None):
            new_ws = None  # use case changed, workspace cleared
        elif new_ws is None:
            new_ws = str(row["ml_workspace_id"]) if row["ml_workspace_id"] else None
        if body.mlWorkspaceId is not None:
            check_workspace(conn, body.mlWorkspaceId, new_uc)
        merged = ctx.merge(row["context"], body.context) if body.context is not None else row["context"]
        conn.execute("UPDATE session SET use_case_id=%s, ml_workspace_id=%s, context=%s, status='ACTIVE', last_seen_at=CURRENT_TIMESTAMP, "
                     "updated_at=CURRENT_TIMESTAMP WHERE session_id = %s", (new_uc, new_ws, jb(merged), session_id))
        detail = {}
        if new_uc != (str(row["use_case_id"]) if row["use_case_id"] else None):
            detail["useCaseId"] = {"from": str(row["use_case_id"]) if row["use_case_id"] else None, "to": new_uc}
        if new_ws != (str(row["ml_workspace_id"]) if row["ml_workspace_id"] else None):
            detail["mlWorkspaceId"] = {"from": str(row["ml_workspace_id"]) if row["ml_workspace_id"] else None, "to": new_ws}
        if body.context is not None:
            detail["contextKeys"] = sorted(body.context.keys())
        event(conn, session_id, "CONTEXT_CHANGED", p.email, row["status"], "ACTIVE", detail)
        full = conn.execute(SESSION_SELECT + " WHERE s.session_id = %s", (session_id,)).fetchone()
        resource = to_resource(full)
        idem.store(conn, p.user_id, idempotency_key, "PATCH /sessions", {"id": session_id, **body.model_dump()}, 200, resource)
    return resource


# heartbeat
@router.post("/sessions/{session_id}/heartbeat")
def heartbeat(session_id: str, p: Principal = Depends(current_principal)):
    with tx() as conn:
        row = load_session(conn, session_id, p, allow_owner=False, for_update=True)
        if str(row["user_id"]) != p.user_id:
            raise ApiError(403, "FORBIDDEN", "Only the session owner may heartbeat.")
        upd = conn.execute(
            "UPDATE session SET last_seen_at=CURRENT_TIMESTAMP, status='ACTIVE', expires_at=CURRENT_TIMESTAMP + make_interval(hours => %s), "
            "updated_at=CURRENT_TIMESTAMP WHERE session_id=%s AND status IN ('ACTIVE','IDLE') "
            "AND last_seen_at < CURRENT_TIMESTAMP - make_interval(secs => %s) RETURNING expires_at",
            (SESSION_TTL_HOURS, session_id, HEARTBEAT_DEBOUNCE_SECONDS)).fetchone()
        debounced = upd is None
        if not debounced and row["status"] == "IDLE":
            event(conn, session_id, "RESUMED", p.email, "IDLE", "ACTIVE")
        expires = upd["expires_at"] if upd else row["expires_at"]
    return {"sessionId": session_id, "status": "ACTIVE" if not debounced else row["status"], "expiresAt": expires.isoformat(), "debounced": debounced}


# end
@router.delete("/sessions/{session_id}", status_code=204)
def end_session(session_id: str, p: Principal = Depends(current_principal), reason: str | None = Query(default=None, max_length=200),
                idempotency_key: str = Header(alias="Idempotency-Key")):
    with tx() as conn:
        row = conn.execute("SELECT * FROM session WHERE session_id = %s AND deleted_at IS NULL FOR UPDATE", (session_id,)).fetchone()
        if not row:
            raise ApiError(404, "NOT_FOUND", f"Session {session_id} not found.")
        if str(row["user_id"]) != p.user_id:
            raise ApiError(403, "FORBIDDEN", "Only the session owner may end it. Admins use :forceEnd.")
        if row["status"] in ("ACTIVE", "IDLE"):
            conn.execute("UPDATE session SET status='ENDED', end_reason='USER', ended_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP "
                         "WHERE session_id = %s", (session_id,))
            event(conn, session_id, "ENDED", p.email, row["status"], "ENDED", {"reason": reason} if reason else {})
    return Response(status_code=204)


# events
@router.get("/sessions/{session_id}/events")
def session_events(session_id: str, p: Principal = Depends(current_principal), limit: int = Query(50, ge=1, le=200)):
    with tx() as conn:
        row = conn.execute("SELECT user_id, use_case_id FROM session WHERE session_id = %s AND deleted_at IS NULL", (session_id,)).fetchone()
        if not row:
            raise ApiError(404, "NOT_FOUND", f"Session {session_id} not found.")
        if not (str(row["user_id"]) == p.user_id or p.is_admin or (row["use_case_id"] and owns_use_case(conn, p.user_id, str(row["use_case_id"])))):
            raise ApiError(403, "FORBIDDEN", "Not permitted to read this session's events.")
        rows = conn.execute("SELECT event_type, from_status, to_status, actor, detail, created_at FROM session_event "
                            "WHERE session_id = %s ORDER BY created_at LIMIT %s", (session_id, limit)).fetchall()
    return {"items": [{"eventType": r["event_type"], "fromStatus": r["from_status"], "toStatus": r["to_status"], "actor": r["actor"],
                       "detail": r["detail"], "createdAt": r["created_at"].isoformat()} for r in rows], "nextCursor": None}
