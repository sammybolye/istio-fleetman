"""fake orchestrator. sync, idempotent on Idempotency-Key, queryable by key. sleeps to look like terraform.
PROVISION_SECONDS / FAIL_FIRST_ATTEMPT to poke at the retry paths."""
import os
import time
import uuid
from fastapi import FastAPI, Header, Request
from fastapi.responses import JSONResponse

app = FastAPI(title="Orchestrator stub")
PROVISION_SECONDS = float(os.environ.get("PROVISION_SECONDS", "5"))
FAIL_FIRST_ATTEMPT = os.environ.get("FAIL_FIRST_ATTEMPT", "false").lower() == "true"
_store: dict[str, dict] = {}
_seen_once: set[str] = set()


@app.post("/provision")
def provision(body: dict, request: Request, idempotency_key: str = Header(alias="Idempotency-Key")):
    if idempotency_key in _store:
        return JSONResponse(_store[idempotency_key], headers={"X-Correlation-Id": _store[idempotency_key]["correlationId"], "Idempotent-Replayed": "true"})
    if FAIL_FIRST_ATTEMPT and idempotency_key not in _seen_once:
        _seen_once.add(idempotency_key)
        return JSONResponse({"error": "simulated transient failure"}, status_code=503)
    corr = f"run-{uuid.uuid4().hex[:8]}"
    ws = body.get("workstation") or {}
    if (ws.get("gpu_count") or 0) > 1:
        return JSONResponse({"reason": "GPU count above 1 needs business approval"}, status_code=409, headers={"X-Correlation-Id": corr})
    time.sleep(PROVISION_SECONDS)  # pretend terraform apply
    name = ws.get("workstation_id", idempotency_key)[:8]
    if body.get("operationType") == "DELETE_WORKSTATION":
        result = {"correlationId": corr, "deleted": True, "resourceName": ws.get("external_resource_name")}
    else:
        result = {
            "correlationId": corr,
            "resourceName": f"//workstations.googleapis.com/projects/cl-affordability-dev/locations/europe-west2/workstationClusters/cl/workstationConfigs/atlas/workstations/ws-{name}",
            "host": f"ws-{name}.cl-affordability-dev.workstations.example",
            "launchUrl": f"https://80-ws-{name}.cl-affordability-dev.workstations.example",
        }
    _store[idempotency_key] = result
    return JSONResponse(result, headers={"X-Correlation-Id": corr})


@app.get("/provision/{idempotency_key}")
def status(idempotency_key: str):
    if idempotency_key in _store:
        return _store[idempotency_key]
    return JSONResponse({"error": "unknown key"}, status_code=404)


@app.get("/healthz")
def healthz():
    return {"ok": True, "provisionSeconds": PROVISION_SECONDS, "failFirstAttempt": FAIL_FIRST_ATTEMPT}
