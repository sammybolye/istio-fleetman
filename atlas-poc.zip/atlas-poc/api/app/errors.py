"""error envelope: {error: {code, message, details, requestId}}"""
import uuid
from fastapi import Request
from fastapi.responses import JSONResponse


class ApiError(Exception):
    def __init__(self, status: int, code: str, message: str, details: dict | None = None):
        self.status = status
        self.code = code
        self.message = message
        self.details = details or {}


def request_id(request: Request) -> str:
    rid = getattr(request.state, "request_id", None)
    if not rid:
        rid = str(uuid.uuid4())
        request.state.request_id = rid
    return rid


async def api_error_handler(request: Request, exc: ApiError):
    body = {"error": {"code": exc.code, "message": exc.message, "details": exc.details, "requestId": request_id(request)}}
    return JSONResponse(status_code=exc.status, content=body, headers={"X-Request-Id": request_id(request)})


async def validation_error_handler(request: Request, exc):
    fields = [".".join(str(p) for p in e.get("loc", [])) for e in exc.errors()]
    body = {"error": {"code": "VALIDATION_FAILED", "message": "Request failed validation.",
                      "details": {"fields": fields}, "requestId": request_id(request)}}
    return JSONResponse(status_code=400, content=body, headers={"X-Request-Id": request_id(request)})
