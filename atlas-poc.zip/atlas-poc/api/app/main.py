"""atlas experience api"""
import uuid
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from psycopg.errors import InvalidTextRepresentation
from .db import close_pool, open_pool, pool
from .errors import ApiError, api_error_handler, validation_error_handler
from .operations import router as operations_router
from .sessions import router as sessions_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    open_pool()
    yield
    close_pool()


app = FastAPI(title="Atlas Experience API", version="0.1.0-poc", lifespan=lifespan)
app.add_exception_handler(ApiError, api_error_handler)
app.add_exception_handler(RequestValidationError, validation_error_handler)


async def bad_uuid_handler(request: Request, exc: InvalidTextRepresentation):
    rid = getattr(request.state, "request_id", "")
    return JSONResponse(status_code=400, content={"error": {"code": "VALIDATION_FAILED", "message": "A path or query value is not a valid identifier.",
                                                            "details": {}, "requestId": rid}}, headers={"X-Request-Id": rid})


app.add_exception_handler(InvalidTextRepresentation, bad_uuid_handler)
app.include_router(sessions_router)
app.include_router(operations_router)


@app.middleware("http")
async def request_id_middleware(request: Request, call_next):
    request.state.request_id = request.headers.get("X-Request-Id", str(uuid.uuid4()))
    response = await call_next(request)
    response.headers["X-Request-Id"] = request.state.request_id
    return response


@app.get("/healthz")
def healthz():
    with pool.connection() as conn:
        conn.execute("SELECT 1")
    return {"ok": True}
