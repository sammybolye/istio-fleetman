"""reaper: mark idle, expire, purge old idempotency keys, retire old sessions"""
import logging
import os
import time
import psycopg
from psycopg.rows import dict_row
from .db import DATABASE_URL, jb

log = logging.getLogger("atlas.reaper")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")

INTERVAL = int(os.environ.get("REAPER_INTERVAL_SECONDS", "300"))
IDLE_AFTER_MIN = int(os.environ.get("SESSION_IDLE_MINUTES", "15"))
RETAIN_DAYS = int(os.environ.get("SESSION_RETAIN_DAYS", "90"))
ACTOR = "atlas-reaper@atlas.system"


def sweep():
    with psycopg.connect(DATABASE_URL, row_factory=dict_row) as conn:
        idle = conn.execute(
            "UPDATE session SET status='IDLE', updated_at=CURRENT_TIMESTAMP WHERE status='ACTIVE' AND deleted_at IS NULL "
            "AND last_seen_at < CURRENT_TIMESTAMP - make_interval(mins => %s) RETURNING session_id", (IDLE_AFTER_MIN,)).fetchall()
        for r in idle:
            conn.execute("INSERT INTO session_event (session_id, event_type, from_status, to_status, actor) VALUES (%s,'IDLE','ACTIVE','IDLE',%s)",
                         (r["session_id"], ACTOR))
        expired = conn.execute(
            "UPDATE session SET status='EXPIRED', end_reason='EXPIRED', ended_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP "
            "WHERE status IN ('ACTIVE','IDLE') AND deleted_at IS NULL AND expires_at < CURRENT_TIMESTAMP RETURNING session_id, status",
        ).fetchall()
        for r in expired:
            conn.execute("INSERT INTO session_event (session_id, event_type, to_status, actor) VALUES (%s,'EXPIRED','EXPIRED',%s)",
                         (r["session_id"], ACTOR))
        purged = conn.execute("DELETE FROM idempotency_key WHERE expires_at < CURRENT_TIMESTAMP").rowcount
        # retention: sessions with no operations can go entirely, the rest get soft-deleted (operation.session_id is RESTRICT)
        old = conn.execute("SELECT session_id FROM session WHERE ended_at < CURRENT_TIMESTAMP - make_interval(days => %s) AND deleted_at IS NULL",
                           (RETAIN_DAYS,)).fetchall()
        hard = soft = 0
        for r in old:
            has_ops = conn.execute("SELECT 1 FROM operation WHERE session_id = %s LIMIT 1", (r["session_id"],)).fetchone()
            if has_ops:
                conn.execute("UPDATE session SET deleted_at=CURRENT_TIMESTAMP WHERE session_id=%s", (r["session_id"],)); soft += 1
            else:
                conn.execute("DELETE FROM session_event WHERE session_id=%s", (r["session_id"],))
                conn.execute("DELETE FROM session WHERE session_id=%s", (r["session_id"],)); hard += 1
        conn.commit()
        log.info("sweep: idle=%d expired=%d keys_purged=%d retired_hard=%d retired_soft=%d", len(idle), len(expired), purged, hard, soft)


def main():
    log.info("reaper starting, interval=%ss idle_after=%smin", INTERVAL, IDLE_AFTER_MIN)
    while True:
        try:
            sweep()
        except Exception as e:
            log.exception("sweep failed: %s", e)
        time.sleep(INTERVAL)


if __name__ == "__main__":
    main()
