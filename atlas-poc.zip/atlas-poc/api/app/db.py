"""db pool + helpers"""
import os
import json
from contextlib import contextmanager
from psycopg import Connection
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb
from psycopg_pool import ConnectionPool

DATABASE_URL = os.environ.get("DATABASE_URL", "postgresql://atlas:atlas@localhost:5432/atlas")

pool = ConnectionPool(
    conninfo=DATABASE_URL,
    min_size=1,
    max_size=int(os.environ.get("DB_POOL_MAX", "8")),
    kwargs={"row_factory": dict_row, "autocommit": False},
    open=False,
)


def open_pool():
    pool.open()
    pool.wait(timeout=30)


def close_pool():
    pool.close()


@contextmanager
def tx():
    """One transaction. Commits on success, rolls back on exception."""
    with pool.connection() as conn:  # type: Connection
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise


def jb(value):
    """Wrap a Python object for a JSONB parameter."""
    return Jsonb(value)


def row_to_json(row):
    """Make a dict row JSON-serialisable (UUIDs, datetimes, IPs)."""
    return json.loads(json.dumps(row, default=str))
