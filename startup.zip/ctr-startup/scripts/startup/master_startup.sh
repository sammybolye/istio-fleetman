#!/bin/bash

#################################################################################
#DO NOT REMOVE
#Run the static custom scripts injected into the container image
/opt/scripts/custom/banner.sh
#
#Run the system script to inherit GCE Metadata variables.
/opt/scripts/custom/get_gce_md.sh
#
#Run the  dynamic dl-post-startup-script
/opt/scripts/dynamic/run-dl-post-startup-script.sh
#
################################################################################

#INSERT CUSTOM SCRIPTS BELOW



#DO NOT DELETE!!!!
#Run the Jupyter Service/
/run_jupyter.sh
