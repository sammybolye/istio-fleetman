#!/bin/bash

echo "This is a dummy file to validate that the scripts injected by the docker build are operational" > /tmp/custom_script.log
