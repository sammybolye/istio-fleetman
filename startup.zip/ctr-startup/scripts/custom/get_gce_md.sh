#!/bin/bash

# URL to fetch instance metadata
METADATA_URL="http://metadata.google.internal/computeMetadata/v1/instance/attributes/"
HEADER="Metadata-Flavor: Google"

# File where persistent environment variables will be stored
PROFILE_SCRIPT="$HOME/.gce_metadata_env"

# Clear the file to prevent duplicate entries
echo "#!/bin/bash" > "$PROFILE_SCRIPT"

# Fetch the list of metadata keys
KEYS=$(curl -s -H "$HEADER" "$METADATA_URL")

# Loop through each key and fetch its value
for KEY in $KEYS; do
  # Fetch value for the metadata key
  VALUE=$(curl -s -H "$HEADER" "${METADATA_URL}${KEY}")

  # Convert key to uppercase and replace hyphens with underscores
  ENV_KEY=$(echo "$KEY" | tr '[:lower:]' '[:upper:]' | tr '-' '_')

  # Export as an environment variable (current session)
  export "$ENV_KEY"="$VALUE"

  # Append to ~/.gce_metadata_env for persistence
  echo "export $ENV_KEY=\"$VALUE\"" >> "$PROFILE_SCRIPT"
done

# Ensure script is executable
chmod +x "$PROFILE_SCRIPT"

# Add source command to .bashrc to ensure variables persist across sessions
if ! grep -q "source $PROFILE_SCRIPT" "$HOME/.bashrc"; then
  echo "source $PROFILE_SCRIPT" >> "$HOME/.bashrc"
fi

echo "Metadata variables have been set and will persist across reboots."
