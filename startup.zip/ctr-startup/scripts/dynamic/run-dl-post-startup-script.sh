#!/bin/bash


echo "Fetching startup script URL from GCE metadata..."
SCRIPT_URL=$(curl -H "Metadata-Flavor: Google" "http://metadata.google.internal/computeMetadata/v1/instance/attributes/dl-post-startup-script" -s)

if [[ -n "$SCRIPT_URL" ]]; then
    echo "Downloading user-defined startup script from GCS bucket at $SCRIPT_URL..."
    gsutil cp "$SCRIPT_URL" /opt/scripts/dynamic/dl-post-startup_script.sh
    if [[ $? -eq 0 ]]; then
        chmod +x /opt/scripts/dynamic/dl-post-startup_script.sh
        echo "Executing user-defined startup script..."
        /opt/scripts/dynamic/dl-post-startup_script.sh
    else
        echo "Failed to download the startup script from $SCRIPT_URL."
    fi
else
    echo "No startup script URL found in metadata. Skipping..."
fi

