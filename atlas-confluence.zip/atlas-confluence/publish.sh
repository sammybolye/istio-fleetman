#!/usr/bin/env bash
# Publish the whole design set to Confluence: one parent page and one child page per document, with attachments.
# Idempotent: re-running updates pages in place (matched by title within the space).
#
#   CONFLUENCE_BASE=https://<site>.atlassian.net/wiki  CONFLUENCE_USER=<email>  CONFLUENCE_TOKEN=<api token>
#   SPACE_KEY=<space>  [PARENT_ID=<page id to nest the parent under>]  ./publish.sh
#
# Server/DC: CONFLUENCE_BASE=https://confluence.<company>/  and a personal access token works as the password.
set -euo pipefail
: "${CONFLUENCE_BASE:?}" "${CONFLUENCE_USER:?}" "${CONFLUENCE_TOKEN:?}" "${SPACE_KEY:?}"
HERE=$(cd "$(dirname "$0")" && pwd)
AUTH="$CONFLUENCE_USER:$CONFLUENCE_TOKEN"
MANIFEST="$HERE/manifest.json"

api() { curl -s -u "$AUTH" -H 'Content-Type: application/json' "$@"; }
jsonstr() { python3 -c 'import json,sys; print(json.dumps(open(sys.argv[1]).read()))' "$1"; }
urlenc() { python3 -c 'import urllib.parse,sys; print(urllib.parse.quote(sys.argv[1]))' "$1"; }

# upsert_page TITLE BODYFILE ANCESTOR_ID -> echoes page id
upsert_page() {
  local title=$1 file=$2 ancestor=${3:-}
  local body; body=$(jsonstr "$file")
  local anc=""; [ -n "$ancestor" ] && anc=", \"ancestors\": [{\"id\": \"$ancestor\"}]"
  local existing; existing=$(api "$CONFLUENCE_BASE/rest/api/content?spaceKey=$SPACE_KEY&title=$(urlenc "$title")&expand=version")
  local id; id=$(echo "$existing" | python3 -c 'import sys,json; r=json.load(sys.stdin)["results"]; print(r[0]["id"] if r else "")')
  if [ -z "$id" ]; then
    id=$(api -X POST "$CONFLUENCE_BASE/rest/api/content" \
      -d "{\"type\":\"page\",\"title\":$(python3 -c 'import json,sys;print(json.dumps(sys.argv[1]))' "$title"),\"space\":{\"key\":\"$SPACE_KEY\"}$anc,\"body\":{\"storage\":{\"value\":$body,\"representation\":\"storage\"}}}" \
      | python3 -c 'import sys,json; d=json.load(sys.stdin); print(d.get("id") or sys.exit("create failed: "+json.dumps(d)[:300]))')
    echo "created  $id  $title" >&2
  else
    local ver; ver=$(echo "$existing" | python3 -c 'import sys,json; print(json.load(sys.stdin)["results"][0]["version"]["number"]+1)')
    api -o /dev/null -X PUT "$CONFLUENCE_BASE/rest/api/content/$id" \
      -d "{\"id\":\"$id\",\"type\":\"page\",\"title\":$(python3 -c 'import json,sys;print(json.dumps(sys.argv[1]))' "$title"),\"version\":{\"number\":$ver}$anc,\"body\":{\"storage\":{\"value\":$body,\"representation\":\"storage\"}}}"
    echo "updated  $id  $title (v$ver)" >&2
  fi
  echo "$id"
}

attach() {  # attach PAGE_ID FILE...
  local page=$1; shift
  for f in "$@"; do
    [ -f "$HERE/attachments/$f" ] || { echo "  missing attachment $f" >&2; continue; }
    curl -s -o /dev/null -u "$AUTH" -X PUT "$CONFLUENCE_BASE/rest/api/content/$page/child/attachment" \
      -H 'X-Atlassian-Token: nocheck' -F "file=@$HERE/attachments/$f" -F "minorEdit=true"
    echo "  attached $f" >&2
  done
}

PARENT_TITLE=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["parent"])' "$MANIFEST")
PARENT_FILE=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["parent_file"])' "$MANIFEST")
PARENT=$(upsert_page "$PARENT_TITLE" "$HERE/$PARENT_FILE" "${PARENT_ID:-}")
attach "$PARENT" $(python3 -c 'import json,sys; print(" ".join(json.load(open(sys.argv[1]))["parent_attachments"]))' "$MANIFEST")

python3 -c 'import json,sys; [print(p["title"]+"\t"+p["file"]+"\t"+" ".join(p["attachments"])) for p in json.load(open(sys.argv[1]))["pages"]]' "$MANIFEST" \
| while IFS=$'\t' read -r title file atts; do
    id=$(upsert_page "$title" "$HERE/$file" "$PARENT")
    [ -n "$atts" ] && attach "$id" $atts
  done

echo "done: $CONFLUENCE_BASE/pages/viewpage.action?pageId=$PARENT"
