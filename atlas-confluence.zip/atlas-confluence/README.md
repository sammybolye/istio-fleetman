# Importing the Atlas design set into Confluence

Everything in this folder is generated from the markdown in `../atlas-design-pack/md` by `build.py`.

```
pages/            one Confluence storage-format (XHTML) file per page, plus index.storage.xhtml for the parent
attachments/      every diagram as PNG (+ Mermaid source) and the OpenAPI yaml
docx/             Word version of each page, for the "Import Word Document" fallback
manifest.json     page titles, files, and which attachments each page needs
publish.sh        creates or updates the whole tree through the REST API
build.py          regenerate after editing the markdown
```

Pages (parent first, then children in this order):

1. Atlas Session Persistence Design  *(index page, links to the rest, carries the OpenAPI attachment)*
2. Atlas Session Management  *(the short one, written in the style of the entity model page)*
3. Atlas Session and Operation Persistence
4. Atlas Provisioning Chain of Events
5. Atlas Experience API Reference
6. Atlas Session Database Metadata Classification
7. Atlas Terraform Hydration
8. Atlas Source Material (Workshop, ERD, DDL, Gemini Review)

Cross-references between documents are Confluence page links by title, so keep the titles as they are or edit `PAGES` in `build.py` and rebuild.

## Option A: REST API (recommended, one command)

```
CONFLUENCE_BASE=https://<site>.atlassian.net/wiki \
CONFLUENCE_USER=<your email> \
CONFLUENCE_TOKEN=<api token from id.atlassian.com> \
SPACE_KEY=<space key> \
PARENT_ID=<optional: id of the page to nest under, e.g. the entity model page> \
./publish.sh
```

Creates the parent and the seven children, attaches the right PNGs to each, and prints the parent URL. Re-running updates pages in place (matched by title) and re-uploads attachments as new versions. On Server or Data Center use the base URL of your instance and a personal access token as the token.

## Option B: paste by hand

For each page: create it, open the editor, `/` then **Markup**, choose *Confluence storage format*, paste the matching file from `pages/`, save, then drag the attachments listed for that page in `manifest.json` onto it. Create the parent first so the child page links resolve. Fourteen minutes of clicking for eight pages, so prefer option A if you have an API token.

## Option C: Word import

Space settings, Content Tools, **Import Word Document**, one `docx/` file per page. Diagrams are embedded. Code blocks come through as preformatted text rather than the code macro, and the cross-links between pages become plain text.

## Regenerating

Edit the markdown in `../atlas-design-pack/md`, then:

```
python3 atlas-confluence/build.py
./atlas-confluence/publish.sh   # with the same env vars
```

Diagrams already rendered are reused; a new Mermaid block without a matching PNG is rendered on the fly (needs Node for the Mermaid CLI). Word output needs pandoc.
