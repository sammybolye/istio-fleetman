#!/usr/bin/env python3
"""Convert the design pack markdown into Confluence storage format pages + attachments + docx fallbacks.
Run from the atlas-session folder:  python3 atlas-confluence/build.py
"""
import html, json, pathlib, re, shutil, subprocess, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
PACK = ROOT / "atlas-design-pack"
OUT = ROOT / "atlas-confluence"
PAGES_DIR = OUT / "pages"
ATT_DIR = OUT / "attachments"
DOCX_DIR = OUT / "docx"
CFG = OUT / "mmd-config.json"

# order = page order under the parent
PAGES = [
    ("atlas-session-management.md",            "Atlas Session Management"),
    ("atlas-session-persistence-spec.md",       "Atlas Session and Operation Persistence"),
    ("atlas-provisioning-chain-of-events.md",   "Atlas Provisioning Chain of Events"),
    ("atlas-api-reference.md",                  "Atlas Experience API Reference"),
    ("atlas-metadata-classification.md",        "Atlas Session Database Metadata Classification"),
    ("atlas-terraform-hydration.md",            "Atlas Terraform Hydration"),
    ("atlas-source-material.md",                "Atlas Source Material (Workshop, ERD, DDL, Gemini Review)"),
]
PARENT_TITLE = "Atlas Session Persistence Design"
LINK_MAP = {md: title for md, title in PAGES}


def esc(t):
    return html.escape(t, quote=False)


def inline(t):
    t = esc(t)
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    t = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", t)
    t = re.sub(r"(?<![\w*])\*([^*\n]+)\*(?!\w)", r"<em>\1</em>", t)
    # links: to another pack doc -> page link; to a file in the pack -> attachment link; else plain link
    def link(m):
        text, href = m.group(1), m.group(2)
        base = href.split("#")[0].split("/")[-1]
        if base in LINK_MAP:
            return f'<ac:link><ri:page ri:content-title="{esc(LINK_MAP[base])}" /><ac:plain-text-link-body><![CDATA[{html.unescape(text)}]]></ac:plain-text-link-body></ac:link>'
        if base.endswith((".png", ".svg", ".mmd", ".yaml")):
            return f'<ac:link><ri:attachment ri:filename="{base}" /><ac:plain-text-link-body><![CDATA[{html.unescape(text)}]]></ac:plain-text-link-body></ac:link>'
        return f'<a href="{href}">{text}</a>'
    t = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", link, t)
    return t.replace("→", "&rarr;").replace("≥", "&ge;").replace("≤", "&le;")


def code_macro(lang, body):
    lang = {"sql": "sql", "json": "js", "http": "text", "bash": "bash", "yaml": "yml", "mermaid": "text", "": "text"}.get(lang, "text")
    return (f'<ac:structured-macro ac:name="code"><ac:parameter ac:name="language">{lang}</ac:parameter>'
            f'<ac:parameter ac:name="theme">Confluence</ac:parameter><ac:plain-text-body><![CDATA[{body}]]></ac:plain-text-body></ac:structured-macro>')


def expand(title, inner):
    return f'<ac:structured-macro ac:name="expand"><ac:parameter ac:name="title">{esc(title)}</ac:parameter><ac:rich-text-body>{inner}</ac:rich-text-body></ac:structured-macro>'


def image(filename):
    return f'<p><ac:image ac:align="center" ac:layout="center" ac:original-width="1400"><ri:attachment ri:filename="{filename}" /></ac:image></p>'


def render_mermaid(mmd, name):
    """Render a mermaid block to attachments/<name>.png if not already there."""
    png = ATT_DIR / f"{name}.png"
    if png.exists():
        return png.name
    src = ATT_DIR / f"{name}.mmd"
    src.write_text(mmd)
    subprocess.run(["npx", "-y", "@mermaid-js/mermaid-cli@11.4.2", "-i", str(src), "-o", str(png), "-c", str(CFG), "-b", "white", "-s", "2"],
                   check=True, capture_output=True)
    return png.name


def convert(md_text, slug):
    lines = md_text.split("\n")
    out, i = [], 0
    in_ul = False
    mermaid_n = 0
    pending_mermaid = None  # (source) waiting to see if an image line follows

    def close():
        nonlocal in_ul
        if in_ul:
            out.append("</ul>")
            in_ul = False

    def flush_mermaid(png=None):
        nonlocal pending_mermaid, mermaid_n
        if pending_mermaid is None:
            return
        if png is None:
            mermaid_n += 1
            png = render_mermaid(pending_mermaid, f"{slug}-diagram-{mermaid_n}")
        out.append(image(png))
        out.append(expand("Diagram source (Mermaid)", code_macro("mermaid", pending_mermaid)))
        pending_mermaid = None

    while i < len(lines):
        l = lines[i]
        if l.startswith("```"):
            close()
            lang = l[3:].strip()
            buf = []
            i += 1
            while i < len(lines) and not lines[i].startswith("```"):
                buf.append(lines[i]); i += 1
            i += 1
            body = "\n".join(buf)
            if lang == "mermaid":
                flush_mermaid()
                pending_mermaid = body
            else:
                flush_mermaid()
                out.append(code_macro(lang, body))
            continue
        if l.startswith("!["):
            m = re.match(r"!\[[^\]]*\]\(([^)]+)\)", l)
            png = pathlib.Path(m.group(1)).name if m else None
            if pending_mermaid is not None and png:
                flush_mermaid(png)
            elif png:
                out.append(image(png))
            i += 1
            continue
        if l.startswith("*Rendered:"):
            i += 1
            continue
        flush_mermaid()
        if l.startswith("# "):
            close()
            t = l[2:].strip()
            if out:  # mid-document part heading
                out.append(f"<h1>{inline(t)}</h1>")
            i += 1
            continue
        if l.startswith("## "):
            close(); out.append(f"<h2>{inline(l[3:].strip())}</h2>"); i += 1; continue
        if l.startswith("### "):
            close(); out.append(f"<h3>{inline(l[4:].strip())}</h3>"); i += 1; continue
        if l.startswith("#### "):
            close(); out.append(f"<h4>{inline(l[5:].strip())}</h4>"); i += 1; continue
        if l.startswith("|"):
            close()
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                rows.append(lines[i]); i += 1
            cells = []
            for r in rows:
                if re.match(r"^\|[\s:\-|]+\|$", r):
                    continue
                parts = re.split(r"(?<!\\)\|", r.strip().strip("|"))
                cells.append([c.strip().replace("\\|", "|") for c in parts])
            t = ["<table><tbody><tr>" + "".join(f"<th>{inline(c)}</th>" for c in cells[0]) + "</tr>"]
            for r in cells[1:]:
                t.append("<tr>" + "".join(f"<td>{inline(c)}</td>" for c in r) + "</tr>")
            t.append("</tbody></table>")
            out.append("".join(t))
            continue
        if l.startswith("- "):
            if not in_ul:
                out.append("<ul>"); in_ul = True
            item = l[2:]
            # nested continuation lines (indented) get folded into the item
            while i + 1 < len(lines) and lines[i + 1].startswith("  ") and not lines[i + 1].strip().startswith("- "):
                item += " " + lines[i + 1].strip(); i += 1
            out.append(f"<li>{inline(item)}</li>"); i += 1
            continue
        if re.match(r"^\d+\. ", l):
            close()
            items = []
            while i < len(lines) and re.match(r"^\d+\. ", lines[i]):
                item = re.sub(r"^\d+\. ", "", lines[i]); i += 1
                while i < len(lines) and lines[i].startswith("   ") and lines[i].strip():
                    item += " " + lines[i].strip(); i += 1
                items.append(item)
            out.append("<ol>" + "".join(f"<li>{inline(x)}</li>" for x in items) + "</ol>")
            continue
        if l.startswith("> "):
            close()
            buf = []
            while i < len(lines) and lines[i].startswith(">"):
                buf.append(lines[i].lstrip("> ").strip()); i += 1
            out.append(f'<ac:structured-macro ac:name="info"><ac:rich-text-body><p>{inline(" ".join(b for b in buf if b))}</p></ac:rich-text-body></ac:structured-macro>')
            continue
        if l.strip() == "---" or not l.strip():
            close(); i += 1; continue
        if l.startswith("*") and l.endswith("*") and l.count("*") == 2 and len(l) > 2:
            close()
            out.append(f'<ac:structured-macro ac:name="note"><ac:rich-text-body><p>{inline(l.strip("*"))}</p></ac:rich-text-body></ac:structured-macro>')
            i += 1
            continue
        if l.startswith("**") and ":**" in l and i + 1 < len(lines) and lines[i + 1].startswith("**"):
            # metadata block like **Status:** ... / **Scope:** ... -> one paragraph with line breaks
            close()
            buf = []
            while i < len(lines) and lines[i].startswith("**"):
                buf.append(inline(lines[i])); i += 1
            out.append("<p>" + "<br/>".join(buf) + "</p>")
            continue
        close()
        buf = [l]; i += 1
        while i < len(lines) and lines[i].strip() and not re.match(r"^(#|\||- |\d+\. |```|!\[|\*Rendered|---|> )", lines[i]):
            buf.append(lines[i]); i += 1
        out.append(f"<p>{inline(' '.join(buf))}</p>")
    close()
    flush_mermaid()
    return "\n".join(out)


def main():
    PAGES_DIR.mkdir(exist_ok=True); ATT_DIR.mkdir(exist_ok=True); DOCX_DIR.mkdir(exist_ok=True)
    # attachments: every rendered diagram from the pack, plus the openapi file
    for f in (PACK / "diagrams").glob("*.png"):
        shutil.copy(f, ATT_DIR / f.name)
    for f in (PACK / "diagrams").glob("*.mmd"):
        shutil.copy(f, ATT_DIR / f.name)
    shutil.copy(PACK / "openapi" / "atlas-experience-api.yaml", ATT_DIR / "atlas-experience-api.yaml")
    # the two session-management diagrams rendered earlier live next to this script
    for n in ("session-entity-model", "session-lifecycle"):
        if (OUT / f"{n}.png").exists():
            shutil.copy(OUT / f"{n}.png", ATT_DIR / f"{n}.png")

    manifest = {"parent": PARENT_TITLE, "pages": []}
    index_items = []
    for md_name, title in PAGES:
        src = PACK / "md" / md_name if (PACK / "md" / md_name).exists() else ROOT / md_name
        md = src.read_text()
        # the session-management doc's mermaid blocks map to the two pre-rendered PNGs
        slug = md_name.replace(".md", "")
        if slug == "atlas-session-management":
            md = md.replace("```mermaid\nerDiagram", "![x](session-entity-model.png)\n```mermaid\nerDiagram", 1)
            md = md.replace("```mermaid\nstateDiagram-v2", "![x](session-lifecycle.png)\n```mermaid\nstateDiagram-v2", 1)
            # move image lines after the fence so the converter pairs them
            md = re.sub(r"!\[x\]\((session-[a-z-]+\.png)\)\n(```mermaid\n.*?```\n)", r"\2![x](\1)\n", md, flags=re.S)
        body = convert(md, slug)
        (PAGES_DIR / f"{slug}.storage.xhtml").write_text(body)
        # which attachments does this page reference?
        atts = sorted(set(re.findall(r'ri:filename="([^"]+)"', body)))
        manifest["pages"].append({"title": title, "file": f"pages/{slug}.storage.xhtml", "attachments": atts})
        index_items.append(f'<li><ac:link><ri:page ri:content-title="{esc(title)}" /></ac:link></li>')
        # docx fallback
        docx_md = re.sub(r"```mermaid\n.*?```\n", "", md, flags=re.S)
        docx_md = re.sub(r"\]\((?:\.\./diagrams/|atlas-design-pack/diagrams/)", "](" + str(ATT_DIR) + "/", docx_md)
        docx_md = re.sub(r"\]\((session-[a-z-]+\.png)\)", "](" + str(ATT_DIR) + r"/\1)", docx_md)
        docx_md = re.sub(r"^\*Rendered:.*$", "", docx_md, flags=re.M)
        tmp = OUT / "_tmp.md"; tmp.write_text(docx_md)
        subprocess.run(["pandoc", str(tmp), "-o", str(DOCX_DIR / f"{slug}.docx"), "--from", "gfm"], check=True)
        tmp.unlink()

    # parent/index page
    index = ('<p>Design documents for durable session and operation persistence in the Atlas ML Platform experience layer (GKE and Cloud SQL for PostgreSQL). '
             'Start with Session Management for the summary; the remaining pages carry the detail.</p><ol>' + "".join(index_items) + "</ol>"
             '<p>Machine-readable API contract: <ac:link><ri:attachment ri:filename="atlas-experience-api.yaml" /><ac:plain-text-link-body><![CDATA[atlas-experience-api.yaml]]></ac:plain-text-link-body></ac:link></p>')
    (PAGES_DIR / "index.storage.xhtml").write_text(index)
    manifest["parent_file"] = "pages/index.storage.xhtml"
    manifest["parent_attachments"] = ["atlas-experience-api.yaml"]
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2))
    # sanity: well-formed xml
    import xml.etree.ElementTree as ET
    for p in PAGES_DIR.glob("*.xhtml"):
        ET.fromstring('<r xmlns:ac="a" xmlns:ri="b">' + p.read_text().replace("&rarr;", "→").replace("&ge;", "≥").replace("&le;", "≤") + "</r>")
    print(f"{len(manifest['pages'])} pages + index, {len(list(ATT_DIR.iterdir()))} attachments, {len(list(DOCX_DIR.iterdir()))} docx")


if __name__ == "__main__":
    main()
